/* global jQuery, BONZAI_INLINE */
(function ($) {
  'use strict';

  // If the Bonzai iframe ever navigates to a same-origin URL (e.g. thank-you page),
  // force the redirect in the top window so the user leaves the embed.
  function attachTopRedirectGuard(iframeEl) {
    if (!iframeEl || iframeEl.__bonzaiTopRedirectGuard) return;
    iframeEl.__bonzaiTopRedirectGuard = true;

    function maybeForceTopRedirect() {
      try {
        if (!iframeEl.contentWindow || !iframeEl.contentWindow.location) return;
        var href = iframeEl.contentWindow.location.href || '';
        if (!href || href === 'about:blank') return;

        var u = new URL(href, window.location.origin);

        // If the iframe is showing a page on the merchant's origin, escape the iframe.
        if (u.origin === window.location.origin) {
          if (window.top && window.top !== window) {
            window.top.location.href = u.toString();
          } else {
            window.location.href = u.toString();
          }
        }
      } catch (e) {
        // Cross-origin: cannot read location (still inside Bonzai). Ignore.
      }
    }

    iframeEl.addEventListener('load', maybeForceTopRedirect);
    // Extra safety: some flows update history without a full load.
    setInterval(maybeForceTopRedirect, 800);
  }


  var cfg = window.BONZAI_INLINE || {};
  var gatewayId = cfg.gateway_id || 'bonzai';
  var hashFlag = cfg.hash || '#bonzai-inline';
  var sessionUrl = cfg.session_ajax || null;
  var prepareUrl = cfg.prepare_ajax || null;
  var restUrl = cfg.rest || null;
  var restNonce = cfg.nonce || null;

  var prepareTimer = null;
  var pollTimer = null;
  var lastPreparedFp = null;
  var lastEmbedUrl = null;
  var lastOrder = { id: 0, key: '' };

  // Resize helper (does NOT touch page scroll; only adjusts iframe height).
  var resizeScheduled = false;

  function getIframeEl() {
    var c = getPaymentBox();
    if (!c.length) return null;
    var $iframe = c.find('#bonzai-inline-iframe').first();
    return $iframe.length ? $iframe : null;
  }

  function computeIframeHeightPx($iframe) {
    if (!$iframe || !$iframe.length) return 0;
    var el = $iframe.get(0);
    if (!el || !el.getBoundingClientRect) return 0;

    var rect = el.getBoundingClientRect();
    // Available viewport space from iframe top to bottom, with a small padding.
    var padding = 16;
    var avail = window.innerHeight - Math.max(rect.top, 0) - padding;

    // We want near-viewport height to minimize internal iframe scroll (esp. 3DS).
    // Keep a sane minimum so the UI remains usable on small viewports.
    var min = Math.min(560, Math.max(420, window.innerHeight - padding));
    var h = Math.max(min, avail);

    // Cap slightly under full viewport to avoid accidental extra scrollbar.
    var cap = window.innerHeight - padding;
    if (h > cap) h = cap;
    return Math.round(h);
  }

  function applyIframeHeight() {
    var $iframe = getIframeEl();
    if (!$iframe) return;
    if ($iframe.is(':hidden')) return;
    var h = computeIframeHeightPx($iframe);
    if (h > 0) {
      $iframe.css('height', h + 'px');
    }
  }

  function requestIframeResize() {
    if (resizeScheduled) return;
    resizeScheduled = true;
    window.requestAnimationFrame(function () {
      resizeScheduled = false;
      applyIframeHeight();
    });
  }

  function getPaymentBox() {
    return $('.payment_box.payment_method_' + gatewayId).first();
  }

  function ensureContainer() {
    var box = getPaymentBox();
    if (!box.length) return null;

    var c = box.find('#bonzai-inline-container');
    if (c.length) return c;

    c = $('<div id="bonzai-inline-container" class="is-hidden"></div>');
    c.append('<div id="bonzai-inline-loading" style="display:none">Chargement du paiement sécurisé...</div>');
    c.append('<div id="bonzai-inline-error" style="display:none"></div>');
    c.append('<iframe id="bonzai-inline-iframe" title="Bonzai secure payment" allow="payment *; clipboard-write *" style="display:none; width:100%; min-height:640px; border:0;"></iframe>');
    box.append(c);

    // Resize once the embedded content navigates (e.g., 3DS steps).
    // This does not read iframe contents (cross-origin), it only adjusts the outer iframe height.
    c.find('#bonzai-inline-iframe').on('load', function () {
      requestIframeResize();
    });
    return c;
  }

  function showLoading(msg) {
    var c = ensureContainer();
    if (!c) return;
    c.removeClass('is-hidden');
    c.find('#bonzai-inline-error').hide().text('');
    c.find('#bonzai-inline-iframe').hide();
    c.find('#bonzai-inline-loading').show().text(msg || 'Chargement du paiement sécurisé...');
  }

  function showError(msg) {
    var c = ensureContainer();
    if (!c) return;
    c.removeClass('is-hidden');
    c.find('#bonzai-inline-loading').hide();
    c.find('#bonzai-inline-iframe').hide();
    c.find('#bonzai-inline-error').show().text(msg || 'Impossible de charger le paiement.');
  }

  function showIframe(url) {
    var c = ensureContainer();
    if (!c) return;
    c.removeClass('is-hidden');
    c.find('#bonzai-inline-loading').hide();
    c.find('#bonzai-inline-error').hide().text('');
    c.find('#bonzai-inline-iframe').show();

    // Avoid resetting the iframe if already loaded with the same URL.
    var $iframe = c.find('#bonzai-inline-iframe');
    if ($iframe.attr('src') !== url) {
      $iframe.attr('src', url);
    }

    // Adjust height to reduce internal scrolling (no impact on page scroll).
    requestIframeResize();
  }

  function hideContainer() {
    var c = ensureContainer();
    if (!c) return;
    c.addClass('is-hidden');
    c.find('#bonzai-inline-loading').hide();
    c.find('#bonzai-inline-error').hide().text('');
    c.find('#bonzai-inline-iframe').hide();
  }

  function isGatewaySelected() {
    return $('input[name="payment_method"]:checked').val() === gatewayId;
  }

  function getCheckoutForm() {
    var $form = $('form.checkout');
    if ($form.length) return $form;
    // Some builders wrap checkout differently; fall back to the first form on checkout.
    $form = $('form').filter(function () {
      return $(this).find('input[name="payment_method"]').length > 0;
    }).first();
    return $form.length ? $form : null;
  }

  function getFieldValue(selectors) {
    var val = '';
    selectors.split(',').forEach(function (sel) {
      sel = $.trim(sel);
      if (!sel) return;
      var $el = $(sel).first();
      if ($el.length && $el.val() !== undefined && $el.val() !== null) {
        val = String($el.val());
      }
    });
    return $.trim(val);
  }

  function getIdentitySnapshot() {
    var email = getFieldValue('#billing_email, input[name="billing_email"]');
    var first = getFieldValue('#billing_first_name, input[name="billing_first_name"]');
    var last = getFieldValue('#billing_last_name, input[name="billing_last_name"]');
    var postcode = getFieldValue('#billing_postcode, input[name="billing_postcode"]');
    return {
      email: email,
      first: first,
      last: last,
      postcode: postcode
    };
  }

  function isValidEmail(email) {
    if (!email) return false;
    // Basic validation (server will enforce real validation).
    return /.+@.+\..+/.test(email);
  }

  function computeFp(snapshot) {
    // We intentionally keep this lightweight and client-side only.
    return [snapshot.email, snapshot.first, snapshot.last, snapshot.postcode].join('|');
  }

  function fetchEmbedUrlFromSession() {
    if (!sessionUrl) return $.Deferred().reject('missing_session_url').promise();
    return $.getJSON(sessionUrl).then(function (res) {
      // support wp_send_json payload
      if (res && res.ok && res.embed_url) return res;
      // support Woo wc-ajax success wrapper
      if (res && res.success && res.data) return res.data;
      throw new Error('no_embed_url');
    });
  }

  function prepareSession() {
    if (!prepareUrl) {
      showError('Configuration Bonzai invalide (prepare endpoint manquant).');
      return;
    }

    var snap = getIdentitySnapshot();
    if (!isValidEmail(snap.email)) {
      // Do not show an error while the user is typing; keep the box hidden.
      hideContainer();
      return;
    }

    var fp = computeFp(snap);
    if (lastPreparedFp && fp === lastPreparedFp && lastEmbedUrl) {
      showIframe(lastEmbedUrl);
      return;
    }

    var $form = getCheckoutForm();
    if (!$form) {
      showError('Formulaire de paiement introuvable.');
      return;
    }

    showLoading('Ouverture du paiement sécurisé...');

    $.ajax({
      url: prepareUrl,
      method: 'POST',
      dataType: 'json',
      data: {
        checkout_data: $form.serialize()
      }
    }).done(function (res) {
      if (!res || !res.ok || !res.embed_url) {
        var msg = 'Impossible de charger le paiement. Rafraîchissez la page et réessayez.';
        if (res && res.error === 'missing_email') {
          msg = 'Veuillez renseigner une adresse email valide pour afficher le paiement.';
        }
        showError(msg);
        return;
      }

      lastPreparedFp = fp;
      lastEmbedUrl = res.embed_url;
      lastOrder.id = parseInt(res.order_id || 0, 10) || 0;
      lastOrder.key = String(res.order_key || '');

      // Ensure the URL reflects inline mode (optional; useful for reload recovery).
      try {
        if (window.location.hash !== hashFlag) {
          window.location.hash = hashFlag;
        }
      } catch (e) {}

      showIframe(res.embed_url);
      startPolling();
    }).fail(function () {
      showError('Impossible de charger le paiement. Rafraîchissez la page et réessayez.');
    });
  }

  function startPolling() {
    if (!restUrl || !lastOrder.id || !lastOrder.key) return;
    if (pollTimer) return;

    pollTimer = window.setInterval(function () {
      $.ajax({
        url: restUrl,
        method: 'GET',
        dataType: 'json',
        headers: restNonce ? { 'X-WP-Nonce': restNonce } : {},
        data: {
          order_id: lastOrder.id,
          order_key: lastOrder.key
        }
      }).done(function (res) {
        if (!res) return;

        // Support both response shapes (this plugin contains two route registrations).
        var paid = false;
        var thankyou = '';

        if (res.ok) {
          paid = !!res.paid;
          thankyou = res.thankyou || '';
        } else if (res.valid !== undefined) {
          paid = !!res.paid;
          thankyou = res.thankyou_url || '';
        }

        if (paid && thankyou) {
          window.clearInterval(pollTimer);
          pollTimer = null;
          window.location.href = thankyou;
        }
      });
    }, 2000);
  }

  function schedulePrepare() {
    if (!isGatewaySelected()) {
      hideContainer();
      return;
    }
    if (prepareTimer) window.clearTimeout(prepareTimer);
    prepareTimer = window.setTimeout(function () {
      prepareSession();
    }, 650);
  }

  function maybeLoadFromHashOnInit() {
    if (!isGatewaySelected()) return;
    if (window.location.hash !== hashFlag) return;
    // If we reload and session exists, restore iframe quickly.
    showLoading('Chargement du paiement sécurisé...');
    fetchEmbedUrlFromSession()
      .then(function (data) {
        if (data && data.embed_url) {
          lastEmbedUrl = data.embed_url;
          lastOrder.id = parseInt(data.order_id || 0, 10) || 0;
          // order_key is not returned by session endpoint; we may re-prepare to get it.
          showIframe(data.embed_url);
          // Re-prepare to obtain order_key for polling.
          schedulePrepare();

    // Guard: if thank-you loads inside iframe, force top redirect.
    var ifr = document.getElementById('bonzai-inline-iframe');
    attachTopRedirectGuard(ifr);
        } else {
          schedulePrepare();
        }
      })
      .catch(function () {
        schedulePrepare();
      });
  }

  function bindEvents() {
    // Ensure container exists.
    ensureContainer();

    $(document.body).on('updated_checkout', function () {
      ensureContainer();
      schedulePrepare();
      // Checkout fragments may move the iframe; keep the height optimal.
      requestIframeResize();
    });

    $(document.body).on('change', 'input[name="payment_method"]', function () {
      // Reset state when switching away.
      if (!isGatewaySelected()) {
        hideContainer();
        lastPreparedFp = null;
        lastEmbedUrl = null;
        lastOrder = { id: 0, key: '' };
        if (pollTimer) {
          window.clearInterval(pollTimer);
          pollTimer = null;
        }
        return;
      }
      schedulePrepare();
      requestIframeResize();
    });

    // Identity fields must trigger preparation.
    $(document.body).on(
      'input change',
      '#billing_first_name, #billing_last_name, #billing_email, #billing_postcode, input[name="billing_first_name"], input[name="billing_last_name"], input[name="billing_email"], input[name="billing_postcode"]',
      function () {
        schedulePrepare();
      }
    );

    // Address fields can also impact totals/shipping in many stores.
    $(document.body).on(
      'input change',
      '#billing_country, #billing_state, #billing_city, #billing_address_1, #billing_address_2, input[name="billing_country"], input[name="billing_state"], input[name="billing_city"], input[name="billing_address_1"], input[name="billing_address_2"]',
      function () {
        if (!isGatewaySelected()) return;
        // Let Woo recompute first, then prepare.
        $(document.body).trigger('update_checkout');
      }
    );

    maybeLoadFromHashOnInit();
    // Also prepare if Bonzai is already selected.
    schedulePrepare();

    // Keep iframe height optimal as the user scrolls to the payment area.
    $(window).on('resize', requestIframeResize);
    $(window).on('scroll', function () {
      // Only resize when the iframe exists and is shown.
      var $iframe = getIframeEl();
      if ($iframe && $iframe.length && !$iframe.is(':hidden')) {
        requestIframeResize();
      }
    });
  }

  $(function () {
    bindEvents();
  });
})(jQuery);
