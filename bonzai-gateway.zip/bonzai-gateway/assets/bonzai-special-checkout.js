/* global jQuery, BONZAI_SPECIAL */
(function ($) {
  'use strict';

  // If the Bonzai iframe ever navigates to a same-origin URL (e.g. thank-you page),
  // force the redirect in the top window so the user leaves the embed.
  function attachTopRedirectGuard(iframeEl) {
    if (!iframeEl || iframeEl.__bonzaiTopRedirectGuard) return;
    iframeEl.__bonzaiTopRedirectGuard = true;

    function maybeForceTopRedirect() {
      try {
        if (!iframeEl.contentWindow || !iframeEl.contentWindow.location) return;
        var href = iframeEl.contentWindow.location.href || '';
        if (!href || href === 'about:blank') return;

        var u = new URL(href, window.location.origin);

        // If the iframe is showing a page on the merchant's origin, escape the iframe.
        if (u.origin === window.location.origin) {
          if (window.top && window.top !== window) {
            window.top.location.href = u.toString();
          } else {
            window.location.href = u.toString();
          }
        }
      } catch (e) {
        // Cross-origin: cannot read location (still inside Bonzai). Ignore.
      }
    }

    iframeEl.addEventListener('load', maybeForceTopRedirect);
    // Extra safety: some flows update history without a full load.
    setInterval(maybeForceTopRedirect, 800);
  }


  var cfg = window.BONZAI_SPECIAL || {};
  var prepareUrl = cfg.prepare_ajax || '';
  var restUrl = cfg.rest || '';
  var restNonce = cfg.nonce || '';

  var i18n = cfg.i18n || {};
  var required = cfg.required || {};

  function t(key, fallback) {
    return (i18n && i18n[key]) ? i18n[key] : (fallback || '');
  }

  var prepareTimer = null;
  var pollTimer = null;
  var lastFp = '';
  var lastEmbed = '';
  var lastCheckoutUrl = '';
  var orderId = 0;
  var orderKey = '';

  function $form() { return $('#bonzai-sc-form'); }
  function $container() { return $('#bonzai-inline-container'); }
  function $loading() { return $('#bonzai-inline-loading'); }
  function $error() { return $('#bonzai-inline-error'); }
  function $iframe() { return $('#bonzai-inline-iframe'); }

  // --- 3DS adaptive height handling (only during 3D Secure challenge) ---
  var in3ds = false;

  function compute3dsHeight() {
    // Fit most 3DS challenge screens without internal scrolling.
    // Keep within a sane range so we don't blow up the layout.
    var vh = Math.max(0, window.innerHeight || 0);
    // Leave some breathing room for page padding/cards.
    var h = Math.round(vh * 0.92);
    return Math.max(740, Math.min(1100, h));
  }

  function setIframeHeight(px) {
    var $if = $iframe();
    if (!$if.length) return;
    if (px && px > 0) {
      $if.css('height', px + 'px');
    }
  }

  function enable3dsMode() {
    var $if = $iframe();
    if (!$if.length) return;
    in3ds = true;
    $if.addClass('is-3ds');
    setIframeHeight(compute3dsHeight());
  }

  function disable3dsMode() {
    var $if = $iframe();
    if (!$if.length) return;
    in3ds = false;
    $if.removeClass('is-3ds');
    // Reset to default (CSS var controlled height)
    $if.css('height', '');
  }

  // Listen to Bonzai iframe messages. Bonzai can emit "3ds"/"challenge" events or a resize payload.
  window.addEventListener('message', function (e) {
    var $if = $iframe();
    if (!$if.length) return;
    var iframeEl = $if.get(0);
    if (!iframeEl || !iframeEl.contentWindow) return;

    // Only accept messages from our iframe.
    if (e.source !== iframeEl.contentWindow) return;

    var d = e.data;

    // If Bonzai sends explicit resize info, honor it.
    if (d && typeof d === 'object') {
      var h = parseInt(d.height || d.iframeHeight || d.frameHeight || 0, 10);
      if (h && h > 0) {
        // If the height is large, we assume we're in an auth step (3DS).
        if (h >= 720) enable3dsMode();
        setIframeHeight(Math.max(620, Math.min(1400, h)));
      }

      var evt = String(d.type || d.event || d.name || '').toLowerCase();
      var status = String(d.status || d.state || '').toLowerCase();
      if (evt && /3ds|three/.test(evt)) enable3dsMode();
      if (status && /3ds|challenge|requires_action|authenticate/.test(status)) enable3dsMode();
      if (status && /paid|success|succeeded|complete|completed/.test(status)) disable3dsMode();
      if (evt && /close|done|success|paid|complete/.test(evt)) disable3dsMode();
      return;
    }

    // Fallback: inspect string payload.
    var s = (typeof d === 'string') ? d : '';
    if (!s) return;
    var ls = s.toLowerCase();
    if (/(3d\s*secure|3ds|challenge|authentication)/i.test(s)) enable3dsMode();
    if (/(paid|success|succeeded|complete|completed|thankyou|redirect)/i.test(s)) disable3dsMode();
  }, false);

  // Keep 3DS height responsive on resize.
  window.addEventListener('resize', function () {
    if (in3ds) setIframeHeight(compute3dsHeight());
  });

  function showLoading(text) {
    $container().removeClass('is-hidden');
    $error().hide().text('');
    $iframe().hide();
    $loading().show().text(text || t('loading_initial', 'Loading secure payment...'));
  }

  function showError(text) {
    $container().removeClass('is-hidden');
    $loading().hide();
    $iframe().hide();
    $error().show().text(text || t('err_required', 'Please complete the required fields to continue.'));
  }

  function showIframe(url) {
    // Ensure we always load Bonzai in explicit embed mode.
    // Some API responses may return a manage URL without the embed flag.
    if (url && url.indexOf('embed=1') === -1) {
      url += (url.indexOf('?') === -1 ? '?' : '&') + 'embed=1';
    }
    $container().removeClass('is-hidden');
    $loading().hide();
    $error().hide().text('');
    if ($iframe().attr('src') !== url) {
      $iframe().attr('src', url);
    }
    $iframe().show();
  }

  function val(sel) {
    var out = '';
    sel.split(',').forEach(function (s) {
      s = $.trim(s);
      if (!s) return;
      var $el = $(s).first();
      if ($el.length && $el.val() !== undefined && $el.val() !== null) {
        out = String($el.val());
      }
    });
    return $.trim(out);
  }

  function isValidEmail(email) {
    return /.+@.+\..+/.test(email || '');
  }

  function termsPresentAndUnchecked() {
    var $t = $form().find('input[name="terms"]');
    if (!$t.length) return false;
    return !$t.is(':checked');
  }

  function stateRequiredAndEmpty() {
    var $s = $form().find('#billing_state, [name="billing_state"]').first();
    if (!$s.length) return false;
    var required = !!($s.prop('required') || $s.attr('aria-required') === 'true' || $s.data('required') === 1);
    if (!required) return false;
    return $.trim(String($s.val() || '')) === '';
  }

  function snapshot() {
    return {
      first: val('#billing_first_name, [name="billing_first_name"]'),
      last: val('#billing_last_name, [name="billing_last_name"]'),
      email: val('#billing_email, [name="billing_email"]'),
      addr1: val('#billing_address_1, [name="billing_address_1"]'),
      city: val('#billing_city, [name="billing_city"]'),
      postcode: val('#billing_postcode, [name="billing_postcode"]'),
      country: val('#billing_country, [name="billing_country"]'),
      state: val('#billing_state, [name="billing_state"]')
    };
  }

  function fingerprint(s) {
    return [s.first, s.last, s.email, s.addr1, s.city, s.postcode, s.country, s.state, termsPresentAndUnchecked() ? '0' : '1'].join('|');
  }

  function validate(s) {
    // Required identity.
    if ((required.first && !s.first) || (required.last && !s.last) || (required.email && !s.email)) {
      return t('err_required', 'Please complete the required fields to continue.');
    }
    if (required.email && !isValidEmail(s.email)) {
      return t('err_email', 'Please enter a valid email address to continue.');
    }

    // Required billing address.
    if ((required.address_1 && !s.addr1) || (required.city && !s.city) || (required.postcode && !s.postcode) || (required.country && !s.country)) {
      return t('err_required', 'Please complete the required fields to continue.');
    }
    if (required.state && stateRequiredAndEmpty()) {
      return t('err_state', 'Please enter your state/region to continue.');
    }

    // Custom required fields.
    var missingCustom = false;
    $('[data-bonzai-required="1"]').each(function () {
      var v = $.trim(String($(this).val() || ''));
      if (!v) missingCustom = true;
    });
    if (missingCustom) {
      return t('err_required', 'Please complete the required fields to continue.');
    }

    if (termsPresentAndUnchecked()) {
      return t('err_terms', 'Please accept the terms and conditions to continue.');
    }
    return '';
  }

  function startPolling() {
    if (!restUrl || !orderId || !orderKey) return;
    if (pollTimer) return;

    pollTimer = window.setInterval(function () {
      $.ajax({
        url: restUrl,
        method: 'GET',
        dataType: 'json',
        headers: restNonce ? { 'X-WP-Nonce': restNonce } : {},
        data: { order_id: orderId, order_key: orderKey }
      }).done(function (res) {
        if (!res || !res.ok) return;
        if (res.paid && res.thankyou) {
          window.clearInterval(pollTimer);
          pollTimer = null;
          window.location.href = res.thankyou;
        }
      });
    }, 2000);
  }

  function prepareSession(forceNew) {
    var s = snapshot();
    var msg = validate(s);
    if (msg) {
      showError(msg);
      return;
    }

    var fp = fingerprint(s);
    if (!forceNew && lastFp && fp === lastFp && lastEmbed) {
      showIframe(lastEmbed);
      return;
    }

    if (!prepareUrl) {
      showError('Bonzai configuration is invalid (prepare endpoint missing).');
      return;
    }

    showLoading(t('loading', 'Opening secure payment...'));

    $.ajax({
      url: prepareUrl,
      method: 'POST',
      dataType: 'json',
      data: {
        checkout_data: $form().serialize(),
        force_new: forceNew ? '1' : '0',
        special_checkout: '1'
      }
    }).done(function (res) {
      if (!res || !res.ok || !res.embed_url) {
        var emsg = t('err_generic', 'Unable to load the payment. Please refresh and try again.');
        if (res && res.error === 'missing_email') {
          emsg = t('err_email', 'Please enter a valid email address to continue.');
        }
        showError(emsg);
        return;
      }

      lastFp = fp;
      lastEmbed = res.embed_url;
      lastCheckoutUrl = String(res.checkout_url || '');
      orderId = parseInt(res.order_id || 0, 10) || 0;
      orderKey = String(res.order_key || '');

      // IMPORTANT: This page is intended to keep the full payment flow embedded.
      // Therefore, we never perform a top-level redirect to Bonzai.
      // If Bonzai returns an embed_url, use it. (It should already include embed=1.)
      showIframe(lastEmbed);
      startPolling();
    }).fail(function () {
      showError(t('err_generic', 'Unable to load the payment. Please refresh and try again.'));
    });
  }

  function schedulePrepare(forceNew) {
    if (prepareTimer) window.clearTimeout(prepareTimer);
    prepareTimer = window.setTimeout(function () {
      prepareSession(!!forceNew);
    }, 550);
  }

  $(function () {

    // Guard: if thank-you loads inside iframe, force redirect in top window.
    (function waitForIframe(){
      var ifr = document.getElementById('bonzai-inline-iframe');
      if (ifr) { attachTopRedirectGuard(ifr); return; }
      setTimeout(waitForIframe, 500);
    })();
    if (!$form().length) return;

    // Prevent standard submit.
    $form().on('submit', function (e) {
      e.preventDefault();
      return false;
    });

    // Always create a fresh session on first load to avoid a stuck "processing" iframe after refresh.
    schedulePrepare(true);

    // Debounced prepare on any field change.
    $form().on('input change', 'input, select, textarea', function () {
      schedulePrepare(false);
    });


    // Testimonials carousel (under order summary)
    (function initTestimonialsCarousel() {
      var $root = $('#bonzai-sc-testimonials');
      if (!$root.length) return;

	      // Only run carousel logic when mode=carousel.
	      var mode = ($root.data('bonzai-mode') || 'carousel');
	      if (mode !== 'carousel') return;

      var $track = $root.find('.bonzai-sc-testimonials-track');
      var $items = $root.find('.bonzai-sc-testimonial');
	      var $dotsWrap = $root.find('.bonzai-sc-testimonials-dots');

      var count = $items.length;
      if (!count) {
        $root.remove();
        return;
      }

      var idx = 0;

      function renderDots() {
        $dotsWrap.empty();
        if (count <= 1) return;
        for (var i = 0; i < count; i++) {
          var $d = $('<span class="bonzai-sc-dot" />');
          if (i === idx) $d.addClass('is-on');
          (function (n) {
            $d.on('click', function () { go(n); resetAutoplay(); });
          })(i);
          $dotsWrap.append($d);
        }
      }

      function go(n) {
        idx = Math.max(0, Math.min(count - 1, n));
        var x = -idx * 100;
        $track.css('transform', 'translateX(' + x + '%)');
        renderDots();
      }

      
      // Autoplay (every 5s). Reset on interaction.
      var autoplayMs = 5000;
      var autoplayTimer = null;

      function stopAutoplay() {
        if (autoplayTimer) { clearInterval(autoplayTimer); autoplayTimer = null; }
      }

      function startAutoplay() {
        stopAutoplay();
        if (count <= 1) return;
        autoplayTimer = setInterval(function () {
          var next = idx + 1;
          if (next >= count) next = 0;
          go(next);
        }, autoplayMs);
      }

      function resetAutoplay() {
        startAutoplay();
      }
      // Basic swipe support
      var startX = 0;
      var dx = 0;
      $root.find('.bonzai-sc-testimonials-viewport').on('touchstart', function (e) {
        var t0 = (e.originalEvent.touches && e.originalEvent.touches[0]) ? e.originalEvent.touches[0] : null;
        if (!t0) return;
        startX = t0.clientX;
        dx = 0;
      });
      $root.find('.bonzai-sc-testimonials-viewport').on('touchmove', function (e) {
        var t0 = (e.originalEvent.touches && e.originalEvent.touches[0]) ? e.originalEvent.touches[0] : null;
        if (!t0) return;
        dx = t0.clientX - startX;
      });
	      $root.find('.bonzai-sc-testimonials-viewport').on('touchend', function () {
        if (Math.abs(dx) < 40) return;
        if (dx < 0) go(idx + 1);
        else go(idx - 1);
	        resetAutoplay();
      });

	      go(0);
	      startAutoplay();
    })();

  });
})(jQuery);
