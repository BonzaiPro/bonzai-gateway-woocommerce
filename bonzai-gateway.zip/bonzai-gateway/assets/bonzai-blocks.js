/* global wc, wp */
(function () {
  'use strict';

  if (!window.wc || !wc.wcBlocksRegistry || !wc.wcSettings) {
    return;
  }

  var settings = wc.wcSettings.getSetting('bonzai_data', {});
  var label = settings.title || 'Bonzai';

  var Content = function () {
    var el = window.wp.element.createElement;
    var desc = settings.description || '';
    return el('div', {}, desc);
  };

  wc.wcBlocksRegistry.registerPaymentMethod({
    name: 'bonzai',
    label: label,
    ariaLabel: label,
    content: window.wp.element.createElement(Content, null),
    edit: window.wp.element.createElement(Content, null),
    canMakePayment: function () { return true; },
    supports: {
      features: settings.supports || ['products']
    }
  });
})();
