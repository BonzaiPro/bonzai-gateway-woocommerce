( function () {
	// Ensure WooCommerce Blocks globals exist.
	if ( ! window.wc || ! window.wc.wcBlocksRegistry || ! window.wc.wcSettings ) {
		return;
	}

	const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
	const settings = window.wc.wcSettings.getSetting( 'bonzai_data', {} );

	// wp.htmlEntities is provided by dependency 'wp-html-entities'
	const decodeEntities =
		( window.wp &&
			window.wp.htmlEntities &&
			window.wp.htmlEntities.decodeEntities ) ||
		( ( s ) => s );

	const label = decodeEntities( settings.title || 'Bonzai' );
	const description = decodeEntities( settings.description || '' );

	const Content = () => {
		return window.wp && window.wp.element
			? window.wp.element.createElement( 'div', null, description )
			: description;
	};

	/**
	 * Minimal “legacy” integration:
	 * - We do NOT do any custom Store API processing.
	 * - We simply provide a valid SUCCESS response so checkout proceeds.
	 * - WooCommerce will then call the PHP gateway process_payment() (legacy flow).
	 *
	 * This is consistent with WooCommerce docs about legacy processing. 
	 */
	const BonzaiPaymentMethod = {
		name: 'bonzai',
		label: label,
		ariaLabel: label,
		content: window.wp.element.createElement( Content, null ),
		edit: window.wp.element.createElement( Content, null ),
		canMakePayment: () => true,
		supports: {
			features: [ 'products' ],
		},
		// Optional: show a more explicit CTA for redirect gateways.
		placeOrderButtonLabel: 'Proceed to Bonzai',
	};

	registerPaymentMethod( BonzaiPaymentMethod );
} )();
