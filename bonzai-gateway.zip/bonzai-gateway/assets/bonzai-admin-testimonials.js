/* global jQuery, BONZAI_ADMIN_TESTIMONIALS */
(function ($) {
  'use strict';

  var cfg = window.BONZAI_ADMIN_TESTIMONIALS || {};
  var i18n = (cfg && cfg.i18n) ? cfg.i18n : {};

  function t(key, fallback) {
    return (i18n && i18n[key]) ? i18n[key] : (fallback || '');
  }

  function safeParse(json) {
    try {
      var v = JSON.parse(json || '[]');
      return Array.isArray(v) ? v : [];
    } catch (e) {
      return [];
    }
  }

  function uid() {
    return 't_' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  }

  function normalizeItem(item) {
    item = item || {};
    return {
      id: item.id || uid(),
      name: (item.name || '').toString(),
      date: (item.date || '').toString(),
      stars: Math.max(1, Math.min(5, parseInt(item.stars || 5, 10) || 5)),
      content: (item.content || '').toString(),
      photo: (item.photo || '').toString()
    };
  }

  function renderStars(n) {
    var out = '';
    for (var i = 1; i <= 5; i++) out += '<span class="bzt-star ' + (i <= n ? 'is-on' : 'is-off') + '">★</span>';
    return out;
  }

  function buildCard(item) {
    var avatar = item.photo ? '<img class="bzt-avatar" src="' + item.photo + '" alt="" />' : '<div class="bzt-avatar is-placeholder"></div>';
    var date = item.date ? '<div class="bzt-date">' + escapeHtml(item.date) + '</div>' : '';
    return (
      '<div class="bzt-card" data-id="' + item.id + '">' +
        '<div class="bzt-card-top">' +
          avatar +
          '<div class="bzt-meta">' +
            '<div class="bzt-name">' + escapeHtml(item.name || '') + '</div>' +
            date +
            '<div class="bzt-stars">' + renderStars(item.stars) + '</div>' +
          '</div>' +
          '<div class="bzt-actions">' +
            '<button type="button" class="button bzt-edit">' + escapeHtml(t('edit', 'Edit')) + '</button> ' +
            '<button type="button" class="button bzt-delete">' + escapeHtml(t('delete', 'Delete')) + '</button>' +
          '</div>' +
        '</div>' +
        '<div class="bzt-content">' + escapeHtml(item.content || '') + '</div>' +
        '<div class="bzt-drag-hint">↕</div>' +
      '</div>'
    );
  }

  function escapeHtml(s) {
    return (s || '').toString()
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function openIframeModal(opts, onSave) {
    opts = opts || {};
    var item = normalizeItem(opts.item || {});
    var isEdit = !!opts.isEdit;

    var $overlay = $('#bonzai-testimonial-modal');
    if (!$overlay.length) {
      $overlay = $('<div id="bonzai-testimonial-modal" class="bzt-modal-overlay" style="display:none"></div>');
      var $modal = $('<div class="bzt-modal"></div>');
      var $head = $('<div class="bzt-modal-head"><div class="bzt-modal-title"></div><button type="button" class="bzt-close" aria-label="Close">×</button></div>');
      var $body = $('<div class="bzt-modal-body"></div>');
      $modal.append($head).append($body);
      $overlay.append($modal);
      $('body').append($overlay);

      $overlay.on('click', function (e) {
        if (e.target === $overlay[0]) close();
      });
      $overlay.find('.bzt-close').on('click', close);

      function close() {
        $overlay.hide();
        $overlay.find('iframe').remove();
      }

      $overlay.data('close', close);
    }

    var closeFn = $overlay.data('close');
    $overlay.find('.bzt-modal-title').text(isEdit ? t('edit', 'Edit testimonial') : t('add', 'Add a testimonial'));

    var srcdoc = buildIframeSrcdoc(item, {
      title: isEdit ? t('edit', 'Edit testimonial') : t('add', 'Add a testimonial'),
      save: t('save', 'Save'),
      cancel: t('cancel', 'Cancel'),
      profile_photo: t('profile_photo', 'Profile photo'),
      image_url: t('image_url', 'Image URL'),
      drop_here: t('drop_here', 'Or drop an image here'),
      name: t('name', 'Name / Pseudo'),
      date: t('date', 'Date'),
      rating: t('rating', 'Rating (1-5)'),
      content: t('content', 'Testimonial'),
      upload: t('upload', 'Drag & drop or click to upload'),
      use_url: t('use_url', 'Use image URL')
    });

    var $iframe = $('<iframe class="bzt-iframe" sandbox="allow-scripts allow-forms allow-same-origin"></iframe>');
    $iframe.attr('srcdoc', srcdoc);
    $overlay.find('.bzt-modal-body').empty().append($iframe);
    $overlay.show();

    function onMessage(ev) {
      if (!ev || !ev.data || typeof ev.data !== 'object') return;
      if (ev.data.type === 'BONZAI_TESTIMONIAL_CANCEL') {
        window.removeEventListener('message', onMessage);
        closeFn();
        return;
      }
      if (ev.data.type === 'BONZAI_TESTIMONIAL_SAVE') {
        window.removeEventListener('message', onMessage);
        closeFn();
        var payload = ev.data.payload || {};
        onSave(normalizeItem(payload));
      }
    }

    window.addEventListener('message', onMessage);
  }

  function buildIframeSrcdoc(item, labels) {
    // Keep it small and dependency-free.
    function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
    var init = {
      id: item.id,
      name: item.name,
      date: item.date,
      stars: item.stars,
      content: item.content,
      photo: item.photo
    };

    return (
`<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<style>
  :root { --bg:#0b0f1a; --card:#ffffff; --muted:#6b7280; --border:#e5e7eb; --radius:12px; }
  body{ margin:0; font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif; background:#f6f7fb; }
  .wrap{ padding:16px; }
  .grid{ display:grid; gap:12px; grid-template-columns: 1fr 1fr; }
  .grid.one{ grid-template-columns:1fr; }
  .card{ background:var(--card); border:1px solid var(--border); border-radius:var(--radius); padding:12px; }
  label{ display:block; font-size:12px; color:#111827; margin:0 0 6px; }
  input, textarea, select{ width:100%; box-sizing:border-box; padding:10px; border:1px solid var(--border); border-radius:10px; font-size:14px; }
  textarea{ min-height:90px; resize:vertical; }
  .row{ display:grid; gap:12px; grid-template-columns: 1fr 1fr; }
  .row.one{ grid-template-columns:1fr; }
  .drop{ border:1px dashed #cbd5e1; border-radius:12px; padding:12px; text-align:center; color:var(--muted); cursor:pointer; background:#fbfcff; }
  .drop.drag{ background:#eef2ff; border-color:#818cf8; }
  .preview{ display:flex; gap:10px; align-items:center; margin-top:10px; }
  .avatar{ width:44px; height:44px; border-radius:999px; overflow:hidden; background:#e5e7eb; flex:0 0 auto; }
  .avatar img{ width:100%; height:100%; object-fit:cover; }
  .btns{ display:flex; gap:10px; justify-content:flex-end; padding:12px 16px; border-top:1px solid var(--border); background:#fff; position:sticky; bottom:0; }
  .btn{ border-radius:12px; padding:10px 14px; font-weight:600; border:1px solid var(--border); background:#fff; cursor:pointer; }
  .btn.primary{ background:#111827; color:#fff; border-color:#111827; }
  .stars{ display:flex; gap:4px; margin-top:6px; }
  .s{ font-size:16px; color:#d1d5db; }
  .s.on{ color:#f59e0b; }
  .hint{ font-size:12px; color:var(--muted); margin-top:6px;}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="grid">
      <div>
        <label>${esc(labels.name)}</label>
        <input id="name" value="${esc(init.name)}" placeholder="${esc(labels.name)}" />
      </div>
      <div>
        <label>${esc(labels.date)}</label>
        <input id="date" type="date" value="${esc(init.date)}" />
      </div>
    </div>
    <div class="grid" style="margin-top:12px">
      <div>
        <label>${esc(labels.rating)}</label>
        <select id="stars">
          ${[1,2,3,4,5].map(n=>`<option value="${n}" ${n===init.stars?'selected':''}>${n}</option>`).join('')}
        </select>
        <div class="stars" aria-hidden="true">
          ${[1,2,3,4,5].map(n=>`<span class="s ${n<=init.stars?'on':''}">★</span>`).join('')}
        </div>
      </div>
      <div>
        <label>${esc(labels.image_url)}</label>
        <input id="imgUrl" value="${esc(init.photo && init.photo.indexOf('data:image')===0 ? '' : init.photo)}" placeholder="https://..." />
        <div class="hint">${esc(labels.use_url)}</div>
      </div>
    </div>

    <div style="margin-top:12px">
      <label>${esc(labels.profile_photo)}</label>
      <div id="drop" class="drop">${esc(labels.upload)}<div class="hint">${esc(labels.drop_here)}</div></div>
      <input id="file" type="file" accept="image/*" style="display:none" />
      <div class="preview">
        <div class="avatar" id="avatar">${init.photo ? `<img src="${esc(init.photo)}" alt="" />` : ''}</div>
        <div class="hint" id="imgInfo">${init.photo ? '✓' : ''}</div>
      </div>
    </div>

    <div style="margin-top:12px">
      <label>${esc(labels.content)}</label>
      <textarea id="content" placeholder="${esc(labels.content)}">${esc(init.content)}</textarea>
    </div>
  </div>
</div>

<div class="btns">
  <button class="btn" id="cancel">${esc(labels.cancel)}</button>
  <button class="btn primary" id="save">${esc(labels.save)}</button>
</div>

<script>
(function(){
  const init = ${JSON.stringify(init)};
  let photo = init.photo || '';

  const drop = document.getElementById('drop');
  const file = document.getElementById('file');
  const avatar = document.getElementById('avatar');
  const imgUrl = document.getElementById('imgUrl');
  const imgInfo = document.getElementById('imgInfo');
  const stars = document.getElementById('stars');
  const starsRow = document.querySelector('.stars');

  function setPreview(src){
    photo = src || '';
    avatar.innerHTML = photo ? '<img src="'+photo.replace(/"/g,'&quot;')+'" alt=""/>' : '';
    imgInfo.textContent = photo ? '✓' : '';
  }

  function readFile(f){
    const reader = new FileReader();
    reader.onload = () => setPreview(reader.result);
    reader.readAsDataURL(f);
  }

  drop.addEventListener('click', () => file.click());
  file.addEventListener('change', () => { if (file.files && file.files[0]) readFile(file.files[0]); });

  ['dragenter','dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('drag'); }));
  ['dragleave','drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('drag'); }));
  drop.addEventListener('drop', e => {
    const f = e.dataTransfer && e.dataTransfer.files ? e.dataTransfer.files[0] : null;
    if (f) readFile(f);
  });

  imgUrl.addEventListener('input', () => {
    const v = imgUrl.value.trim();
    if (v) setPreview(v);
  });

  stars.addEventListener('change', () => {
    const v = parseInt(stars.value,10) || 5;
    starsRow.querySelectorAll('.s').forEach((el, idx) => {
      el.classList.toggle('on', (idx+1) <= v);
    });
  });

  document.getElementById('cancel').addEventListener('click', () => {
    parent.postMessage({ type:'BONZAI_TESTIMONIAL_CANCEL' }, '*');
  });

  document.getElementById('save').addEventListener('click', () => {
    const payload = {
      id: init.id,
      name: document.getElementById('name').value.trim(),
      date: document.getElementById('date').value.trim(),
      stars: parseInt(document.getElementById('stars').value,10) || 5,
      content: document.getElementById('content').value.trim(),
      photo: photo || ''
    };
    parent.postMessage({ type:'BONZAI_TESTIMONIAL_SAVE', payload }, '*');
  });

})();
</script>
</body>
</html>`
    );
  }

  function initManager($wrap) {
    var $textarea = $wrap.find('textarea');
    var $list = $wrap.find('.bonzai-admin-testimonials-list');
    var $empty = $wrap.find('.bonzai-admin-testimonials-empty');
    var items = safeParse($textarea.val()).map(normalizeItem);

    function markDirty() {
      // WooCommerce settings page: enable the main "Save changes" button and mark as changed.
      $textarea.trigger('change').trigger('input');
      var $save = $('p.submit button[name="save"], p.submit input[name="save"]').first();
      if ($save.length) {
        $save.prop('disabled', false).removeClass('disabled');
      }
      // Some WC versions listen for this event.
      $(document.body).trigger('wc-settings-changed');
    }

    function sync() {
      // keep order
      $textarea.val(JSON.stringify(items.map(function (it) {
        return { name: it.name, date: it.date, stars: it.stars, content: it.content, photo: it.photo };
      })));
      markDirty();
      render();
    }

    function render() {
      if (!items.length) {
        $list.empty();
        $empty.show();
        return;
      }
      $empty.hide();
      $list.html(items.map(buildCard).join(''));
    }

    function findIndex(id) {
      for (var i = 0; i < items.length; i++) if (items[i].id === id) return i;
      return -1;
    }

    $wrap.on('click', '.bonzai-admin-add', function () {
	      if (items.length >= 5) {
	        alert('Maximum 5 testimonials.');
	        return;
	      }
      openIframeModal({ isEdit: false, item: {} }, function (newItem) {
        if (!newItem.name || !newItem.content) return;
        items.push(newItem);
        sync();
      });
    });

    $wrap.on('click', '.bzt-edit', function () {
      var id = $(this).closest('.bzt-card').data('id');
      var idx = findIndex(id);
      if (idx < 0) return;
      openIframeModal({ isEdit: true, item: items[idx] }, function (updated) {
        if (!updated.name || !updated.content) return;
        updated.id = items[idx].id;
        items[idx] = updated;
        sync();
      });
    });

    $wrap.on('click', '.bzt-delete', function () {
      var id = $(this).closest('.bzt-card').data('id');
      var idx = findIndex(id);
      if (idx < 0) return;
      items.splice(idx, 1);
      sync();
    });

    // Simple drag & drop reorder (no external libs)
    var draggingId = null;

    $wrap.on('dragstart', '.bzt-card', function (e) {
      draggingId = $(this).data('id');
      e.originalEvent.dataTransfer.effectAllowed = 'move';
      $(this).addClass('is-dragging');
    });

    $wrap.on('dragend', '.bzt-card', function () {
      $(this).removeClass('is-dragging');
      draggingId = null;
    });

    $wrap.on('dragover', '.bzt-card', function (e) {
      e.preventDefault();
      if (!draggingId) return;
      e.originalEvent.dataTransfer.dropEffect = 'move';
      $(this).addClass('is-drop-target');
    });

    $wrap.on('dragleave', '.bzt-card', function () {
      $(this).removeClass('is-drop-target');
    });

    $wrap.on('drop', '.bzt-card', function (e) {
      e.preventDefault();
      var targetId = $(this).data('id');
      $(this).removeClass('is-drop-target');
      if (!draggingId || draggingId === targetId) return;

      var from = findIndex(draggingId);
      var to = findIndex(targetId);
      if (from < 0 || to < 0) return;

      var moved = items.splice(from, 1)[0];
      items.splice(to, 0, moved);
      sync();
    });

    // Make cards draggable
    $wrap.on('mouseenter', '.bzt-card', function () {
      $(this).attr('draggable', 'true');
    });

    render();
    // ensure initial sync to normalize
    $textarea.val(JSON.stringify(items.map(function (it) {
      return { name: it.name, date: it.date, stars: it.stars, content: it.content, photo: it.photo };
    })));
  }

  $(function () {
    $('.bonzai-admin-testimonials').each(function () {
      initManager($(this));
    });
  });
})(jQuery);
