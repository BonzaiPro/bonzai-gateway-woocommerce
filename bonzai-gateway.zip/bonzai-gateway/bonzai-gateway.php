<?php
/*
Plugin Name: Bonzai Payment Gateway
Description: Payment via Bonzai Checkout with confirmation webhooks and order sync.
Version: 1.7.2.6
Author: Ramy
Text Domain: bonzai-gateway
Domain Path: /languages
*/

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

if (!defined('BONZAI_PLUGIN_VERSION')) {
    define('BONZAI_PLUGIN_VERSION', '1.7.2.4');
}

// Internationalization.
add_action('plugins_loaded', function () {
    load_plugin_textdomain('bonzai-gateway', false, dirname(plugin_basename(__FILE__)) . '/languages');
});

/**
 * Admin assets (Testimonials manager in gateway settings).
 * Loaded only on WooCommerce > Settings > Payments > Bonzai.
 */
add_action('admin_enqueue_scripts', function ($hook) {
    // WooCommerce settings pages typically use this hook.
    if ($hook !== 'woocommerce_page_wc-settings') return;

    $tab = isset($_GET['tab']) ? sanitize_key((string) $_GET['tab']) : '';
    $section = isset($_GET['section']) ? sanitize_key((string) $_GET['section']) : '';

    // Historical: tab=checkout. Some WC versions may use tab=payments.
    if (!in_array($tab, array('checkout', 'payment', 'payments'), true)) return;
    if ($section !== 'bonzai') return;

    $plugin_url = plugin_dir_url(__FILE__);

    wp_enqueue_style(
        'bonzai-admin-testimonials',
        $plugin_url . 'assets/bonzai-admin-testimonials.css',
        array(),
        BONZAI_PLUGIN_VERSION
    );

    wp_enqueue_script(
        'bonzai-admin-testimonials',
        $plugin_url . 'assets/bonzai-admin-testimonials.js',
        array('jquery'),
        BONZAI_PLUGIN_VERSION,
        true
    );

    // Minimal i18n without requiring .mo files.
    $locale = function_exists('determine_locale') ? determine_locale() : get_locale();
    $lang = strtolower(substr((string) $locale, 0, 2));

    $i18n = array(
        'add' => __('Add a testimonial', 'bonzai-gateway'),
        'edit' => __('Edit testimonial', 'bonzai-gateway'),
        'delete' => __('Delete', 'bonzai-gateway'),
        'save' => __('Save', 'bonzai-gateway'),
        'cancel' => __('Cancel', 'bonzai-gateway'),
        'no_items' => __('No testimonials yet.', 'bonzai-gateway'),
        'profile_photo' => __('Profile photo', 'bonzai-gateway'),
        'image_url' => __('Image URL', 'bonzai-gateway'),
        'drop_here' => __('Or drop an image here', 'bonzai-gateway'),
        'name' => __('Name / Pseudo', 'bonzai-gateway'),
        'date' => __('Date', 'bonzai-gateway'),
        'rating' => __('Rating (1-5)', 'bonzai-gateway'),
        'content' => __('Testimonial', 'bonzai-gateway'),
        'upload' => __('Drag & drop or click to upload', 'bonzai-gateway'),
        'use_url' => __('Use image URL', 'bonzai-gateway'),
    );

    // Fallback strings when site language is ES/FR but no translation files exist.
    if ($lang === 'fr') {
        $i18n = array_merge($i18n, array(
            'add' => 'Ajouter un avis',
            'edit' => 'Modifier l\'avis',
            'delete' => 'Supprimer',
            'save' => 'Enregistrer',
            'cancel' => 'Annuler',
            'no_items' => 'Aucun avis pour le moment.',
            'profile_photo' => 'Photo de profil',
            'image_url' => 'URL de l\'image',
            'drop_here' => 'Ou déposez une image ici',
            'name' => 'Nom / Pseudo',
            'date' => 'Date',
            'rating' => 'Note (1-5)',
            'content' => 'Avis',
            'upload' => 'Glissez-déposez ou cliquez pour importer',
            'use_url' => 'Utiliser une URL d\'image',
        ));
    } elseif ($lang === 'es') {
        $i18n = array_merge($i18n, array(
            'add' => 'Añadir un testimonio',
            'edit' => 'Editar testimonio',
            'delete' => 'Eliminar',
            'save' => 'Guardar',
            'cancel' => 'Cancelar',
            'no_items' => 'Aún no hay testimonios.',
            'profile_photo' => 'Foto de perfil',
            'image_url' => 'URL de la imagen',
            'drop_here' => 'O suelta una imagen aquí',
            'name' => 'Nombre / Alias',
            'date' => 'Fecha',
            'rating' => 'Valoración (1-5)',
            'content' => 'Testimonio',
            'upload' => 'Arrastra y suelta o haz clic para subir',
            'use_url' => 'Usar URL de imagen',
        ));
    }

    wp_localize_script('bonzai-admin-testimonials', 'BONZAI_ADMIN_TESTIMONIALS', array(
        'i18n' => $i18n,
    ));
});

/**
 * Built-in fallback translations (no .mo required).
 * This ensures the special checkout page and gateway settings follow the site's language
 * even when the merchant hasn't installed translation files.
 */
function bonzai_get_fallback_translations(): array {
    $locale = function_exists('determine_locale') ? determine_locale() : get_locale();
    $lang = strtolower(substr((string) $locale, 0, 2));

    // Add languages as needed. Defaults to English (no mapping).
    if ($lang === 'fr') {
        return array(
            // Checkout page
            'Checkout' => 'Paiement',
            'To access the Bonzai payment form, please complete the required customer information below. The payment will open automatically once the required fields are valid.' => 'Pour accéder au formulaire de paiement Bonzai, veuillez compléter les informations client obligatoires ci-dessous. Le paiement s\'ouvrira automatiquement une fois les champs obligatoires valides.',
            'After payment, you will be redirected back to this store to see your order confirmation.' => 'Après le paiement, vous serez redirigé vers cette boutique pour voir la confirmation de votre commande.',
            'Billing details' => 'Informations de facturation',
            'First name' => 'Prénom',
            'Last name' => 'Nom',
            'Email' => 'E-mail',
            'Street address' => 'Adresse',
            'Apartment, suite, etc. (optional)' => 'Appartement, suite, etc. (optionnel)',
            'Postal code' => 'Code postal',
            'City' => 'Ville',
            'Country' => 'Pays',
            'State/Region' => 'État / Région',
            'Order summary' => 'Récapitulatif de la commande',
            'Loading secure payment...' => 'Chargement du paiement sécurisé...',
            'Opening secure payment...' => 'Ouverture du paiement sécurisé...',
            'Unable to load the payment. Please refresh and try again.' => 'Impossible de charger le paiement. Rafraîchissez la page et réessayez.',
            'Please complete the required fields to continue.' => 'Veuillez compléter les champs obligatoires pour continuer.',
            'Please enter a valid email address to continue.' => 'Veuillez saisir une adresse e-mail valide pour continuer.',
            'Please accept the terms and conditions to continue.' => 'Veuillez accepter les conditions générales pour continuer.',
            'I have read and agree to the terms and conditions.' => 'J\'ai lu et j\'accepte les conditions générales.',
            'View terms' => 'Voir les conditions',

            // Settings
            'Bonzai Checkout Page' => 'Page de paiement Bonzai',
            'Customize the /bonzai-checkout/ page (does not modify the iframe content).' => 'Personnalisez la page /bonzai-checkout/ (ne modifie pas le contenu de l\'iframe).',
            'Header' => 'En-tête',
            'Theme header/footer' => 'En-tête/pied du thème',
            'Minimal (plugin)' => 'Minimal (plugin)',
            'Use your theme header/footer for a consistent experience, or a minimal plugin-only layout.' => 'Utilisez l\'en-tête/pied de votre thème pour une expérience cohérente, ou une mise en page minimale gérée par le plugin.',
            'Layout' => 'Mise en page',
            'Two columns (form + summary)' => 'Deux colonnes (formulaire + récapitulatif)',
            'One column' => 'Une colonne',
            'Product thumbnails' => 'Miniatures produits',
            'Show product thumbnails' => 'Afficher les miniatures des produits',
            'Show order summary' => 'Afficher le récapitulatif de la commande',
            'Address line 2 field' => 'Champ d\'adresse (ligne 2)',
            'Show address line 2 (apartment, suite, etc.)' => 'Afficher la ligne d\'adresse 2 (appartement, suite, etc.)',
            'State/Region field' => 'Champ État / Région',
            'Show the state/region field' => 'Afficher le champ État / Région',            'Testimonials' => 'Avis clients',
            'Add a testimonial' => 'Ajouter un avis',
	            'Edit testimonial' => 'Modifier l\'avis',
            'Delete' => 'Supprimer',
            'Cancel' => 'Annuler',
            'Save' => 'Enregistrer',
            'Previous testimonial' => 'Avis précédent',
            'Next testimonial' => 'Avis suivant',

        );
    }

    if ($lang === 'es') {
        return array(
            // Checkout page
            'Checkout' => 'Pagar',
            'To access the Bonzai payment form, please complete the required customer information below. The payment will open automatically once the required fields are valid.' => 'Para acceder al formulario de pago de Bonzai, completa la información obligatoria del cliente a continuación. El pago se abrirá automáticamente cuando los campos obligatorios sean válidos.',
            'After payment, you will be redirected back to this store to see your order confirmation.' => 'Después del pago, serás redirigido de vuelta a esta tienda para ver la confirmación de tu pedido.',
            'Billing details' => 'Datos de facturación',
            'First name' => 'Nombre',
            'Last name' => 'Apellidos',
            'Email' => 'Correo electrónico',
            'Street address' => 'Dirección',
            'Apartment, suite, etc. (optional)' => 'Apartamento, suite, etc. (opcional)',
            'Postal code' => 'Código postal',
            'City' => 'Ciudad',
            'Country' => 'País',
            'State/Region' => 'Estado/Región',
            'Order summary' => 'Resumen del pedido',
            'Loading secure payment...' => 'Cargando pago seguro...',
            'Opening secure payment...' => 'Abriendo pago seguro...',
            'Unable to load the payment. Please refresh and try again.' => 'No se pudo cargar el pago. Actualiza la página e inténtalo de nuevo.',
            'Please complete the required fields to continue.' => 'Completa los campos obligatorios para continuar.',
            'Please enter a valid email address to continue.' => 'Introduce un correo electrónico válido para continuar.',
            'Please accept the terms and conditions to continue.' => 'Acepta los términos y condiciones para continuar.',
            'I have read and agree to the terms and conditions.' => 'He leído y acepto los términos y condiciones.',
            'View terms' => 'Ver términos',

            // Settings
            'Bonzai Checkout Page' => 'Página de pago de Bonzai',
            'Customize the /bonzai-checkout/ page (does not modify the iframe content).' => 'Personaliza la página /bonzai-checkout/ (no modifica el contenido del iframe).',
            'Header' => 'Encabezado',
            'Theme header/footer' => 'Encabezado/pie del tema',
            'Minimal (plugin)' => 'Mínimo (plugin)',
            'Use your theme header/footer for a consistent experience, or a minimal plugin-only layout.' => 'Usa el encabezado/pie de tu tema para una experiencia coherente, o un diseño mínimo del plugin.',
            'Layout' => 'Diseño',
            'Two columns (form + summary)' => 'Dos columnas (formulario + resumen)',
            'One column' => 'Una columna',
            'Product thumbnails' => 'Miniaturas de producto',
            'Show product thumbnails' => 'Mostrar miniaturas de producto',
            'Show order summary' => 'Mostrar resumen del pedido',
            'Address line 2 field' => 'Dirección (línea 2)',
            'Show address line 2 (apartment, suite, etc.)' => 'Mostrar dirección línea 2 (apartamento, suite, etc.)',
            'State/Region field' => 'Campo Estado/Región',
            'Show the state/region field' => 'Mostrar el campo de Estado/Región',            'Testimonials' => 'Testimonios',
            'Add a testimonial' => 'Añadir un testimonio',
            'Edit testimonial' => 'Editar testimonio',
            'Delete' => 'Eliminar',
            'Cancel' => 'Cancelar',
            'Save' => 'Guardar',
            'Profile photo' => 'Foto de perfil',
            'Image URL' => 'URL de la imagen',
            'Or drop an image here' => 'O suelta una imagen aquí',
            'Name / Pseudo' => 'Nombre / Pseudónimo',
            'Date' => 'Fecha',
            'Rating (1-5)' => 'Valoración (1-5)',
            'Testimonial' => 'Reseña',
            'No testimonials yet.' => 'Aún no hay testimonios.',
            'Drag & drop or click to upload' => 'Arrastra y suelta o haz clic para subir',
            'Use image URL' => 'Usar URL de imagen',
            'Optional' => 'Opcional',
            'Enabled' => 'Activado',
            'Show testimonials carousel' => 'Mostrar carrusel de testimonios',
            'Previous testimonial' => 'Testimonio anterior',
            'Next testimonial' => 'Siguiente testimonio',

        );
    }

    return array();
}

add_filter('gettext', function ($translation, $text, $domain) {
    if ($domain !== 'bonzai-gateway') return $translation;
    $map = bonzai_get_fallback_translations();
    return isset($map[$text]) ? $map[$text] : $translation;
}, 10, 3);

add_filter('gettext_with_context', function ($translation, $text, $context, $domain) {
    if ($domain !== 'bonzai-gateway') return $translation;
    $map = bonzai_get_fallback_translations();
    return isset($map[$text]) ? $map[$text] : $translation;
}, 10, 4);

/**
 * MODE A (Bonzai-only checkout):
 * - Cart "Proceed to checkout" always goes to /bonzai-checkout/
 * - Any direct hit to WooCommerce checkout (/checkout/) is redirected to /bonzai-checkout/
 * - The special checkout page is rendered by this plugin and then redirects to Bonzai.
 */
if (!defined('BONZAI_SPECIAL_CHECKOUT_SLUG')) {
    define('BONZAI_SPECIAL_CHECKOUT_SLUG', 'bonzai-checkout');
}

function bonzai_special_checkout_url(): string {
    return home_url('/' . BONZAI_SPECIAL_CHECKOUT_SLUG . '/');
}

function bonzai_is_special_checkout_request(): bool {
    if (get_query_var('bonzai_special_checkout') === '1') return true;
    $uri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '';
    return (bool) preg_match('#/' . preg_quote(BONZAI_SPECIAL_CHECKOUT_SLUG, '#') . '(/|\\?|$)#', $uri);
}

// Register rewrite + query var.
add_action('init', function () {
    add_rewrite_rule(
        '^' . BONZAI_SPECIAL_CHECKOUT_SLUG . '/?$',
        'index.php?bonzai_special_checkout=1',
        'top'
    );
});

add_filter('query_vars', function ($vars) {
    $vars[] = 'bonzai_special_checkout';
    return $vars;
});

/**
 * Ensure /bonzai-checkout/ works immediately even if rewrite rules were not flushed yet (plugin update).
 * - Hooks early into parse_request to mark this request as our special checkout.
 * - Also performs a one-time rewrite flush per plugin version to persist the rule.
 */
add_action('parse_request', function ($wp) {
    if (!is_object($wp) || !isset($wp->query_vars)) return;
    // If rewrite rules are not flushed yet, WordPress won't route /bonzai-checkout/ to our query var.
    // Detect by URL path and set the query var manually.
    $uri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '';
    if (!$uri) return;
    if (preg_match('#/' . preg_quote(BONZAI_SPECIAL_CHECKOUT_SLUG, '#') . '(/|\?|$)#', $uri)) {
        $wp->query_vars['bonzai_special_checkout'] = '1';
        // Prevent 404 canonical redirects.
        if (property_exists($wp, 'is_404')) $wp->is_404 = false;
        if (isset($wp->query_vars['error'])) unset($wp->query_vars['error']);
    }
}, 0);

add_action('init', function () {
    // On plugin updates, activation hook doesn't run, so rewrite rules may not include our endpoint yet.
    $current = defined('BONZAI_PLUGIN_VERSION') ? BONZAI_PLUGIN_VERSION : '1.6.4';
    $opt_key = 'bonzai_rewrite_flushed_version';
    $stored  = get_option($opt_key, '');
    if ($stored !== $current) {
        flush_rewrite_rules();
        update_option($opt_key, $current, false);
    }
}, 20);


// Flush rewrites on activation (important for /bonzai-checkout/ to work immediately).
register_activation_hook(__FILE__, function () {
    add_rewrite_rule(
        '^' . BONZAI_SPECIAL_CHECKOUT_SLUG . '/?$',
        'index.php?bonzai_special_checkout=1',
        'top'
    );
    flush_rewrite_rules();
});

register_deactivation_hook(__FILE__, function () {
    flush_rewrite_rules();
});

// Force checkout URL used by the cart "Proceed to checkout" button.
add_filter('woocommerce_get_checkout_url', function ($url) {
    if (is_admin()) return $url;
    if (!function_exists('WC') || !WC() || !WC()->cart) return $url;
    if (WC()->cart->is_empty()) return $url;
    return bonzai_special_checkout_url();
}, 50);

// Hard redirect if the visitor hits the WooCommerce checkout directly (Classic or Blocks).
add_action('template_redirect', function () {
    if (is_admin()) return;
    if (bonzai_is_special_checkout_request()) return;
    if (!function_exists('is_checkout') || !is_checkout()) return;

    // Allow order-pay + order-received.
    if (function_exists('is_wc_endpoint_url') && (is_wc_endpoint_url('order-received') || is_wc_endpoint_url('order-pay'))) {
        return;
    }

    if (function_exists('WC') && WC() && WC()->cart && WC()->cart->is_empty()) {
        return;
    }

    wp_safe_redirect(bonzai_special_checkout_url());
    exit;
}, 5);


/**
 * Render the Bonzai special checkout page under /bonzai-checkout/.
 * This is intentionally self-contained to work with Classic + Blocks stores
 * without depending on the theme's checkout templates.
 */
add_action('template_redirect', function () {
    if (is_admin()) return;
    if (!bonzai_is_special_checkout_request()) return;
    if (!function_exists('WC')) return;

    // Ensure cart is loaded.
    if (!WC()->cart || WC()->cart->is_empty()) {
        wp_safe_redirect(wc_get_cart_url());
        exit;
    }
    $settings = (array) get_option('woocommerce_bonzai_settings', array());

    $header_mode = isset($settings['sc_header_mode']) ? (string) $settings['sc_header_mode'] : 'theme';
    $layout      = isset($settings['sc_layout']) ? (string) $settings['sc_layout'] : 'two_columns';
    $show_summary = (isset($settings['sc_show_summary']) ? $settings['sc_show_summary'] : 'yes') === 'yes';
    $show_thumbs  = (isset($settings['sc_show_thumbnails']) ? $settings['sc_show_thumbnails'] : 'yes') === 'yes';

    // Read from gateway settings (source of truth).
    $testimonials_enabled = (isset($settings['sc_testimonials_enabled']) ? $settings['sc_testimonials_enabled'] : 'no') === 'yes';
    $testimonials_mode = sanitize_key((string) ($settings['sc_testimonials_mode'] ?? ''));

    // Validate mode from settings.
    if (!in_array($testimonials_mode, array('carousel', 'inline'), true)) {
        $testimonials_mode = '';
    }

    // Fallback to mirrored standalone options ONLY when settings are missing.
    $standalone_enabled = (string) get_option('bonzai_sc_testimonials_enabled', '');
    if (!isset($settings['sc_testimonials_enabled']) && ($standalone_enabled === 'yes' || $standalone_enabled === 'no')) {
        $testimonials_enabled = ($standalone_enabled === 'yes');
    }

    $standalone_mode = sanitize_key((string) get_option('bonzai_sc_testimonials_mode', ''));
    if ($testimonials_mode === '' && in_array($standalone_mode, array('carousel', 'inline'), true)) {
        $testimonials_mode = $standalone_mode;
    }

    // Final fallback.
    if ($testimonials_mode === '') {
        $testimonials_mode = 'carousel';
    }

    // Keep mirror in sync (helps if some environments read the standalone options elsewhere).
    if ($standalone_mode !== $testimonials_mode) {
        update_option('bonzai_sc_testimonials_mode', $testimonials_mode);
    }
    if (($standalone_enabled === 'yes' || $standalone_enabled === 'no') && (($standalone_enabled === 'yes') !== $testimonials_enabled)) {
        update_option('bonzai_sc_testimonials_enabled', $testimonials_enabled ? 'yes' : 'no');
    }
	    $testimonials = array();
    $testimonials_raw = (string) ($settings['sc_testimonials_json'] ?? '[]');
    $decoded_testimonials = json_decode($testimonials_raw, true);
    if ($testimonials_enabled && is_array($decoded_testimonials)) {
        foreach ($decoded_testimonials as $t) {
            if (!is_array($t)) continue;
            $name = sanitize_text_field((string) ($t['name'] ?? ''));
            $content = sanitize_textarea_field((string) ($t['content'] ?? ''));
            if ($name === '' || $content === '') continue;
            $date = sanitize_text_field((string) ($t['date'] ?? ''));
            $stars = (int) ($t['stars'] ?? 5);
            if ($stars < 1) $stars = 1;
            if ($stars > 5) $stars = 5;
            $photo = esc_url_raw((string) ($t['photo'] ?? ''));
            // Allow data URLs for small inline avatars.
            if ($photo && strpos($photo, 'data:image') === 0) {
                $photo = (string) $t['photo'];
            }
            $testimonials[] = array(
                'name' => $name,
                'date' => $date,
                'stars' => $stars,
                'content' => $content,
                'photo' => $photo,
            );
        }
    }

	    // Hard limit: max 5 testimonials (keep admin order).
	    if (!empty($testimonials)) {
	        $testimonials = array_slice($testimonials, 0, 5);
	    }

	    // Hard limit: max 5 testimonials, keep admin order.
	    if (!empty($testimonials)) {
	        $testimonials = array_slice($testimonials, 0, 5);
	    }
    if (empty($testimonials)) {
        $testimonials_enabled = false;
    }

    $max_width    = max(640, min(1400, (int) ($settings['sc_max_width'] ?? 1000)));
    $iframe_h     = max(420, min(1400, (int) ($settings['sc_iframe_height'] ?? 620)));
    $iframe_h_3ds = max(560, min(1600, (int) ($settings['sc_iframe_height_3ds'] ?? 860)));

    // Optional field visibility (core fields are always present).
    $show_address2 = (isset($settings['sc_show_address_2']) ? $settings['sc_show_address_2'] : 'yes') === 'yes';
    $show_state    = (isset($settings['sc_show_state']) ? $settings['sc_show_state'] : 'yes') === 'yes';

    $required_raw = (string) ($settings['sc_required_fields'] ?? 'first,last,email,address_1,city,postcode,country');
    $required_list = array_filter(array_map('trim', explode(',', strtolower($required_raw))));
    $allowed_required = array('first','last','email','address_1','address_2','city','postcode','country','state');
    $required_list = array_values(array_intersect($required_list, $allowed_required));

    // Core fields are always required for Bonzai.
    foreach (array('first','last','email','address_1','city','postcode','country') as $must) {
        if (!in_array($must, $required_list, true)) $required_list[] = $must;
    }
    $required_map = array();
    foreach ($allowed_required as $key) {
        $required_map[$key] = in_array($key, $required_list, true);
    }

    // If a field is hidden, it cannot be required.
    if (!$show_address2) {
        $required_map['address_2'] = false;
    }
    if (!$show_state) {
        $required_map['state'] = false;
    }

    // If a field is hidden, it cannot be required.
    if (!$show_address2) $required_map['address_2'] = false;
    if (!$show_state)    $required_map['state'] = false;

    $custom_fields = array();
    $custom_raw = (string) ($settings['sc_custom_fields_json'] ?? '[]');
    $decoded = json_decode($custom_raw, true);
    if (is_array($decoded)) {
        foreach ($decoded as $field) {
            if (!is_array($field)) continue;
            $key = isset($field['key']) ? sanitize_key((string) $field['key']) : '';
            if ($key === '') continue;
            $label = isset($field['label']) ? sanitize_text_field((string) $field['label']) : $key;
            $type = isset($field['type']) ? sanitize_key((string) $field['type']) : 'text';
            if (!in_array($type, array('text','email','tel','number','textarea','select'), true)) {
                $type = 'text';
            }
            $required = !empty($field['required']);
            $options = array();
            if ($type === 'select' && !empty($field['options']) && is_array($field['options'])) {
                foreach ($field['options'] as $opt) {
                    $options[] = sanitize_text_field((string) $opt);
                }
            }
            $custom_fields[] = array(
                'key' => $key,
                'label' => $label,
                'type' => $type,
                'required' => $required,
                'options' => $options,
            );
        }
    }

    // Special checkout uses INLINE embed on this page.
    $plugin_url = plugin_dir_url(__FILE__);
    wp_enqueue_style('bonzai-inline-ui', $plugin_url . 'assets/bonzai-inline.css', array(), '1.0.0');
    wp_enqueue_style('bonzai-special-checkout', $plugin_url . 'assets/bonzai-special-checkout.css', array(), BONZAI_PLUGIN_VERSION);
    wp_enqueue_script('bonzai-special-checkout', $plugin_url . 'assets/bonzai-special-checkout.js', array('jquery'), BONZAI_PLUGIN_VERSION, true);

    wp_localize_script('bonzai-special-checkout', 'BONZAI_SPECIAL', array(
        'rest'        => esc_url_raw(rest_url('bonzai/v1/order-status')),
        'nonce'       => wp_create_nonce('wp_rest'),
        'prepare_ajax'=> (class_exists('WC_AJAX') ? esc_url_raw(WC_AJAX::get_endpoint('bonzai_inline_prepare')) : ''),
        'required'    => $required_map,
        'custom_required_keys' => array_values(array_map(function($f){ return $f['required'] ? $f['key'] : null; }, $custom_fields)),
        'ui' => array(
            'max_width' => $max_width,
            'iframe_h'  => $iframe_h,
            'iframe_h_3ds' => $iframe_h_3ds,
        ),
        'i18n' => array(
            'loading' => __('Opening secure payment...', 'bonzai-gateway'),
            'loading_initial' => __('Loading secure payment...', 'bonzai-gateway'),
            'err_generic' => __('Unable to load the payment. Please refresh and try again.', 'bonzai-gateway'),
            'err_terms' => __('Please accept the terms and conditions to continue.', 'bonzai-gateway'),
            'err_state' => __('Please enter your state/region to continue.', 'bonzai-gateway'),
            'err_email' => __('Please enter a valid email address to continue.', 'bonzai-gateway'),
            'err_required' => __('Please complete the required fields to continue.', 'bonzai-gateway'),
        ),
    ));

    // Render the page.
    $terms_required = function_exists('wc_terms_and_conditions_checkbox_enabled') ? (bool) wc_terms_and_conditions_checkbox_enabled() : false;
    $terms_link = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('terms') : '';

    $prefill = array(
        'billing_first_name' => WC()->customer ? WC()->customer->get_billing_first_name() : '',
        'billing_last_name'  => WC()->customer ? WC()->customer->get_billing_last_name() : '',
        'billing_email'      => WC()->customer ? WC()->customer->get_billing_email() : '',
        'billing_address_1'  => WC()->customer ? WC()->customer->get_billing_address_1() : '',
        'billing_address_2'  => WC()->customer ? WC()->customer->get_billing_address_2() : '',
        'billing_city'       => WC()->customer ? WC()->customer->get_billing_city() : '',
        'billing_postcode'   => WC()->customer ? WC()->customer->get_billing_postcode() : '',
        'billing_state'      => WC()->customer ? WC()->customer->get_billing_state() : '',
        'billing_country'    => WC()->customer ? WC()->customer->get_billing_country() : WC()->countries->get_base_country(),
    );

    // Avoid showing opaque state codes (e.g. "DZ-06") as a suggested value.
    // Many stores store regions as ISO-like codes; for better UX, only prefill when it looks like a human label.
    if (isset($prefill['billing_state']) && is_string($prefill['billing_state'])) {
        $st = trim($prefill['billing_state']);
        if ($st !== '' && preg_match('/^[A-Z]{2}-[A-Z0-9]{1,5}$/', $st)) {
            $prefill['billing_state'] = '';
        }
    }

    status_header(200);
    nocache_headers();

    // IMPORTANT: capture $testimonials_mode in the closure. Without it, PHP treats the variable as undefined
    // inside the template, so the UI always falls back to the carousel branch.
    $content = function () use ($layout, $show_summary, $show_thumbs, $terms_required, $terms_link, $prefill, $required_map, $custom_fields, $max_width, $iframe_h, $iframe_h_3ds, $show_address2, $show_state, $testimonials_enabled, $testimonials, $testimonials_mode) {
        $wrap_style = '--bonzai-sc-max-width:' . (int) $max_width . 'px;--bonzai-sc-iframe-height:' . (int) $iframe_h . 'px;--bonzai-sc-iframe-height-3ds:' . (int) $iframe_h_3ds . 'px;';
        ?>
        <div class="bonzai-sc-wrap" style="<?php echo esc_attr($wrap_style); ?>">
            <div class="bonzai-sc-grid <?php echo $layout === 'one_column' ? 'is-one-col' : 'is-two-col'; ?> <?php echo $show_summary ? '' : 'no-summary'; ?>">
                <div class="bonzai-sc-card">
                    <h1 class="bonzai-sc-h"><?php echo esc_html(__('Checkout', 'bonzai-gateway')); ?></h1>
                    <p class="bonzai-sc-note"><?php echo esc_html(__('To access the Bonzai payment form, please complete the required customer information below. The payment will open automatically once the required fields are valid.', 'bonzai-gateway')); ?></p>

                    <form id="bonzai-sc-form" class="checkout" method="post" action="#" onsubmit="return false;">
                        <input type="hidden" name="payment_method" value="bonzai" />

                        <div class="bonzai-sc-row cols2">
                            <div class="bonzai-sc-field">
                                <label for="billing_first_name"><?php echo esc_html(__('First name', 'bonzai-gateway')); ?><?php echo $required_map['first'] ? ' *' : ''; ?></label>
                                <input id="billing_first_name" name="billing_first_name" autocomplete="given-name" <?php echo $required_map['first'] ? 'required' : ''; ?> value="<?php echo esc_attr($prefill['billing_first_name']); ?>" />
                            </div>
                            <div class="bonzai-sc-field">
                                <label for="billing_last_name"><?php echo esc_html(__('Last name', 'bonzai-gateway')); ?><?php echo $required_map['last'] ? ' *' : ''; ?></label>
                                <input id="billing_last_name" name="billing_last_name" autocomplete="family-name" <?php echo $required_map['last'] ? 'required' : ''; ?> value="<?php echo esc_attr($prefill['billing_last_name']); ?>" />
                            </div>
                        </div>

                        <div class="bonzai-sc-row">
                            <div class="bonzai-sc-field">
                                <label for="billing_email"><?php echo esc_html(__('Email', 'bonzai-gateway')); ?><?php echo $required_map['email'] ? ' *' : ''; ?></label>
                                <input id="billing_email" name="billing_email" type="email" autocomplete="email" <?php echo $required_map['email'] ? 'required' : ''; ?> value="<?php echo esc_attr($prefill['billing_email']); ?>" />
                            </div>
                        </div>

                        <div class="bonzai-sc-row">
                            <div class="bonzai-sc-field">
                                <label for="billing_address_1"><?php echo esc_html(__('Street address', 'bonzai-gateway')); ?><?php echo $required_map['address_1'] ? ' *' : ''; ?></label>
                                <input id="billing_address_1" name="billing_address_1" autocomplete="address-line1" <?php echo $required_map['address_1'] ? 'required' : ''; ?> value="<?php echo esc_attr($prefill['billing_address_1']); ?>" />
                            </div>
                            <?php if ($show_address2): ?>
                                <div class="bonzai-sc-field">
                                    <label for="billing_address_2"><?php echo esc_html(__('Apartment, suite, etc. (optional)', 'bonzai-gateway')); ?><?php echo $required_map['address_2'] ? ' *' : ''; ?></label>
                                    <input id="billing_address_2" name="billing_address_2" autocomplete="address-line2" <?php echo $required_map['address_2'] ? 'required' : ''; ?> value="<?php echo esc_attr($prefill['billing_address_2']); ?>" />
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="bonzai-sc-row cols2">
                            <div class="bonzai-sc-field">
                                <label for="billing_postcode"><?php echo esc_html(__('Postal code', 'bonzai-gateway')); ?><?php echo $required_map['postcode'] ? ' *' : ''; ?></label>
                                <input id="billing_postcode" name="billing_postcode" autocomplete="postal-code" <?php echo $required_map['postcode'] ? 'required' : ''; ?> value="<?php echo esc_attr($prefill['billing_postcode']); ?>" />
                            </div>
                            <div class="bonzai-sc-field">
                                <label for="billing_city"><?php echo esc_html(__('City', 'bonzai-gateway')); ?><?php echo $required_map['city'] ? ' *' : ''; ?></label>
                                <input id="billing_city" name="billing_city" autocomplete="address-level2" <?php echo $required_map['city'] ? 'required' : ''; ?> value="<?php echo esc_attr($prefill['billing_city']); ?>" />
                            </div>
                        </div>

                        <div class="bonzai-sc-row cols2">
                            <div class="bonzai-sc-field">
                                <label for="billing_country"><?php echo esc_html(__('Country', 'bonzai-gateway')); ?><?php echo $required_map['country'] ? ' *' : ''; ?></label>
                                <select id="billing_country" name="billing_country" <?php echo $required_map['country'] ? 'required' : ''; ?>>
                                    <?php foreach (WC()->countries->get_allowed_countries() as $code => $name): ?>
                                        <option value="<?php echo esc_attr($code); ?>" <?php selected($prefill['billing_country'], $code); ?>><?php echo esc_html($name); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php if ($show_state): ?>
                                <div class="bonzai-sc-field">
                                    <label for="billing_state"><?php echo esc_html(__('State/Region', 'bonzai-gateway')); ?><?php echo $required_map['state'] ? ' *' : ''; ?></label>
                                    <input id="billing_state" name="billing_state" autocomplete="address-level1" <?php echo $required_map['state'] ? 'required' : ''; ?> value="<?php echo esc_attr($prefill['billing_state']); ?>" />
                                </div>
                            <?php endif; ?>
                        </div>

                        <?php if (!empty($custom_fields)): ?>
                            <div class="bonzai-sc-custom">
                                <?php foreach ($custom_fields as $cf):
                                    $field_name = 'bonzai_cf_' . $cf['key'];
                                    $is_req = !empty($cf['required']);
                                ?>
                                    <div class="bonzai-sc-row">
                                        <div class="bonzai-sc-field">
                                            <label for="<?php echo esc_attr($field_name); ?>"><?php echo esc_html($cf['label']); ?><?php echo $is_req ? ' *' : ''; ?></label>
                                            <?php if ($cf['type'] === 'textarea'): ?>
                                                <textarea id="<?php echo esc_attr($field_name); ?>" name="<?php echo esc_attr($field_name); ?>" rows="3" <?php echo $is_req ? 'required data-bonzai-required="1"' : ''; ?>></textarea>
                                            <?php elseif ($cf['type'] === 'select'): ?>
                                                <select id="<?php echo esc_attr($field_name); ?>" name="<?php echo esc_attr($field_name); ?>" <?php echo $is_req ? 'required data-bonzai-required="1"' : ''; ?>>
                                                    <option value=""></option>
                                                    <?php foreach ($cf['options'] as $opt): ?>
                                                        <option value="<?php echo esc_attr($opt); ?>"><?php echo esc_html($opt); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            <?php else: ?>
                                                <input id="<?php echo esc_attr($field_name); ?>" name="<?php echo esc_attr($field_name); ?>" type="<?php echo esc_attr($cf['type']); ?>" <?php echo $is_req ? 'required data-bonzai-required="1"' : ''; ?> />
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                        <?php if ($terms_required): ?>
                            <label class="bonzai-sc-terms">
                                <input type="checkbox" name="terms" value="1" required />
                                <span><?php echo esc_html(__('I have read and agree to the terms and conditions.', 'bonzai-gateway')); ?><?php if ($terms_link): ?> <a href="<?php echo esc_url($terms_link); ?>" target="_blank" rel="noopener"><?php echo esc_html(__('View terms', 'bonzai-gateway')); ?></a><?php endif; ?></span>
                            </label>
                        <?php endif; ?>
                    </form>

                    <div id="bonzai-inline-container" class="is-hidden">
                        <div id="bonzai-inline-loading" style="display:none"><?php echo esc_html(__('Loading secure payment...', 'bonzai-gateway')); ?></div>
                        <div id="bonzai-inline-error" style="display:none"></div>
                        <iframe id="bonzai-inline-iframe" title="Bonzai secure payment" allow="payment *; clipboard-write *" style="display:none; width:100%; border:0;"></iframe>
                    </div>
                </div>

                <?php if ($show_summary): ?>
                    <aside class="bonzai-sc-card bonzai-sc-summary-card">
                        <h2 class="bonzai-sc-h"><?php echo esc_html(__('Order summary', 'bonzai-gateway')); ?></h2>
                        <div class="bonzai-sc-summary">
                            <?php foreach (WC()->cart->get_cart() as $cart_item):
                                $product = $cart_item['data'];
                                if (!$product) continue;
                                $name = $product->get_name();
                                $qty  = (int) $cart_item['quantity'];
                                $line = wc_price($cart_item['line_total'] + $cart_item['line_tax']);
                                $thumb = '';
                                if ($show_thumbs && $product->get_image_id()) {
                                    $thumb = wp_get_attachment_image($product->get_image_id(), array(56,56), false, array('class' => 'bonzai-sc-thumb'));
                                }
                            ?>
                                <div class="bonzai-sc-line">
                                    <div class="bonzai-sc-line-left">
                                        <?php if ($thumb) echo $thumb; ?>
                                        <span class="bonzai-sc-line-name"><?php echo esc_html($name); ?> <span class="bonzai-sc-line-qty">× <?php echo (int) $qty; ?></span></span>
                                    </div>
                                    <span class="bonzai-sc-line-price"><?php echo wp_kses_post($line); ?></span>
                                </div>
                            <?php endforeach; ?>
                            <div class="bonzai-sc-divider"></div>
                            <div class="bonzai-sc-line"><span><?php echo esc_html(__('Subtotal', 'bonzai-gateway')); ?></span><span><?php echo wp_kses_post(wc_price(WC()->cart->get_subtotal())); ?></span></div>
                            <div class="bonzai-sc-line"><span><?php echo esc_html(__('Shipping', 'bonzai-gateway')); ?></span><span><?php echo wp_kses_post(wc_price(WC()->cart->get_shipping_total())); ?></span></div>
                            <div class="bonzai-sc-total bonzai-sc-line"><span><?php echo esc_html(__('Total', 'bonzai-gateway')); ?></span><span><?php echo wp_kses_post(wc_price(WC()->cart->get_total('edit'))); ?></span></div>
                        </div>

	                        <?php if ($testimonials_enabled && !empty($testimonials)): ?>
	                            <div class="bonzai-sc-testimonials <?php echo ($testimonials_mode === 'inline') ? 'bonzai-is-inline' : 'bonzai-is-carousel'; ?>"
	                                 id="bonzai-sc-testimonials"
	                                 data-bonzai-count="<?php echo (int) count($testimonials); ?>"
	                                 data-bonzai-mode="<?php echo esc_attr($testimonials_mode); ?>">
	                                <div class="bonzai-sc-testimonials-head">
	                                    <h3 class="bonzai-sc-testimonials-title"><?php echo esc_html(__('Testimonials', 'bonzai-gateway')); ?></h3>
	                                </div>

	                                <?php if ($testimonials_mode === 'inline'): ?>
	                                    <div class="bonzai-sc-testimonials-inline">
	                                        <?php foreach ($testimonials as $t): ?>
	                                            <article class="bonzai-sc-testimonial">
	                                                <div class="bonzai-sc-testimonial-top">
	                                                    <?php if (!empty($t['photo'])): ?>
	                                                        <img class="bonzai-sc-testimonial-avatar" src="<?php echo esc_url($t['photo']); ?>" alt="<?php echo esc_attr($t['name']); ?>" loading="lazy" />
	                                                    <?php else: ?>
	                                                        <div class="bonzai-sc-testimonial-avatar is-placeholder" aria-hidden="true"></div>
	                                                    <?php endif; ?>
	                                                    <div class="bonzai-sc-testimonial-meta">
	                                                        <div class="bonzai-sc-testimonial-name"><?php echo esc_html($t['name']); ?></div>
	                                                        <?php if (!empty($t['date'])): ?>
	                                                            <div class="bonzai-sc-testimonial-date"><?php echo esc_html($t['date']); ?></div>
	                                                        <?php endif; ?>
	                                                    </div>
	                                                    <div class="bonzai-sc-testimonial-stars" aria-label="<?php echo esc_attr($t['stars']); ?> / 5">
	                                                        <?php for ($i=1;$i<=5;$i++): ?>
	                                                            <span class="bonzai-sc-star <?php echo $i <= (int) $t['stars'] ? 'is-on' : 'is-off'; ?>">★</span>
	                                                        <?php endfor; ?>
	                                                    </div>
	                                                </div>
	                                                <div class="bonzai-sc-testimonial-content"><?php echo esc_html($t['content']); ?></div>
	                                            </article>
	                                        <?php endforeach; ?>
	                                    </div>
	                                <?php else: ?>
	                                    <div class="bonzai-sc-testimonials-viewport">
	                                        <div class="bonzai-sc-testimonials-track">
	                                            <?php foreach ($testimonials as $t): ?>
	                                                <article class="bonzai-sc-testimonial">
	                                                    <div class="bonzai-sc-testimonial-top">
	                                                        <?php if (!empty($t['photo'])): ?>
	                                                            <img class="bonzai-sc-testimonial-avatar" src="<?php echo esc_url($t['photo']); ?>" alt="<?php echo esc_attr($t['name']); ?>" loading="lazy" />
	                                                        <?php else: ?>
	                                                            <div class="bonzai-sc-testimonial-avatar is-placeholder" aria-hidden="true"></div>
	                                                        <?php endif; ?>
	                                                        <div class="bonzai-sc-testimonial-meta">
	                                                            <div class="bonzai-sc-testimonial-name"><?php echo esc_html($t['name']); ?></div>
	                                                            <?php if (!empty($t['date'])): ?>
	                                                                <div class="bonzai-sc-testimonial-date"><?php echo esc_html($t['date']); ?></div>
	                                                            <?php endif; ?>
	                                                        </div>
	                                                        <div class="bonzai-sc-testimonial-stars" aria-label="<?php echo esc_attr($t['stars']); ?> / 5">
	                                                            <?php for ($i=1;$i<=5;$i++): ?>
	                                                                <span class="bonzai-sc-star <?php echo $i <= (int) $t['stars'] ? 'is-on' : 'is-off'; ?>">★</span>
	                                                            <?php endfor; ?>
	                                                        </div>
	                                                    </div>
	                                                    <div class="bonzai-sc-testimonial-content"><?php echo esc_html($t['content']); ?></div>
	                                                </article>
	                                            <?php endforeach; ?>
	                                        </div>
	                                    </div>
	                                    <div class="bonzai-sc-testimonials-dots" aria-hidden="true"></div>
	                                <?php endif; ?>
	                            </div>
	                        <?php endif; ?>

                        <p class="bonzai-sc-note"><?php echo esc_html(__('After payment, you will be redirected back to this store to see your order confirmation.', 'bonzai-gateway')); ?></p>
                    </aside>
                <?php endif; ?>
            </div>
        </div>
        <?php
    };

    if ($header_mode === 'theme' && function_exists('get_header') && function_exists('get_footer')) {
        get_header();
        $content();
        get_footer();
        exit;
    }

    ?><!doctype html>
    <html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo('charset'); ?>" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title><?php echo esc_html(get_bloginfo('name') . ' - ' . __('Checkout', 'bonzai-gateway')); ?></title>
        <?php wp_head(); ?>
    </head>
    <body <?php body_class(); ?>>
        <?php $content(); ?>
        <?php wp_footer(); ?>
    </body>
    </html>
    <?php
    exit;
}, 8);


// If the buyer returns with a wc_order param after paying on Bonzai, redirect to WooCommerce thank-you page.
add_action('template_redirect', function () {
    if (!function_exists('wc_get_order')) return;

    $order_id = 0;
    if (isset($_GET['wc_order'])) {
        $order_id = (int) $_GET['wc_order'];
    } elseif (isset($_GET['order_id'])) {
        $order_id = (int) $_GET['order_id'];
    }

    if ($order_id <= 0) return;

    $order = wc_get_order($order_id);
    if (!$order) return;

    // Only redirect when the order is paid to avoid looping on pending payments.
    if (method_exists($order, 'is_paid') && $order->is_paid()) {
        wp_safe_redirect($order->get_checkout_order_received_url());
        exit;
    }
}, 1);


// WooCommerce Blocks support (Checkout Block).
// Without this, the Bonzai gateway may not appear when merchants use the block based checkout.
add_action('woocommerce_blocks_loaded', function () {
    if (!class_exists('Automattic\\WooCommerce\\Blocks\\Payments\\Integrations\\AbstractPaymentMethodType')) {
        return;
    }

    // Register Bonzai payment method type for Blocks.
    add_action('woocommerce_blocks_payment_method_type_registration', function ($payment_method_registry) {
        if (!class_exists('Automattic\\WooCommerce\\Blocks\\Payments\\Integrations\\AbstractPaymentMethodType')) {
            return;
        }

        if (!class_exists('WC_Gateway_Bonzai_Blocks')) {
            class WC_Gateway_Bonzai_Blocks extends Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType {

                protected $name = 'bonzai';

                public function initialize() {
                    $this->settings = get_option('woocommerce_bonzai_settings', array());
                }

                public function is_active() {
                    $enabled = isset($this->settings['enabled']) ? $this->settings['enabled'] : 'no';
                    return $enabled === 'yes';
                }

                public function get_payment_method_script_handles() {
                    $handle = 'bonzai-gateway-blocks';

                    if (!wp_script_is($handle, 'registered')) {
                        wp_register_script(
                            $handle,
                            plugins_url('assets/bonzai-blocks.js', __FILE__),
                            array('wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities', 'wp-i18n'),
                            '1.0.0',
                            true
                        );
                    }

                    return array($handle);
                }

                public function get_payment_method_data() {
                    $title = isset($this->settings['title']) && $this->settings['title'] !== '' ? $this->settings['title'] : 'Bonzai';
                    $description = isset($this->settings['description']) ? $this->settings['description'] : '';

                    return array(
                        'title'       => $title,
                        'description' => $description,
                        // Declare support for Blocks.
                        'supports'    => array('products'),
                    );
                }
            }
        }

        $payment_method_registry->register(new WC_Gateway_Bonzai_Blocks());
    });
});

add_action('plugins_loaded', 'bonzai_init_gateway_class');

function bonzai_init_gateway_class() {

    class WC_Gateway_Bonzai extends WC_Payment_Gateway {

        protected $logger = null;

        public function __construct() {
            $this->id                 = 'bonzai';
            $this->icon               = '';
            $this->has_fields         = false;
            $this->method_title       = 'Bonzai';
            $this->method_description = 'Pay through Bonzai Checkout.';
            $this->supports           = array('products');

            $this->init_form_fields();
            $this->init_settings();

            $this->title               = $this->get_option('title');
            $this->description         = $this->get_option('description');
            $this->enabled             = $this->get_option('enabled');
            $this->api_token           = trim($this->get_option('api_token'));
            $this->product_uuid        = trim($this->get_option('product_uuid'));
            // NOTE: This plugin runs in Bonzai-only checkout mode (MODE A).
            // Redirects after payment always rely on WooCommerce's native order received URL.
            // Keep these properties defined for backward compatibility with earlier builds,
            // but they are not exposed as settings anymore.
            $this->popup_iframe        = 'no';
            $this->inline_iframe       = 'no';
            $this->debug               = wc_string_to_bool($this->get_option('debug', 'no'));
            $this->timeout             = absint($this->get_option('timeout', 20));
            $this->force_currency      = strtoupper(trim($this->get_option('force_currency', '')));
            $this->min_amount          = floatval($this->get_option('min_amount', 0));
            $this->webhook_token       = trim($this->get_option('webhook_token', ''));
            $this->is_vat_incl_default = $this->get_option('is_vat_incl_default', 'yes');
            $this->order_sync_enabled  = $this->get_option('order_sync_enabled', 'no');
            $this->order_sync_hour     = intval($this->get_option('order_sync_hour', 3));
            $this->order_sync_day      = strtolower($this->get_option('order_sync_day', 'monday'));

            if ($this->debug) {
                $this->logger = wc_get_logger();
            }

            add_action(
                'woocommerce_update_options_payment_gateways_' . $this->id,
                array($this, 'process_admin_options')
            );
        }

        public function init_form_fields() {
            $base_webhook_url = rest_url('bonzai/v1/webhook');

            $this->form_fields = array(
                'enabled' => array(
                    'title'   => __('Enable', 'bonzai-gateway'),
                    'type'    => 'checkbox',
                    'label'   => __('Enable Bonzai Checkout', 'bonzai-gateway'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title'       => __('Title', 'bonzai-gateway'),
                    'type'        => 'text',
                    'description' => __('Displayed title during checkout.', 'bonzai-gateway'),
                    'default'     => 'Pay with Bonzai',
                ),
                'description' => array(
                    'title'       => __('Description', 'bonzai-gateway'),
                    'type'        => 'textarea',
                    'default'     => __('You will be redirected to Bonzai to complete the payment.', 'bonzai-gateway'),
                ),

                'special_checkout_title' => array(
                    'title'       => __('Bonzai special checkout page', 'bonzai-gateway'),
                    'type'        => 'title',
                    'description' => __('Customize the /bonzai-checkout/ page (Bonzai-only checkout flow). This page hosts the embedded Bonzai payment iframe.', 'bonzai-gateway'),
                ),
                'sc_header_mode' => array(
                    'title'       => __('Header', 'bonzai-gateway'),
                    'type'        => 'select',
                    'default'     => 'theme',
                    'options'     => array(
                        'theme'   => __('Theme header/footer', 'bonzai-gateway'),
                        'minimal' => __('Minimal (plugin)', 'bonzai-gateway'),
                    ),
                    'description' => __('Use your theme header/footer for a consistent experience, or a minimal plugin-only layout.', 'bonzai-gateway'),
                ),
                'sc_layout' => array(
                    'title'       => __('Layout', 'bonzai-gateway'),
                    'type'        => 'select',
                    'default'     => 'two_columns',
                    'options'     => array(
                        'two_columns' => __('Two columns (form + summary)', 'bonzai-gateway'),
                        'one_column'  => __('One column', 'bonzai-gateway'),
                    ),
                ),
                'sc_show_thumbnails' => array(
                    'title'   => __('Product thumbnails in summary', 'bonzai-gateway'),
                    'type'    => 'checkbox',
                    'label'   => __('Show product thumbnails', 'bonzai-gateway'),
                    'default' => 'yes',
                ),
                'sc_show_summary' => array(
                    'title'   => __('Order summary', 'bonzai-gateway'),
                    'type'    => 'checkbox',
                    'label'   => __('Show order summary', 'bonzai-gateway'),
                    'default' => 'yes',
                ),
                'sc_testimonials_enabled' => array(
                    'title'   => __('Testimonials', 'bonzai-gateway'),
                    'type'    => 'checkbox',
	                    'label'   => __('Show testimonials', 'bonzai-gateway'),
                    'default' => 'no',
                ),
	                'sc_testimonials_mode' => array(
	                    'title'       => __('Testimonials display', 'bonzai-gateway'),
	                    'type'        => 'select',
	                    'default'     => 'carousel',
	                    'options'     => array(
	                        'carousel' => __('Carousel (auto)', 'bonzai-gateway'),
	                        'inline'   => __('Inline (stacked)', 'bonzai-gateway'),
	                    ),
	                    'description' => __('Choose how testimonials are displayed under the order summary.', 'bonzai-gateway'),
	                ),
                'sc_testimonials_json' => array(
                    'title'       => __('Testimonials', 'bonzai-gateway'),
                    'type'        => 'bonzai_testimonials',
                    'description' => __('Add, edit, and reorder testimonials displayed under the order summary on the Bonzai Checkout Page. If empty, the carousel is not shown.', 'bonzai-gateway'),
                    'default'     => '[]',
                ),
                'sc_max_width' => array(
                    'title'       => __('Content max width (px)', 'bonzai-gateway'),
                    'type'        => 'number',
                    'default'     => '1000',
                    'custom_attributes' => array('min' => '640', 'max' => '1400', 'step' => '10'),
                ),
                'sc_iframe_height' => array(
                    'title'       => __('Iframe height (px)', 'bonzai-gateway'),
                    'type'        => 'number',
                    'default'     => '620',
                    'custom_attributes' => array('min' => '420', 'max' => '1200', 'step' => '10'),
                    'description' => __('Default iframe height. Because the iframe is cross-domain, the plugin cannot auto-fit its height precisely.', 'bonzai-gateway'),
                ),
                'sc_iframe_height_3ds' => array(
                    'title'       => __('Iframe height during 3DS (px)', 'bonzai-gateway'),
                    'type'        => 'number',
                    'default'     => '860',
                    'custom_attributes' => array('min' => '560', 'max' => '1400', 'step' => '10'),
                ),
                'sc_show_address_2' => array(
                    'title'   => __('Address line 2 field', 'bonzai-gateway'),
                    'type'    => 'checkbox',
                    'label'   => __('Show address line 2 (apartment, suite, etc.)', 'bonzai-gateway'),
                    'default' => 'yes',
                    'description' => __('If disabled, Address line 2 will be removed from the special checkout page.', 'bonzai-gateway'),
                ),
                'sc_show_state' => array(
                    'title'   => __('State/Region field', 'bonzai-gateway'),
                    'type'    => 'checkbox',
                    'label'   => __('Show the state/region field', 'bonzai-gateway'),
                    'default' => 'yes',
                    'description' => __('Some stores do not require a state/region. If disabled, the field will be removed (and cannot be required).', 'bonzai-gateway'),
                ),
                'sc_required_fields' => array(
                    'title'       => __('Required fields (comma-separated)', 'bonzai-gateway'),
                    'type'        => 'text',
                    'default'     => 'first,last,email,address_1,city,postcode,country',
                    'description' => __('Controls which fields must be completed before the payment iframe is displayed. Allowed values: first,last,email,address_1,address_2,city,postcode,country,state', 'bonzai-gateway'),
                ),
                'sc_custom_fields_json' => array(
                    'title'       => __('Custom fields (JSON)', 'bonzai-gateway'),
                    'type'        => 'textarea',
                    'default'     => "[]",
                    'description' => __('Optional: add custom fields to the Bonzai checkout page. JSON example: [{"key":"company","label":"Company","type":"text","required":false},{"key":"vat","label":"VAT Number","type":"text","required":false}]. Keys are stored on the order meta and passed to Bonzai metadata.', 'bonzai-gateway'),
                ),
                'api_token' => array(
                    'title'       => __('API Token', 'bonzai-gateway'),
                    'type'        => 'password',
                    'description' => __('Your Bonzai API token (Bonzai Premium dashboard → API Tokens).', 'bonzai-gateway'),
                ),
                'product_uuid' => array(
                    'title'       => __('Bonzai Product UUID', 'bonzai-gateway'),
                    'type'        => 'text',
                    'description' => __('The Bonzai product UUID used for all WooCommerce purchases.', 'bonzai-gateway'),
                ),


'force_currency' => array(
                    'title'       => __('Currency sent to Bonzai', 'bonzai-gateway'),
                    'type'        => 'select',
                    'description' => __('If empty, WooCommerce currency will be used. Bonzai supports EUR or USD.', 'bonzai-gateway'),
                    'default'     => '',
                    'options'     => array(
                        ''    => __('Use WooCommerce currency', 'bonzai-gateway'),
                        'EUR' => __('Force EUR', 'bonzai-gateway'),
                        'USD' => __('Force USD', 'bonzai-gateway'),
                    ),
                ),
                'min_amount' => array(
                    'title'       => __('Minimum amount', 'bonzai-gateway'),
                    'type'        => 'number',
                    'description' => __('Minimum cart total required to enable this payment method. Set 0 to disable.', 'bonzai-gateway'),
                    'default'     => '0',
                    'custom_attributes' => array('step' => '0.01', 'min' => '0'),
                ),
                'timeout' => array(
                    'title'       => __('API Request Timeout (seconds)', 'bonzai-gateway'),
                    'type'        => 'number',
                    'default'     => '20',
                    'custom_attributes' => array('min' => '5', 'step' => '1'),
                ),
                'debug' => array(
                    'title'       => __('Debug Logs', 'bonzai-gateway'),
                    'type'        => 'checkbox',
                    'label'       => __('Enable logs (WooCommerce → Status → Logs)', 'bonzai-gateway'),
                    'default'     => 'no',
                ),

                'is_vat_incl_default' => array(
                    'title'       => __('Amounts include VAT?', 'bonzai-gateway'),
                    'type'        => 'select',
                    'description' => __('Default VAT handling for Bonzai amounts. Can be overridden per product.', 'bonzai-gateway'),
                    'default'     => 'yes',
                    'options'     => array(
                        'yes' => __('Yes, prices include VAT', 'bonzai-gateway'),
                        'no'  => __('No, prices are excl. VAT', 'bonzai-gateway'),
                    ),
                ),

                'order_sync_title' => array(
                    'title'       => __('Automatic Bonzai order sync', 'bonzai-gateway'),
                    'type'        => 'title',
                    'description' => __('Automatically call Bonzai Retrieve an order to keep WooCommerce orders in sync.', 'bonzai-gateway'),
                ),
                'order_sync_enabled' => array(
                    'title'       => __('Automatic sync frequency', 'bonzai-gateway'),
                    'type'        => 'select',
                    'default'     => 'no',
                    'options'     => array(
                        'no'     => __('Disabled', 'bonzai-gateway'),
                        'daily'  => __('Daily', 'bonzai-gateway'),
                        'weekly' => __('Weekly', 'bonzai-gateway'),
                    ),
                ),
                'order_sync_hour' => array(
                    'title'       => __('Sync hour (0 to 23)', 'bonzai-gateway'),
                    'type'        => 'number',
                    'default'     => '3',
                    'custom_attributes' => array('min' => '0', 'max' => '23', 'step' => '1'),
                    'description' => __('Hour of the day (server time) when the automatic sync should run.', 'bonzai-gateway'),
                ),
                'order_sync_day' => array(
                    'title'       => __('Sync weekday (weekly sync)', 'bonzai-gateway'),
                    'type'        => 'select',
                    'default'     => 'monday',
                    'options'     => array(
                        'monday'    => __('Monday', 'bonzai-gateway'),
                        'tuesday'   => __('Tuesday', 'bonzai-gateway'),
                        'wednesday' => __('Wednesday', 'bonzai-gateway'),
                        'thursday'  => __('Thursday', 'bonzai-gateway'),
                        'friday'    => __('Friday', 'bonzai-gateway'),
                        'saturday'  => __('Saturday', 'bonzai-gateway'),
                        'sunday'    => __('Sunday', 'bonzai-gateway'),
                    ),
                ),

                'webhook_title' => array(
                    'title'       => __('Bonzai Webhooks', 'bonzai-gateway'),
                    'type'        => 'title',
                    'description' => __('Bonzai sends product_access_granted and product_access_revoked. Secured using a token.', 'bonzai-gateway'),
                ),
                'webhook_token' => array(
                    'title'       => __('Webhook Token', 'bonzai-gateway'),
                    'type'        => 'text',
                    'description' => __('Generate a token, save changes, then paste the webhook URL in Bonzai Premium Webhooks:', 'bonzai-gateway') . ' <code>' . esc_html($base_webhook_url) . '?token=YOUR_TOKEN</code>.',
                ),
            );
        }

        /**
         * Save gateway settings and mirror some values into standalone options used by the special checkout UI.
         */
        public function process_admin_options() {
            $saved = parent::process_admin_options();

            // Read freshly submitted values from POST (more reliable than get_option() right after save).
            $mode_key = $this->get_field_key('sc_testimonials_mode');
            $enabled_key = $this->get_field_key('sc_testimonials_enabled');

            $posted_mode = isset($_POST[$mode_key]) ? sanitize_key(wp_unslash($_POST[$mode_key])) : '';
            $posted_enabled = isset($_POST[$enabled_key]) ? sanitize_key(wp_unslash($_POST[$enabled_key])) : 'no';

            $mode = $posted_mode !== '' ? $posted_mode : sanitize_key((string) $this->get_option('sc_testimonials_mode', 'carousel'));
            if (!in_array($mode, array('carousel', 'inline'), true)) {
                $mode = 'carousel';
            }

            $enabled = ($posted_enabled === 'yes' || $posted_enabled === '1' || $posted_enabled === 'on') ? 'yes' : 'no';

            // Mirror settings for the special checkout testimonials display.
            update_option('bonzai_sc_testimonials_mode', $mode);
            update_option('bonzai_sc_testimonials_enabled', $enabled);

            return $saved;
        }





        /**
         * Custom admin field: Testimonials manager.
         */
        public function generate_bonzai_testimonials_html($key, $data) {
            $field_key = $this->get_field_key($key);
            $defaults = array(
                'title'       => '',
                'description' => '',
                'default'     => '[]',
            );
            $data = wp_parse_args($data, $defaults);

            $value = (string) $this->get_option($key, $data['default']);
            if ($value === '') $value = '[]';

            ob_start();
            ?>
            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="<?php echo esc_attr($field_key); ?>"><?php echo esc_html($data['title']); ?></label>
                </th>
                <td class="forminp">
                    <?php if (!empty($data['description'])): ?>
                        <p class="description"><?php echo wp_kses_post($data['description']); ?></p>
                    <?php endif; ?>

                    <div class="bonzai-admin-testimonials" data-field="<?php echo esc_attr($field_key); ?>">
                        <div class="bonzai-admin-testimonials-toolbar">
                            <button type="button" class="button button-primary bonzai-admin-add"><?php echo esc_html(__('Add a testimonial', 'bonzai-gateway')); ?></button>
                        </div>

                        <div class="bonzai-admin-testimonials-list" aria-live="polite"></div>

                        <textarea
                            id="<?php echo esc_attr($field_key); ?>"
                            name="<?php echo esc_attr($field_key); ?>"
                            style="display:none"
                            rows="6"
                        ><?php echo esc_textarea($value); ?></textarea>

                        <p class="description bonzai-admin-testimonials-empty" style="display:none"><?php echo esc_html(__('No testimonials yet.', 'bonzai-gateway')); ?></p>
                    </div>
                </td>
            </tr>
            <?php
            return ob_get_clean();
        }

        public function validate_bonzai_testimonials_field($key, $value) {
            $raw = is_string($value) ? $value : '';
            // WC/WordPress submits POST values slashed. Unsplash before decoding JSON.
            $raw = wp_unslash($raw);
            $decoded = json_decode($raw, true);
            if (!is_array($decoded)) {
                return '[]';
            }
            $out = array();
            foreach ($decoded as $t) {
                if (!is_array($t)) continue;
                $name = sanitize_text_field((string) ($t['name'] ?? ''));
                $content = sanitize_textarea_field((string) ($t['content'] ?? ''));
                if ($name === '' || $content === '') continue;
                $date = sanitize_text_field((string) ($t['date'] ?? ''));
                $stars = (int) ($t['stars'] ?? 5);
                if ($stars < 1) $stars = 1;
                if ($stars > 5) $stars = 5;
                $photo = (string) ($t['photo'] ?? '');
                $photo_url = '';
                if ($photo && strpos($photo, 'data:image') === 0) {
                    // Keep inline images as-is (admin already controlled).
                    $photo_url = $photo;
                } else {
                    $photo_url = esc_url_raw($photo);
                }
                $out[] = array(
                    'name' => $name,
                    'date' => $date,
                    'stars' => $stars,
                    'content' => $content,
                    'photo' => $photo_url,
                );
            }
            return wp_json_encode($out);
        }



        public function is_available() {
            if ('yes' !== $this->enabled) return false;
            if (empty($this->api_token)) return false;

            $currency = get_woocommerce_currency();
            $target   = $this->force_currency ? $this->force_currency : $currency;

            if (!in_array($target, array('EUR', 'USD'), true)) return false;

            if (function_exists('WC') && WC()->cart) {
                $total = floatval(WC()->cart->total);
                if ($this->min_amount > 0 && $total < $this->min_amount) return false;
            }

            return parent::is_available();
        }

        protected function log($message, $context = array()) {
            if ($this->logger) {
                $this->logger->info('[Bonzai] ' . $message, array('source' => 'bonzai_gateway') + $context);
            }
        }

        protected function fail_with_notice(WC_Order $order, $msg) {
            wc_add_notice($msg, 'error');
            if ($order instanceof WC_Order) {
                $order->add_order_note('Bonzai: ' . $msg);
            }
            $this->log('Error: ' . $msg);
            return array('result' => 'fail');
        }

        public function admin_options() {
            parent::admin_options();
            ?>
            <script type="text/javascript">
            (function($){
                $(function(){
                    var $tokenField = $('#woocommerce_bonzai_webhook_token');
                    if (!$tokenField.length) return;

                    var $btn = $('<button type="button" class="button" style="margin-left:8px;">Generate token</button>');
                    $btn.insertAfter($tokenField);

                    $btn.on('click', function(e){
                        e.preventDefault();

                        var token = '';
                        while (token.length < 32) {
                            token += Math.random().toString(36).substring(2);
                        }
                        token = token.substring(0, 32);

                        $tokenField.val(token);
                        $tokenField.trigger('change');

                        var $form = $tokenField.closest('form');
                        if ($form.length) {
                            $form.trigger('change');
                        }
                    });
                });
            })(jQuery);
            </script>
            <?php
        }

        public function process_payment($order_id) {

            $order = wc_get_order($order_id);
            if (!$order) return array('result' => 'fail');

            if (empty($this->api_token)) {
                return $this->fail_with_notice(
                    $order,
                    'Missing Bonzai API Token. Go to WooCommerce → Payments → Bonzai → Manage.'
                );
            }

            if (empty($this->product_uuid)) {
                return $this->fail_with_notice(
                    $order,
                    'Missing Bonzai Product UUID. Add it in WooCommerce → Payments → Bonzai → Manage.'
                );
            }

            $product_uuid = $this->product_uuid;

            $amount = (float) $order->get_total();
            if ($amount <= 0) {
                return $this->fail_with_notice($order, 'Invalid order amount.');
            }

            $currency = $this->force_currency ? $this->force_currency : get_woocommerce_currency();
            if (!in_array($currency, array('EUR', 'USD'), true)) {
                $currency = 'EUR';
            }

            $email        = $order->get_billing_email() ?: '';
            // Always use WooCommerce native thank-you URL (includes order key) so the
            // payment flow returns to WooCommerce regardless of checkout type.
            $redirect_url = $order->get_checkout_order_received_url();

            $items        = $order->get_items('line_item');
            $product_name = '';
            $item_count   = is_array($items) ? count($items) : 0;

            $is_vat_incl = ($this->is_vat_incl_default === 'yes');
            $mode        = 'one_off';
            $interval    = null;

            if ($item_count > 0 && is_array($items)) {
                foreach ($items as $item) {
                    $product_name = $item->get_name();
                    $product_id   = $item->get_product_id();
                    $product      = $product_id ? wc_get_product($product_id) : null;

                    if ($product_id) {
                        $override_vat = get_post_meta($product_id, 'bonzai_is_vat_incl', true);
                        if ($override_vat === 'yes') $is_vat_incl = true;
                        if ($override_vat === 'no')  $is_vat_incl = false;
                    }

                    $product_mode = $product_id ? get_post_meta($product_id, 'bonzai_payment_mode', true) : '';

                    if ($product && empty($product_mode)) {
                        if (class_exists('WC_Product_Subscription') && $product instanceof WC_Product_Subscription) {
                            $product_mode = 'subscription_auto';
                        } elseif (class_exists('WC_Product_Variable_Subscription') && $product instanceof WC_Product_Variable_Subscription) {
                            $product_mode = 'subscription_auto';
                        }
                    }

                    if ($product_mode === 'subscription_monthly') {
                        $mode     = 'subscription';
                        $interval = 'month';
                    } elseif ($product_mode === 'subscription_yearly') {
                        $mode     = 'subscription';
                        $interval = 'year';
                    } elseif ($product_mode === 'subscription_auto') {
                        $mode = 'subscription';
                        if ($product && is_callable(array($product, 'get_billing_period'))) {
                            $period = (string) $product->get_billing_period();
                            if ($period === 'year') {
                                $interval = 'year';
                            } else {
                                $interval = 'month';
                            }
                        } else {
                            $interval = 'month';
                        }
                    } else {
                        $mode     = 'one_off';
                        $interval = null;
                    }

                    break;
                }
            }

            if ($product_name) {
                if ($item_count > 1) {
                    $bonzai_title = sprintf('%s (+%d more items)', $product_name, $item_count - 1);
                } else {
                    $bonzai_title = $product_name;
                }
            } else {
                $bonzai_title = 'WooCommerce Order #' . $order->get_order_number();
            }

            $payload = array(
                'amount'       => round($amount, 2),
                'currency'     => $currency,
                'title'        => $bonzai_title,
                'redirect_url' => $redirect_url,
                'metadata'     => array(
                    'wc_order_id' => $order->get_id(),
                    'site'        => home_url(),
                ),
                'is_vat_incl'  => (bool) $is_vat_incl,
                'mode'         => $mode,
            );

            if ($interval && $mode === 'subscription') {
                $payload['interval'] = $interval;
            }

            if (!empty($email)) {
                $payload['email'] = sanitize_email($email);
            }

            // Prefill customer identity on Bonzai checkout (optional fields).
            $first_name = method_exists($order, 'get_billing_first_name') ? (string) $order->get_billing_first_name() : '';
            $last_name  = method_exists($order, 'get_billing_last_name') ? (string) $order->get_billing_last_name() : '';
            if (!empty($first_name)) {
                $payload['firstname'] = sanitize_text_field($first_name);
            }
            if (!empty($last_name)) {
                $payload['lastname'] = sanitize_text_field($last_name);
            }

            $this->log('Calling Bonzai checkout: ' . wp_json_encode($payload));

            $response = wp_remote_post("https://www.bonzai.pro/api/v1/products/$product_uuid/checkout", array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $this->api_token,
                    'Content-Type'  => 'application/json',
                ),
                'body'    => wp_json_encode($payload),
                'timeout' => max(5, $this->timeout),
            ));

            if (is_wp_error($response)) {
                return $this->fail_with_notice($order, 'Bonzai API error: ' . $response->get_error_message());
            }

            $code_http = (int) wp_remote_retrieve_response_code($response);
            $body_txt  = (string) wp_remote_retrieve_body($response);
            $body      = json_decode($body_txt, true);

            $this->log('Bonzai checkout response HTTP ' . $code_http . ' body=' . $body_txt);

            $bonzai_error_msg = '';
            if (is_array($body)) {
                if (!empty($body['message'])) {
                    $bonzai_error_msg = (string) $body['message'];
                } elseif (!empty($body['errors']) && is_array($body['errors'])) {
                    foreach ($body['errors'] as $field => $messages) {
                        if (is_array($messages) && !empty($messages)) {
                            $bonzai_error_msg = (string) $field . ': ' . (string) reset($messages);
                            break;
                        }
                    }
                }
            }

            if ($code_http < 200 || $code_http >= 300 || !is_array($body) || empty($body['checkout_url'])) {
                $note = 'Bonzai API HTTP ' . $code_http . ' -> ' . $body_txt;
                $order->add_order_note($note);

                $human_msg = 'Unable to create Bonzai payment.';
                if ($bonzai_error_msg) {
                    $human_msg .= ' Bonzai says: ' . $bonzai_error_msg;
                } else {
                    $human_msg .= ' Please try again later.';
                }

                return $this->fail_with_notice($order, $human_msg);
            }

            $order->update_status('pending', 'Waiting for Bonzai payment.');
            $order->add_order_note('Redirecting to Bonzai. Bonzai order_id: ' . ($body['order_id'] ?? 'n/a'));

            $this->log('Redirect URL: ' . $body['checkout_url']);

            if (!empty($body['order_id'])) {
                // Use WooCommerce order meta API (HPOS compatible).
                $order->update_meta_data('_bonzai_order_id', sanitize_text_field($body['order_id']));
                $order->add_order_note('Bonzai: order_id linked ' . $body['order_id']);
            }

// Store URLs (HPOS compatible).
$order->update_meta_data('_bonzai_checkout_url', esc_url_raw($body['checkout_url']));
if (!empty($body['embed_url'])) {
    $order->update_meta_data('_bonzai_embed_url', esc_url_raw($body['embed_url']));
}

// Persist meta changes before redirecting.
$order->save();

// Inline (iframe) mode: keep the customer on the checkout page and render the Bonzai payment UI inline.
// We return a redirect to the SAME checkout URL with a hash.
if (isset($this->inline_iframe) && $this->inline_iframe === 'yes') {
    $iframe_url = !empty($body['embed_url']) ? $body['embed_url'] : $body['checkout_url'];

    // Store for the frontend (AJAX fetch) so we can render inline without leaving the checkout page.
	if (function_exists('WC') && WC() && WC()->session) {
		// Reuse the existing session keys used by the "popup session" AJAX endpoint.
		WC()->session->set('bonzai_popup_iframe_url', esc_url_raw($iframe_url));
		WC()->session->set('bonzai_popup_thankyou', esc_url_raw($this->get_return_url($order)));
		WC()->session->set('bonzai_popup_order_id', (int) $order->get_id());
	}

    $checkout_url = '';
    if (!empty($_POST['bonzai_checkout_page_url'])) {
        $checkout_url = esc_url_raw(wp_unslash($_POST['bonzai_checkout_page_url']));
    }
    if (empty($checkout_url) && function_exists('WC') && WC() && WC()->session) {
        $session_url = WC()->session->get('bonzai_checkout_page_url');
        if (!empty($session_url)) {
            $checkout_url = esc_url_raw($session_url);
        }
    }
    if (empty($checkout_url)) {
        $checkout_url = wc_get_checkout_url();
    }

    return array(
        'result'   => 'success',
        'redirect' => $checkout_url . '#bonzai-inline',
    );
}

// Popup (iframe) mode: keep the customer on the checkout page and open a modal iframe.
// We return a redirect to the SAME checkout URL with a hash. This prevents a full page change,
// even on sites where WooCommerce checkout interception is unreliable.
if ($this->popup_iframe === 'yes') {
    $iframe_url = !empty($body['embed_url']) ? $body['embed_url'] : $body['checkout_url'];

    // Store for the frontend (AJAX fetch) so we can open the modal without leaving the checkout page.
    if (function_exists('WC') && WC()->session) {
					// Reuse the existing session keys used by the wc-ajax endpoint (bonzai_popup_session).
					WC()->session->set('bonzai_popup_iframe_url', esc_url_raw($iframe_url));
					WC()->session->set('bonzai_popup_thankyou', esc_url_raw($this->get_return_url($order)));
					WC()->session->set('bonzai_popup_order_id', (int) $order->get_id());
    }

    // Stay on the current checkout page (works with custom checkout pages/builders).
// IMPORTANT: wp_get_referer() can be the wc-ajax endpoint (update_order_review), so we prefer an explicit
// URL passed from the checkout page (front-end) to avoid redirecting to wc-ajax URLs (which can 403).
$checkout_url = '';

// 1) Prefer the explicit URL passed from the browser.
if (!empty($_POST['bonzai_checkout_page_url'])) {
    $checkout_url = esc_url_raw(wp_unslash($_POST['bonzai_checkout_page_url']));
}

// 2) Fallback to session (captured during template render), which is more reliable with checkout builders.
if (empty($checkout_url) && function_exists('WC') && WC() && WC()->session) {
    $session_url = WC()->session->get('bonzai_checkout_page_url');
    if (!empty($session_url)) {
        $checkout_url = esc_url_raw($session_url);
    }
}

// 3) Final fallback: WooCommerce configured checkout page.
if (empty($checkout_url)) {
    $checkout_url = wc_get_checkout_url();
}

// Only allow same-origin URLs (protect against open redirects).
$home_host = parse_url(home_url('/'), PHP_URL_HOST);
$url_host  = parse_url($checkout_url, PHP_URL_HOST);
if (!$home_host || !$url_host || strtolower($home_host) !== strtolower($url_host)) {
    $checkout_url = wc_get_checkout_url();
}

// Remove any wc-ajax param if present and drop existing hash.
$checkout_url = remove_query_arg('wc-ajax', $checkout_url);
$checkout_url = preg_replace('/#.*$/', '', $checkout_url);

// Hash-only change so the customer stays on the same page.
$hash = ($this->inline_iframe === 'yes') ? '#bonzai-inline' : '#bonzai';
$checkout_url = $checkout_url . $hash;

    return array(
        'result'           => 'success',
        'redirect'         => esc_url_raw($checkout_url),
        'bonzai_wc_order'  => (int) $order->get_id(),
        'bonzai_order_key' => (string) $order->get_order_key(),
        'bonzai_thankyou'  => esc_url_raw($this->get_return_url($order)),
        'bonzai_embed_url' => esc_url_raw($iframe_url),
    );
}

            return array(
                'result'   => 'success',
                'redirect' => esc_url_raw($body['checkout_url']),
            );
        }
    }
}



/**
 * Popup checkout mode (iframe)
 * Adds an endpoint under the merchant domain:
 *   /bonzai/popup/{order_id}/{order_key}
 * which renders a minimal page that opens Bonzai checkout in a full-screen modal iframe.
 *
 * This avoids relying on WooCommerce redirect interception (which varies across themes/builders/blocks).
 */

register_activation_hook(__FILE__, 'bonzai_gateway_activate');
register_deactivation_hook(__FILE__, 'bonzai_gateway_deactivate');

function bonzai_gateway_activate() {
    bonzai_gateway_add_rewrite_rules();
    flush_rewrite_rules();
}

function bonzai_gateway_deactivate() {
    flush_rewrite_rules();
}



// Persist the real checkout page URL in the WooCommerce session so we can reliably redirect back to it
// after placing the order (even when the actual checkout submission happens via wc-ajax endpoints).
add_action('template_redirect', function () {
    if (is_admin() || !function_exists('WC') || !WC() || !WC()->session) {
        return;
    }

    $is_checkout_like = function_exists('is_checkout') && is_checkout();
    $is_cartflows_checkout = isset($_GET['wcf_checkout_id']);
    $looks_like_checkout_path = isset($_SERVER['REQUEST_URI']) && (strpos($_SERVER['REQUEST_URI'], 'checkout') !== false);

    if (!$is_checkout_like && !$is_cartflows_checkout && !$looks_like_checkout_path) {
        return;
    }

    $scheme = is_ssl() ? 'https' : 'http';
    $host   = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
    $uri    = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';

    if (empty($host)) {
        return;
    }

    $url = $scheme . '://' . $host . $uri;

    // Strip fragments and wc-ajax query param if present.
    $url = preg_replace('/#.*$/', '', $url);
    if (function_exists('remove_query_arg')) {
        $url = remove_query_arg('wc-ajax', $url);
    }

    // WC session might not be initialized on some non-standard checkout pages.
    if (function_exists('WC') && WC() && isset(WC()->session) && WC()->session) {
        WC()->session->set('bonzai_checkout_page_url', $url);
    }
}, 1);

add_action('wp_enqueue_scripts', function () {
    // Load embedded UI assets on checkout-like pages.
    if (is_admin()) return;
    if (!class_exists('WooCommerce')) return;

    $settings  = get_option('woocommerce_bonzai_settings', array());
    $inline_on = isset($settings['inline_iframe']) ? ($settings['inline_iframe'] === 'yes') : false;
    $popup_on  = isset($settings['popup_iframe']) ? ($settings['popup_iframe'] === 'yes') : false;

    // Inline has priority over popup.
    if (!$inline_on && !$popup_on) {
        return;
    }

    $plugin_url = plugin_dir_url(__FILE__);

    if ($inline_on) {
        wp_enqueue_script('bonzai-inline', $plugin_url . 'assets/bonzai-inline.js', array('jquery'), '1.0.0', true);
        wp_enqueue_style('bonzai-inline-ui', $plugin_url . 'assets/bonzai-inline.css', array(), '1.0.0');
        wp_localize_script('bonzai-inline', 'BONZAI_INLINE', array(
            'rest' => esc_url_raw(rest_url('bonzai/v1/order-status')),
            'nonce' => wp_create_nonce('wp_rest'),
            'session_ajax' => (class_exists('WC_AJAX') ? esc_url_raw(WC_AJAX::get_endpoint('bonzai_popup_session')) : ''),
            'prepare_ajax' => (class_exists('WC_AJAX') ? esc_url_raw(WC_AJAX::get_endpoint('bonzai_inline_prepare')) : ''),
            'gateway_id'   => 'bonzai',
            'hash'         => '#bonzai-inline',
        ));
        return;
    }

    // Popup fallback.
    wp_enqueue_script('bonzai-popup', $plugin_url . 'assets/bonzai-popup.js', array('jquery'), '1.0.0', true);
    wp_enqueue_style('bonzai-popup-ui', $plugin_url . 'assets/bonzai-popup.css', array(), '1.0.0');
    wp_localize_script('bonzai-popup', 'BONZAI_POPUP', array(
        'rest' => esc_url_raw(rest_url('bonzai/v1/order-status')),
        'nonce' => wp_create_nonce('wp_rest'),
        'session_ajax' => (class_exists('WC_AJAX') ? esc_url_raw(WC_AJAX::get_endpoint('bonzai_popup_session')) : ''),
    ));
});

add_action('rest_api_init', function () {
    register_rest_route('bonzai/v1', '/order-status', array(
        'methods'  => 'GET',
        'callback' => function (\WP_REST_Request $req) {
            $order_id  = (int) $req->get_param('order_id');
            $order_key = (string) $req->get_param('order_key');

            if ($order_id <= 0 || $order_key === '') {
                return new \WP_REST_Response(array('ok' => false, 'error' => 'missing_params'), 400);
            }

            $order = wc_get_order($order_id);
            if (!$order) {
                return new \WP_REST_Response(array('ok' => false, 'error' => 'order_not_found'), 404);
            }

            if (!hash_equals((string) $order->get_order_key(), $order_key)) {
                return new \WP_REST_Response(array('ok' => false, 'error' => 'invalid_key'), 403);
            }

            $status = (string) $order->get_status();
            $paid   = in_array($status, array('processing', 'completed'), true);

            return new \WP_REST_Response(array(
                'ok'       => true,
                'status'   => $status,
                'paid'     => $paid,
                'thankyou' => esc_url_raw($order->get_checkout_order_received_url()),
            ), 200);
        },
        'permission_callback' => '__return_true',
        'args' => array(
            'order_id' => array('required' => true),
            'order_key' => array('required' => true),
        ),
    ));
});

// WooCommerce AJAX endpoint to fetch the last Bonzai embed URL stored in the session.
add_action('wc_ajax_bonzai_popup_session', 'bonzai_wc_ajax_popup_session');
add_action('wc_ajax_nopriv_bonzai_popup_session', 'bonzai_wc_ajax_popup_session');
function bonzai_wc_ajax_popup_session() {
    if (!function_exists('WC') || !WC()->session) {
        wp_send_json(array('ok' => false, 'error' => 'no_session'));
    }

    $embed_url = WC()->session->get('bonzai_popup_iframe_url');
    $thankyou  = WC()->session->get('bonzai_popup_thankyou');
    $order_id  = WC()->session->get('bonzai_popup_order_id');

    // Backward-compat fallback (older keys).
    if (empty($embed_url)) {
        $embed_url = WC()->session->get('bonzai_last_embed_url');
    }
    if (empty($thankyou)) {
        $thankyou = WC()->session->get('bonzai_last_thankyou');
    }
    if (empty($order_id)) {
        $order_id = WC()->session->get('bonzai_last_order_id');
    }
    if (empty($embed_url)) {
        wp_send_json(array('ok' => false, 'error' => 'no_embed_url'));
    }

    wp_send_json(array(
        'ok'        => true,
        'order_id'  => (int) $order_id,
        'embed_url' => esc_url_raw($embed_url),
        'thankyou'  => esc_url_raw($thankyou),
    ));
}


// Inline embed mode: prepare (or reuse) a Bonzai checkout session WITHOUT requiring the customer
// to click the WooCommerce "Place order" button.
//
// This endpoint will:
//  - parse the checkout form fields,
//  - create (or reuse) a pending WooCommerce order linked to the current cart,
//  - call Bonzai /checkout to obtain embed_url,
//  - store embed_url + order info in the WC session for the front-end.
add_action('wc_ajax_bonzai_inline_prepare', 'bonzai_wc_ajax_inline_prepare');
add_action('wc_ajax_nopriv_bonzai_inline_prepare', 'bonzai_wc_ajax_inline_prepare');
function bonzai_wc_ajax_inline_prepare() {
    if (!function_exists('WC') || !WC() || !WC()->cart) {
        wp_send_json(array('ok' => false, 'error' => 'woocommerce_unavailable'), 500);
    }
    if (!WC()->session) {
        wp_send_json(array('ok' => false, 'error' => 'no_session'), 500);
    }

    $gateway = bonzai_get_gateway_instance();
    if (!$gateway || !is_object($gateway) || !method_exists($gateway, 'get_option')) {
        wp_send_json(array('ok' => false, 'error' => 'gateway_unavailable'), 500);
    }

    // Only operate in inline iframe mode.
    // The special /bonzai-checkout/ page always uses inline embed (even if the merchant didn't enable it on the standard checkout).
    $inline_on = ($gateway->get_option('inline_iframe', 'no') === 'yes');
    $special_checkout = false;
    if (isset($_POST['special_checkout'])) {
        $special_checkout = ((string) wp_unslash($_POST['special_checkout']) === '1');
    }
    // Force creation of a fresh Bonzai session (used on the custom /bonzai-checkout/ page to avoid a stuck
    // "Processing" screen after a browser refresh).
    $force_new = false;
    if (isset($_POST['force_new'])) {
        $force_new = ((string) wp_unslash($_POST['force_new']) === '1');
    }
    if (!$inline_on && !$special_checkout) {
        wp_send_json(array('ok' => false, 'error' => 'inline_disabled'), 400);
    }

    $raw = '';
    if (isset($_POST['checkout_data'])) {
        $raw = (string) wp_unslash($_POST['checkout_data']);
    }

    $posted = array();
    if ($raw !== '') {
        wp_parse_str($raw, $posted);
    }

    // Ensure payment method is set to Bonzai for the created order.
    $posted['payment_method'] = 'bonzai';

    $email = '';
    if (isset($posted['billing_email'])) {
        $email = sanitize_email((string) $posted['billing_email']);
    }
    if (!$email || !is_email($email)) {
        wp_send_json(array('ok' => false, 'error' => 'missing_email'), 400);
    }

    $first = isset($posted['billing_first_name']) ? sanitize_text_field((string) $posted['billing_first_name']) : '';
    $last  = isset($posted['billing_last_name']) ? sanitize_text_field((string) $posted['billing_last_name']) : '';
    $postcode = isset($posted['billing_postcode']) ? sanitize_text_field((string) $posted['billing_postcode']) : '';

    $cart_hash = is_callable(array(WC()->cart, 'get_cart_hash')) ? (string) WC()->cart->get_cart_hash() : '';
    $total     = (float) WC()->cart->get_total('edit');
    $currency  = get_woocommerce_currency();
    $force_currency = strtoupper(trim((string) $gateway->get_option('force_currency', '')));
    $target_currency = $force_currency ? $force_currency : $currency;
    if (!in_array($target_currency, array('EUR', 'USD'), true)) {
        $target_currency = 'EUR';
    }

    $fingerprint = md5(wp_json_encode(array(
        'cart' => $cart_hash,
        'email' => $email,
        'first' => $first,
        'last' => $last,
        'postcode' => $postcode,
        'total' => round($total, 2),
        'currency' => $target_currency,
    )));

    // Special checkout page may request a fresh Bonzai session on every reload.
    // When force_new=1, we bypass the reuse logic and clear any previously stored session data.
    $force_new = false;
    if (isset($_POST['force_new'])) {
        $force_new = ((string) wp_unslash($_POST['force_new']) === '1');
    }
    if ($force_new) {
        WC()->session->set('bonzai_inline_fp', '');
        WC()->session->set('bonzai_popup_iframe_url', '');
        WC()->session->set('bonzai_inline_wc_order_id', 0);
        WC()->session->set('bonzai_inline_wc_order_key', '');
        WC()->session->set('bonzai_last_embed_url', '');
        WC()->session->set('bonzai_last_order_id', 0);
        WC()->session->set('bonzai_last_thankyou', '');
    }

    // Reuse an existing prepared session if it matches the current fingerprint.
    $prev_fp = (string) WC()->session->get('bonzai_inline_fp');
    $prev_embed = (string) WC()->session->get('bonzai_popup_iframe_url');
    $prev_checkout = (string) WC()->session->get('bonzai_popup_checkout_url');
    $prev_order_id = (int) WC()->session->get('bonzai_inline_wc_order_id');
    $prev_order_key = (string) WC()->session->get('bonzai_inline_wc_order_key');
    if (!$force_new && $prev_fp && $prev_fp === $fingerprint && $prev_embed && $prev_order_id > 0 && $prev_order_key) {
        wp_send_json(array(
            'ok'        => true,
            'reused'    => true,
            'order_id'  => $prev_order_id,
            'order_key' => $prev_order_key,
            'embed_url' => esc_url_raw($prev_embed),
            'checkout_url' => $prev_checkout ? esc_url_raw($prev_checkout) : '',
        ));
    }

    // Create or reuse a pending Woo order tied to the cart.
    $wc_order = null;
    $existing_id = (int) WC()->session->get('bonzai_inline_wc_order_id');
    if ($existing_id > 0) {
        $candidate = wc_get_order($existing_id);
        if ($candidate && method_exists($candidate, 'get_status')) {
            $status = (string) $candidate->get_status();
            $is_paid = method_exists($candidate, 'is_paid') ? (bool) $candidate->is_paid() : in_array($status, array('processing', 'completed'), true);
            $candidate_cart = (string) $candidate->get_meta('_bonzai_cart_hash', true);
            if (!$is_paid && in_array($status, array('pending', 'failed', 'on-hold'), true) && $candidate_cart === $cart_hash) {
                $wc_order = $candidate;
            }
        }
    }

    if (!$wc_order) {
        try {
            if (!WC()->checkout()) {
                wp_send_json(array('ok' => false, 'error' => 'checkout_unavailable'), 500);
            }
            // create_order adds cart line items automatically.
            $new_id = WC()->checkout()->create_order($posted);
            $wc_order = $new_id ? wc_get_order($new_id) : null;
        } catch (Exception $e) {
            wp_send_json(array('ok' => false, 'error' => 'order_create_failed', 'message' => $e->getMessage()), 400);
        }
    }

    if (!$wc_order) {
        wp_send_json(array('ok' => false, 'error' => 'order_not_created'), 500);
    }

    // Update billing fields on the reused order (or the new one).
    if (method_exists($wc_order, 'set_billing_email')) $wc_order->set_billing_email($email);
    if (method_exists($wc_order, 'set_billing_first_name')) $wc_order->set_billing_first_name($first);
    if (method_exists($wc_order, 'set_billing_last_name')) $wc_order->set_billing_last_name($last);
    if (method_exists($wc_order, 'set_billing_postcode')) $wc_order->set_billing_postcode($postcode);
    $wc_order->update_meta_data('_bonzai_cart_hash', $cart_hash);
    $wc_order->save();

    // Call Bonzai to create a checkout session.
    $api_token = trim((string) $gateway->get_option('api_token'));
    $product_uuid = trim((string) $gateway->get_option('product_uuid'));
    if ($api_token === '' || $product_uuid === '') {
        wp_send_json(array('ok' => false, 'error' => 'missing_settings'), 500);
    }

    $amount = (float) $wc_order->get_total();
    if ($amount <= 0) {
        wp_send_json(array('ok' => false, 'error' => 'invalid_amount'), 400);
    }

    // Always return to WooCommerce thank-you to keep the order flow consistent.
    $redirect_url = $wc_order->get_checkout_order_received_url();

    $is_vat_incl = ((string) $gateway->get_option('is_vat_incl_default', 'yes') === 'yes');

    $bonzai_title = 'WooCommerce Order #' . $wc_order->get_order_number();
    $items = $wc_order->get_items('line_item');
    if (is_array($items) && !empty($items)) {
        foreach ($items as $item) {
            $bonzai_title = (string) $item->get_name();
            break;
        }
    }

    // Collect custom checkout fields from the special checkout page (and any other frontend that submits bonzai_cf_*).
    $custom_meta = array();
    foreach ((array) $posted as $k => $v) {
        if (strpos((string) $k, 'bonzai_cf_') !== 0) {
            continue;
        }
        $clean_key = sanitize_key(substr((string) $k, strlen('bonzai_cf_')));
        if ($clean_key === '') {
            continue;
        }
        // Keep values simple and safe.
        if (is_array($v)) {
            $v = wp_json_encode($v);
        }
        $clean_val = sanitize_text_field((string) $v);
        $custom_meta[$clean_key] = $clean_val;
        $wc_order->update_meta_data('_bonzai_cf_' . $clean_key, $clean_val);
    }

    $payload = array(
        'amount'       => round($amount, 2),
        'currency'     => $target_currency,
        'title'        => $bonzai_title,
        'redirect_url' => $redirect_url,
        'metadata'     => array_merge(
            array(
                'wc_order_id' => $wc_order->get_id(),
                'site'        => home_url(),
            ),
            $custom_meta
        ),
        'is_vat_incl'  => (bool) $is_vat_incl,
        'mode'         => 'one_off',
        'email'        => $email,
    );

    if ($first !== '') $payload['firstname'] = $first;
    if ($last !== '')  $payload['lastname']  = $last;
    if ($postcode !== '') $payload['postal_code'] = $postcode;

    if (method_exists($gateway, 'log')) {
        // noop: keep compatibility if gateway has log method in future.
    }

    $resp = wp_remote_post("https://www.bonzai.pro/api/v1/products/$product_uuid/checkout", array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_token,
            'Content-Type'  => 'application/json',
        ),
        'body'    => wp_json_encode($payload),
        'timeout' => 20,
    ));

    if (is_wp_error($resp)) {
        wp_send_json(array('ok' => false, 'error' => 'bonzai_api_error', 'message' => $resp->get_error_message()), 502);
    }

    $http = (int) wp_remote_retrieve_response_code($resp);
    $body_txt = (string) wp_remote_retrieve_body($resp);
    $body = json_decode($body_txt, true);

    if ($http < 200 || $http >= 300 || !is_array($body) || (empty($body['embed_url']) && empty($body['checkout_url']))) {
        wp_send_json(array('ok' => false, 'error' => 'bonzai_bad_response', 'http' => $http, 'body' => $body), 502);
    }

    // Bonzai provides both a full-page checkout_url and an embed_url.
    // embed_url may fail in some browsers due to third-party cookie restrictions (e.g. 3DS/Livewire flows).
    // We keep returning a primary iframe_url (embed_url preferred) for the classic inline embed integration,
    // but we also expose checkout_url to allow first-party (top-level) redirects when needed.
    $iframe_url   = !empty($body['embed_url']) ? (string) $body['embed_url'] : (string) $body['checkout_url'];
    $checkout_url = !empty($body['checkout_url']) ? (string) $body['checkout_url'] : '';

    // Persist linkage on the order.
    if (!empty($body['order_id'])) {
        $wc_order->update_meta_data('_bonzai_order_id', sanitize_text_field((string) $body['order_id']));
    }
    if (!empty($body['checkout_url'])) {
        $wc_order->update_meta_data('_bonzai_checkout_url', esc_url_raw((string) $body['checkout_url']));
    }
    if (!empty($body['embed_url'])) {
        $wc_order->update_meta_data('_bonzai_embed_url', esc_url_raw((string) $body['embed_url']));
    }
    $wc_order->save();

    // Store for the frontend.
    WC()->session->set('bonzai_inline_fp', $fingerprint);
    WC()->session->set('bonzai_inline_wc_order_id', (int) $wc_order->get_id());
    WC()->session->set('bonzai_inline_wc_order_key', (string) $wc_order->get_order_key());
    WC()->session->set('bonzai_popup_iframe_url', esc_url_raw($iframe_url));
    WC()->session->set('bonzai_popup_checkout_url', $checkout_url ? esc_url_raw($checkout_url) : '');
    WC()->session->set('bonzai_popup_thankyou', esc_url_raw($wc_order->get_checkout_order_received_url()));
    WC()->session->set('bonzai_popup_order_id', (int) $wc_order->get_id());

    wp_send_json(array(
        'ok'        => true,
        'reused'    => false,
        'order_id'  => (int) $wc_order->get_id(),
        'order_key' => (string) $wc_order->get_order_key(),
        // Back-compat: embed_url is what the frontend loads in an iframe.
        'embed_url'    => esc_url_raw($iframe_url),
        // New: checkout_url can be used for top-level navigation (recommended when embed is blocked).
        'checkout_url' => $checkout_url ? esc_url_raw($checkout_url) : '',
    ));
}


add_action('init', 'bonzai_gateway_add_rewrite_rules');

function bonzai_gateway_add_rewrite_rules() {
    $popup_base = 'bonzai/popup';
    $popup_base = ltrim($popup_base, '/');

    // Accept alnum, underscore, and hyphen in order key.
    add_rewrite_rule('^' . preg_quote($popup_base, '/') . '/([0-9]+)/([a-zA-Z0-9_\-]+)/?$', 'index.php?bonzai_popup=1&bonzai_order_id=$matches[1]&bonzai_order_key=$matches[2]', 'top');
}

add_filter('query_vars', function($vars) {
    $vars[] = 'bonzai_popup';
    $vars[] = 'bonzai_order_id';
    $vars[] = 'bonzai_order_key';
    return $vars;
});

add_action('template_redirect', function() {
    if (get_query_var('bonzai_popup')) {
        bonzai_render_popup_page();
        exit;
    }
});

/**
 * Renders the popup page. It loads the Bonzai embed URL inside an iframe.
 * If embed URL is missing, it falls back to checkout URL.
 */
function bonzai_render_popup_page() {
    if (!function_exists('wc_get_order')) {
        status_header(500);
        echo 'WooCommerce not available.';
        return;
    }

    // Prevent WP canonical redirects from altering signed URLs.
    remove_filter('template_redirect', 'redirect_canonical');

    $order_id  = absint(get_query_var('bonzai_order_id'));
    $order_key = (string) get_query_var('bonzai_order_key');

    $order = $order_id ? wc_get_order($order_id) : null;
    if (!$order) {
        status_header(404);
        echo 'Invalid WooCommerce order.';
        return;
    }

    if (!$order_key || $order_key !== $order->get_order_key()) {
        status_header(403);
        echo 'Invalid order key.';
        return;
    }

    $embed_url    = (string) $order->get_meta('_bonzai_embed_url', true);
    $checkout_url = (string) $order->get_meta('_bonzai_checkout_url', true);

    $target_url = $embed_url ? $embed_url : $checkout_url;
    if (!$target_url) {
        status_header(400);
        echo 'Missing Bonzai checkout URL.';
        return;
    }

    // Security: only allow bonzai.pro and subdomains.
    $extracted = bonzai_extract_bonzai_target($target_url);
    if (!$extracted) {
        status_header(400);
        echo 'Invalid Bonzai checkout URL.';
        return;
    }

    $iframe_src = esc_url($target_url);

    header('Content-Type: text/html; charset=utf-8');
    ?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Secure payment</title>
  <style>
    html, body { height: 100%; margin: 0; padding: 0; background: #0b0f14; font-family: -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif; }
    .bz-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,0.72); display: flex; align-items: center; justify-content: center; z-index: 999999; }
    .bz-modal { width: min(1100px, 96vw); height: min(760px, 92vh); background: #0b0f14; border-radius: 12px; overflow: hidden; box-shadow: 0 12px 48px rgba(0,0,0,0.55); position: relative; }
    .bz-topbar { height: 44px; display: flex; align-items: center; justify-content: space-between; padding: 0 12px; background: rgba(255,255,255,0.06); color: #fff; }
    .bz-topbar .title { font-size: 14px; opacity: 0.9; }
    .bz-close { background: rgba(255,255,255,0.12); border: 0; color: #fff; padding: 8px 10px; border-radius: 8px; cursor: pointer; }
    .bz-frame { width: 100%; height: calc(100% - 44px); border: 0; display: block; background: #fff; }
    .bz-fallback { position: fixed; inset: 0; display:none; align-items:center; justify-content:center; color:#fff; padding:24px; text-align:center; }
    .bz-fallback a { color: #fff; text-decoration: underline; }
  </style>
</head>
<body>
  <div class="bz-backdrop" id="bz_backdrop">
    <div class="bz-modal">
      <div class="bz-topbar">
        <div class="title">Paiement sécurisé</div>
        <button class="bz-close" type="button" id="bz_close">Fermer</button>
      </div>
      <iframe class="bz-frame" id="bz_iframe" src="<?php echo $iframe_src; ?>" allow="payment *; fullscreen *" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
  </div>

  <div class="bz-fallback" id="bz_fallback">
    <div>
      <div style="font-size:18px; margin-bottom:8px;">Fenêtre de paiement fermée</div>
      <div style="opacity:0.85; margin-bottom:18px;">Vous pouvez réessayer ou revenir à la boutique.</div>
      <div>
        <a href="<?php echo esc_url(home_url('/')); ?>">Retour</a>
      </div>
    </div>
  </div>

  <script>
    (function(){
      var closeBtn = document.getElementById('bz_close');
      var backdrop = document.getElementById('bz_backdrop');
      var fallback = document.getElementById('bz_fallback');

      function closeModal(){
        backdrop.style.display = 'none';
        fallback.style.display = 'flex';
      }

      closeBtn.addEventListener('click', function(){ closeModal(); });

      document.addEventListener('keydown', function(e){
        if (e && e.key === 'Escape') closeModal();
      });
    })();
  </script>
</body>
</html>
<?php
}

add_action('rest_api_init', function () {
    register_rest_route('bonzai/v1', '/order-status', array(
        'methods'  => 'GET',
        'permission_callback' => '__return_true',
        'callback' => function (WP_REST_Request $request) {
            if (!function_exists('wc_get_order')) {
                return new WP_REST_Response(array('error' => 'woocommerce_unavailable'), 500);
            }

            $order_id  = absint($request->get_param('order_id'));
            $order_key = sanitize_text_field((string) $request->get_param('order_key'));

            $order = wc_get_order($order_id);
            if (!$order || !$order_key || !hash_equals($order->get_order_key(), $order_key)) {
                return new WP_REST_Response(array('paid' => false, 'valid' => false), 200);
            }

            $status = $order->get_status();
            $paid = in_array($status, array('processing', 'completed'), true);

            return new WP_REST_Response(array(
                'valid'       => true,
                'paid'        => $paid,
                'status'      => $status,
                'thankyou_url' => $paid ? $order->get_checkout_order_received_url() : null,
            ), 200);
        },
    ));
});

function bonzai_rewrite_location($location) {
    $gateway = bonzai_get_gateway_instance();
    $proxy_base = 'bonzai/proxy';
    if ($gateway) {
        $proxy_base = trim($gateway->get_option('proxy_base_path', $proxy_base));
    }
    $proxy_base = ltrim($proxy_base, '/');
    $proxy_root = home_url('/' . $proxy_base . '/');

    $location = (string) $location;

    // Keep the current proxied Bonzai host in redirects so all subsequent requests keep targeting the right subdomain.
    $current_host = 'www.bonzai.pro';
    if (isset($_GET['bh'])) {
        $candidate = strtolower(sanitize_text_field((string) $_GET['bh']));
        // Allow bonzai.pro and any subdomain (e.g. pay.bonzai.pro). Note: '.bonzai.pro' is 11 chars.
        $is_bonzai = ($candidate === 'bonzai.pro') || (substr($candidate, -11) === '.bonzai.pro');
        if ($is_bonzai) {
            $current_host = $candidate;
        }
    }

    // Absolute URL to a Bonzai domain: rewrite to our proxy and preserve that host as bh.
    $parts = wp_parse_url($location);
    if (is_array($parts) && !empty($parts['host'])) {
        $h = strtolower((string) $parts['host']);
        // Allow bonzai.pro and any subdomain.
        $is_bonzai = ($h === 'bonzai.pro') || (substr($h, -11) === '.bonzai.pro');
        if ($is_bonzai) {
            $p = isset($parts['path']) ? ltrim((string) $parts['path'], '/') : '';
            $q = isset($parts['query']) && $parts['query'] !== '' ? ('?' . (string) $parts['query']) : '';
            $u = $proxy_root . $p . $q;
            return add_query_arg('bh', $h, $u);
        }
    }

    // Relative redirects: keep them inside our proxy and preserve current bh.
    if (strpos($location, '/') === 0) {
        $u = $proxy_root . ltrim($location, '/');
        return add_query_arg('bh', $current_host, $u);
    }

    return $location;
}

function bonzai_rewrite_set_cookie($cookie_line) {
    $cookie_line = (string) $cookie_line;

    // Drop Domain attribute so cookie becomes first party
    $cookie_line = preg_replace('/;\s*Domain=[^;]+/i', '', $cookie_line);

    // Ensure Path is root
    if (stripos($cookie_line, '; path=') === false) {
        $cookie_line .= '; Path=/';
    }

    // Ensure SameSite for modern browsers
    if (stripos($cookie_line, 'samesite=') === false) {
        $cookie_line .= '; SameSite=Lax';
    }

    return $cookie_line;
}

function bonzai_rewrite_body_urls($body, $bonzai_host = 'www.bonzai.pro') {
    $gateway = bonzai_get_gateway_instance();
    $proxy_base = 'bonzai/proxy';
    if ($gateway) {
        $proxy_base = trim($gateway->get_option('proxy_base_path', $proxy_base));
    }
    $proxy_base = ltrim($proxy_base, '/');
    $proxy_root = home_url('/' . $proxy_base);

    // Rewrite any Bonzai absolute URL (any subdomain) to our proxy, while preserving the originating host via bh.
    $body = preg_replace_callback(
        '#https://([a-z0-9.-]*bonzai\.pro)(/[^\"\'\s<]*)?#i',
        function ($m) use ($proxy_root) {
            $host = strtolower($m[1]);
            $path = isset($m[2]) && $m[2] !== '' ? $m[2] : '/';
            $u = $proxy_root . $path;
            return add_query_arg('bh', $host, $u);
        },
        $body
    );

    // Rewrite absolute root paths in common attributes
    $body = preg_replace_callback('/\b(href|src|action)=([\"\'])\/(?!\/)([^\"\']*)\2/i', function($m) use ($proxy_root, $bonzai_host) {
        $u = $proxy_root . '/' . $m[3];
        $u = add_query_arg('bh', $bonzai_host, $u);
        return $m[1] . '=' . $m[2] . $u . $m[2];
    }, $body);

    return $body;
}

function getallheaders_safe() {
    if (function_exists('getallheaders')) {
        $h = getallheaders();
        if (is_array($h)) return $h;
    }

    $headers = array();
    foreach ($_SERVER as $name => $value) {
        if (strpos($name, 'HTTP_') === 0) {
            $key = str_replace('_', '-', substr($name, 5));
            $headers[$key] = $value;
        }
    }
    return $headers;
}


add_filter('woocommerce_payment_gateways', function($methods){
    $methods[] = 'WC_Gateway_Bonzai';
    return $methods;
});


add_action('rest_api_init', function () {
    register_rest_route('bonzai/v1', '/webhook', array(
        'methods'             => 'POST',
        'callback'            => 'bonzai_handle_webhook',
        'permission_callback' => '__return_true',
    ));
});

function bonzai_get_gateway_instance() {
    if (!function_exists('WC') || !WC()->payment_gateways()) return null;
    $gws = WC()->payment_gateways()->payment_gateways();
    return isset($gws['bonzai']) ? $gws['bonzai'] : null;
}

function bonzai_verify_token(WP_REST_Request $request, $gateway) {
    $configured = trim($gateway->get_option('webhook_token'));
    if ($configured === '') return false;
    $q = (string) $request->get_param('token');
    $h = (string) $request->get_header('x-bonzai-token');
    return hash_equals($configured, $q) || hash_equals($configured, $h);
}

function bonzai_already_processed($event_id) {
    if (!$event_id) return false;
    $key = 'bonz_evt_' . md5($event_id);
    if (get_transient($key)) return true;
    set_transient($key, 1, DAY_IN_SECONDS);
    return false;
}

function bonzai_find_wc_order_from_payload(array $evt) {
    $wc_id = $evt['order']['metadata']['wc_order_id'] ?? null;
    if ($wc_id) {
        $order = wc_get_order((int) $wc_id);
        if ($order) return $order;
    }

    $bonzai_order_id = $evt['order_id'] ?? ($evt['order']['id'] ?? null);
    if (!empty($bonzai_order_id)) {
        $orders = wc_get_orders(array(
            'limit'      => 1,
            'meta_key'   => '_bonzai_order_id',
            'meta_value' => (string) $bonzai_order_id,
            'return'     => 'objects',
        ));
        if (!empty($orders)) return $orders[0];
    }

    $email = $evt['user']['email'] ?? '';
    if ($email !== '') {
        $orders = wc_get_orders(array(
            'limit'         => 1,
            'orderby'       => 'date',
            'order'         => 'DESC',
            'status'        => array('pending','on-hold'),
            'billing_email' => $email,
            'return'        => 'objects',
        ));
        if (!empty($orders)) return $orders[0];
    }

    return null;
}

function bonzai_handle_webhook(WP_REST_Request $request) {
    $gw = bonzai_get_gateway_instance();
    if (!$gw) return new WP_REST_Response(array('ok'=>false,'msg'=>'gateway not loaded'), 503);

    if (!bonzai_verify_token($request, $gw)) {
        return new WP_REST_Response(array('ok'=>false,'msg'=>'invalid token'), 401);
    }

    $raw = $request->get_body();
    $evt = json_decode($raw, true);

    if (!is_array($evt)) {
        return new WP_REST_Response(array('ok'=>false,'msg'=>'invalid json'), 400);
    }

    $event_id = $evt['id'] ?? $evt['order_id'] ?? $evt['timestamp'] ?? hash('sha256', $raw);
    if (bonzai_already_processed($event_id)) {
        return new WP_REST_Response(array('ok'=>true,'msg'=>'duplicate'), 200);
    }

    $type  = $evt['event_type'] ?? 'unknown';
    $order = bonzai_find_wc_order_from_payload($evt);

    if (!$order) {
        if (function_exists('wc_get_logger')) {
            wc_get_logger()->warning('[Bonzai] Webhook received without wc_order_id: ' . $raw, array('source'=>'bonzai_gateway'));
        }
        return new WP_REST_Response(array('ok'=>true,'msg'=>'no wc order'), 200);
    }

    switch ($type) {
        case 'product_access_granted':
            if (!$order->is_paid()) {
                $order->payment_complete();
                $order->add_order_note('Bonzai: product_access_granted -> payment confirmed.');
            } else {
                if ($order->get_status() !== 'completed') {
                    $order->update_status('completed', 'Bonzai: product_access_granted -> completed.');
                }
            }
            break;

        case 'product_access_revoked':
            if ($order->get_status() !== 'cancelled') {
                $order->update_status('cancelled', 'Bonzai: product_access_revoked.');
            }
            break;

        default:
            $order->add_order_note('Bonzai: unhandled event ' . esc_html($type) . '.');
            break;
    }

    return new WP_REST_Response(array('ok'=>true), 200);
}

add_action('template_redirect', function(){
    if (!isset($_GET['wc_order'])) return;
    $order = wc_get_order(absint($_GET['wc_order']));
    if (!$order || $order->is_paid()) return;
    $order->add_order_note('Customer returned to the redirect page. Waiting for Bonzai webhook.');
});

add_filter('woocommerce_payment_complete_order_status', function($status, $order_id, $order){
    if ($order instanceof WC_Order && $order->get_payment_method() === 'bonzai') {
        return 'completed';
    }
    return $status;
}, 10, 3);


add_action('woocommerce_product_options_general_product_data', 'bonzai_product_fields');

function bonzai_product_fields() {
    echo '<div class="options_group">';

    woocommerce_wp_select(array(
        'id'          => 'bonzai_is_vat_incl',
        'label'       => 'Bonzai VAT handling',
        'description' => 'Override Bonzai VAT handling for this product. If Inherit, gateway default is used.',
        'desc_tip'    => true,
        'options'     => array(
            ''     => 'Inherit from gateway setting',
            'yes'  => 'Amount includes VAT',
            'no'   => 'Amount excludes VAT',
        ),
    ));

    woocommerce_wp_select(array(
        'id'          => 'bonzai_payment_mode',
        'label'       => 'Bonzai payment mode',
        'description' => 'Choose how this product should be charged in Bonzai.',
        'desc_tip'    => true,
        'options'     => array(
            ''                     => 'Inherit or auto detect',
            'one_off'              => 'One off payment',
            'subscription_monthly' => 'Subscription monthly',
            'subscription_yearly'  => 'Subscription yearly',
        ),
    ));

    echo '</div>';
}

add_action('woocommerce_process_product_meta', 'bonzai_save_product_fields');

function bonzai_save_product_fields($post_id) {
    if (isset($_POST['bonzai_is_vat_incl'])) {
        $value = wc_clean(wp_unslash($_POST['bonzai_is_vat_incl']));
        if (!in_array($value, array('', 'yes', 'no'), true)) $value = '';
        update_post_meta($post_id, 'bonzai_is_vat_incl', $value);
    }

    if (isset($_POST['bonzai_payment_mode'])) {
        $mode = wc_clean(wp_unslash($_POST['bonzai_payment_mode']));
        if (!in_array($mode, array('', 'one_off', 'subscription_monthly', 'subscription_yearly'), true)) $mode = '';
        update_post_meta($post_id, 'bonzai_payment_mode', $mode);
    }
}


function bonzai_api_retrieve_order($bonzai_order_id, $gateway) {
    $bonzai_order_id = trim((string) $bonzai_order_id);
    if ($bonzai_order_id === '') {
        return new WP_Error('bonzai_no_order_id', 'Missing Bonzai order_id');
    }

    $api_token = trim($gateway->api_token);
    if ($api_token === '') {
        return new WP_Error('bonzai_no_token', 'Missing Bonzai API token');
    }

    $url = 'https://www.bonzai.pro/api/v1/orders/' . rawurlencode($bonzai_order_id);

    $response = wp_remote_get($url, array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_token,
            'Accept'        => 'application/json',
        ),
        'timeout' => max(5, (int) $gateway->timeout),
    ));

    if (is_wp_error($response)) {
        if (!empty($gateway->debug)) {
            $gateway->log('Retrieve order error: ' . $response->get_error_message());
        }
        return $response;
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    $body_txt = (string) wp_remote_retrieve_body($response);
    $body = json_decode($body_txt, true);

    if ($code !== 200 || !is_array($body)) {
        if (!empty($gateway->debug)) {
            $gateway->log('Retrieve order HTTP ' . $code . ' body=' . $body_txt);
        }
        return new WP_Error('bonzai_bad_response', 'Unexpected response from Bonzai retrieve order', array(
            'code' => $code,
            'body' => $body_txt,
        ));
    }

    return $body;
}

function bonzai_store_last_retrieve_payload(WC_Order $order, array $api_order) {
    // Store retrieve info using order meta API for HPOS compatibility.
    $order->update_meta_data('_bonzai_last_retrieve_payload', wp_json_encode($api_order));
    $order->update_meta_data('_bonzai_last_retrieve_at', current_time('mysql'));
    $order->save();
}

function bonzai_extract_timeline(array $payload) {
    $events = array();

    // 1) If there is a real timeline field, use it (future-proof)
    if (!empty($payload['timeline']) && is_array($payload['timeline'])) {
        foreach ($payload['timeline'] as $ev) {
            if (!is_array($ev)) continue;

            $date = $ev['date'] ?? ($ev['created_at'] ?? '');
            if (!$date) continue;

            $events[] = array(
                'date'    => (string) $date,
                'type'    => (string) ($ev['type'] ?? ($ev['event'] ?? 'event')),
                'message' => (string) ($ev['message'] ?? ($ev['label'] ?? '')),
            );
        }
    }

    // 2) Fallback: build timeline from accesses[]
    if (empty($events) && !empty($payload['accesses']) && is_array($payload['accesses'])) {
        foreach ($payload['accesses'] as $a) {
            if (!is_array($a)) continue;

            $id = isset($a['id']) ? (string) $a['id'] : '';

            if (!empty($a['created_at'])) {
                $events[] = array(
                    'date'    => (string) $a['created_at'],
                    'type'    => 'access',
                    'message' => 'Access created' . ($id ? " (#$id)" : ''),
                );
            }

            if (!empty($a['updated_at']) && ($a['updated_at'] !== ($a['created_at'] ?? null))) {
                $events[] = array(
                    'date'    => (string) $a['updated_at'],
                    'type'    => 'access',
                    'message' => 'Access updated' . ($id ? " (#$id)" : ''),
                );
            }

            if (!empty($a['deleted_at'])) {
                $events[] = array(
                    'date'    => (string) $a['deleted_at'],
                    'type'    => 'access',
                    'message' => 'Access deleted' . ($id ? " (#$id)" : ''),
                );
            }
        }
    }

    // Sort ASC by date
    usort($events, function($x, $y){
        $dx = strtotime((string)($x['date'] ?? '')) ?: 0;
        $dy = strtotime((string)($y['date'] ?? '')) ?: 0;
        return $dx <=> $dy;
    });

    return $events;
}

function bonzai_render_history_html(array $payload, $bonzai_order_id = '') {
    $has_access = array_key_exists('has_access', $payload) ? ($payload['has_access'] ? 'true' : 'false') : 'null';
    $intent_status = $payload['intent_status'] ?? ($payload['order']['intent_status'] ?? null);
    $subscription_status = $payload['subscription_status'] ?? ($payload['order']['subscription_status'] ?? null);

    $timeline = bonzai_extract_timeline($payload);

    ob_start();
    ?>
    <div style="padding:12px;">
        <div style="margin-bottom:10px;">
            <div><strong>Bonzai order_id:</strong> <?php echo esc_html($bonzai_order_id ?: ''); ?></div>
            <div><strong>has_access:</strong> <?php echo esc_html($has_access); ?></div>
            <div><strong>intent_status:</strong> <?php echo esc_html($intent_status !== null ? (string) $intent_status : 'null'); ?></div>
            <div><strong>subscription_status:</strong> <?php echo esc_html($subscription_status !== null ? (string) $subscription_status : 'null'); ?></div>
        </div>

        <h3 style="margin:0 0 8px 0;">Timeline</h3>

        <?php if (empty($timeline)) : ?>
            <p>No timeline data found in this Retrieve payload. Raw payload is available below.</p>
        <?php else : ?>
            <table class="widefat striped" style="margin-top:8px;">
                <thead>
                    <tr>
                        <th style="width:180px;">Date</th>
                        <th style="width:220px;">Type</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($timeline as $evt) : ?>
                    <tr>
                        <td><?php echo esc_html($evt['date']); ?></td>
                        <td><?php echo esc_html($evt['type']); ?></td>
                        <td><?php echo esc_html($evt['message']); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <details style="margin-top:10px;">
            <summary>Raw payload</summary>
            <pre style="white-space:pre-wrap;"><?php echo esc_html(wp_json_encode($payload, JSON_PRETTY_PRINT)); ?></pre>
        </details>
    </div>
    <?php
    return ob_get_clean();
}

function bonzai_sync_wc_order_with_bonzai(WC_Order $order, array $api_order) {

    // Support plusieurs formats de réponse possibles
    $has_access = null;
    if (array_key_exists('has_access', $api_order)) {
        $has_access = (bool) $api_order['has_access'];
    } elseif (isset($api_order['order']) && is_array($api_order['order']) && array_key_exists('has_access', $api_order['order'])) {
        $has_access = (bool) $api_order['order']['has_access'];
    }

    $intent_status = $api_order['intent_status'] ?? ($api_order['order']['intent_status'] ?? null);
    $subscription_status = $api_order['subscription_status'] ?? ($api_order['order']['subscription_status'] ?? null);

    // Normalisation simple
    $intent_status_norm = is_string($intent_status) ? strtolower(trim($intent_status)) : null;
    $subscription_status_norm = is_string($subscription_status) ? strtolower(trim($subscription_status)) : null;

    $order->add_order_note(sprintf(
        'Bonzai sync: intent_status=%s, subscription_status=%s, has_access=%s',
        $intent_status_norm !== null ? $intent_status_norm : 'null',
        $subscription_status_norm !== null ? $subscription_status_norm : 'null',
        $has_access === null ? 'null' : ($has_access ? 'true' : 'false')
    ));

    // Heuristique paiement complété
    $payment_completed =
        ($intent_status_norm === 'completed')
        || ($intent_status_norm === 'complete')
        || ($intent_status_norm === 'succeeded')
        || ($intent_status_norm === 'paid');

    // 1) Access actif: on force completed même si c'était refunded
    if ($has_access === true) {
        if ($order->get_status() !== 'completed') {
            // payment_complete peut être bloquant selon l'état, donc on force le statut
            $order->update_status('completed', 'Bonzai sync: access active.');
        }
        return;
    }

    // 2) Access inactif
    if ($has_access === false) {

        // Si paiement jamais complété: on évite de mettre refunded sur un test non payé
        if (!$payment_completed && !$order->is_paid()) {
            // Laisser tel quel, ou marquer cancelled si vous voulez
            $order->add_order_note('Bonzai sync: access inactive and payment not completed. No status change.');
            return;
        }

        // Si paiement a existé: refunded
        if ($order->get_status() !== 'cancelled') {
            $order->update_status('cancelled', 'Bonzai sync: access inactive after payment.');
        }
        return;
    }

    // 3) Cas indéterminé: on ne touche pas au statut
    $order->add_order_note('Bonzai sync: unable to determine access state. No status change.');
}


add_action('init', 'bonzai_register_cron_event');

function bonzai_register_cron_event() {
    if (!wp_next_scheduled('bonzai_cron_order_sync')) {
        wp_schedule_event(time() + HOUR_IN_SECONDS, 'hourly', 'bonzai_cron_order_sync');
    }
}

add_action('bonzai_cron_order_sync', 'bonzai_run_cron_order_sync');

function bonzai_run_cron_order_sync() {
    $gw = bonzai_get_gateway_instance();
    if (!$gw) return;

    $mode = $gw->order_sync_enabled ?? 'no';
    if ($mode === 'no') return;

    $hour_config = isset($gw->order_sync_hour) ? (int) $gw->order_sync_hour : 3;
    $day_config  = isset($gw->order_sync_day) ? strtolower($gw->order_sync_day) : 'monday';

    $now      = current_datetime();
    $hour_now = (int) $now->format('G');
    $day_now  = strtolower($now->format('l'));

    if ($hour_now !== $hour_config) return;

    if ($mode === 'daily') {
        $today = $now->format('Y-m-d');
        $last  = get_option('bonzai_sync_last_daily');
        if ($last === $today) return;
        update_option('bonzai_sync_last_daily', $today);
    } elseif ($mode === 'weekly') {
        if ($day_now !== $day_config) return;
        $yearweek = $now->format('o-W');
        $last     = get_option('bonzai_sync_last_weekly');
        if ($last === $yearweek) return;
        update_option('bonzai_sync_last_weekly', $yearweek);
    } else {
        return;
    }

    if (!empty($gw->debug)) {
        $gw->log('Starting automatic Bonzai order sync via cron.');
    }

    $orders = wc_get_orders(array(
        'limit'        => -1,
        'meta_key'     => '_bonzai_order_id',
        'meta_compare' => 'EXISTS',
        'status'       => array('pending','on-hold','processing','completed','refunded','cancelled','failed'),
        'return'       => 'objects',
    ));

    if (empty($orders)) {
        if (!empty($gw->debug)) $gw->log('Automatic sync: no orders with Bonzai order_id found.');
        return;
    }

    foreach ($orders as $order) {
        $bonzai_order_id = $order->get_meta('_bonzai_order_id', true);
        if (!$bonzai_order_id) continue;

        $api_order = bonzai_api_retrieve_order($bonzai_order_id, $gw);
        if (is_wp_error($api_order)) {
            if (!empty($gw->debug)) {
                $gw->log('Automatic sync error for order #' . $order->get_id() . ': ' . $api_order->get_error_message());
            }
            $order->add_order_note('Bonzai automatic sync error: ' . $api_order->get_error_message());
            continue;
        }

        bonzai_store_last_retrieve_payload($order, $api_order);
        bonzai_sync_wc_order_with_bonzai($order, $api_order);
    }

    if (!empty($gw->debug)) {
        $gw->log('Automatic Bonzai order sync finished.');
    }
}


add_action('admin_menu', 'bonzai_register_admin_page');

function bonzai_register_admin_page() {
    add_submenu_page(
        'woocommerce',
        'Bonzai Order Sync',
        'Bonzai Order Sync',
        'manage_woocommerce',
        'bonzai_order_sync',
        'bonzai_render_order_sync_page'
    );
}

function bonzai_render_order_sync_page() {
    if (!current_user_can('manage_woocommerce')) {
        wp_die('You do not have permission to access this page.');
    }

    $gw = bonzai_get_gateway_instance();
    if (!$gw) {
        echo '<div class="notice notice-error"><p>Bonzai gateway is not loaded.</p></div>';
        return;
    }

    $orders       = array();
    $search_email = '';
    $message      = '';
    $message_type = 'info';

    if (isset($_POST['bonzai_search_email']) && isset($_POST['bonzai_action']) && $_POST['bonzai_action'] === 'search') {
        check_admin_referer('bonzai_search_orders');
        $search_email = sanitize_email(wp_unslash($_POST['bonzai_search_email']));
        if ($search_email) {
            $orders = wc_get_orders(array(
                'limit'         => 50,
                'orderby'       => 'date',
                'order'         => 'DESC',
                'billing_email' => $search_email,
                'return'        => 'objects',
            ));
            if (empty($orders)) {
                $message = 'No orders found for this email.';
                $message_type = 'warning';
            }
        } else {
            $message = 'Please enter a valid email address.';
            $message_type = 'error';
        }
    }

    if (isset($_POST['bonzai_sync_order_id']) && isset($_POST['bonzai_action']) && $_POST['bonzai_action'] === 'sync') {
        check_admin_referer('bonzai_sync_single_order');

        $order_id = absint($_POST['bonzai_sync_order_id']);
        $search_email = isset($_POST['bonzai_search_email']) ? sanitize_email(wp_unslash($_POST['bonzai_search_email'])) : '';
        $order = wc_get_order($order_id);

        if ($order) {
            $o = wc_get_order($order_id);
            $bonzai_order_id = $o ? $o->get_meta('_bonzai_order_id', true) : '';
            if (!$bonzai_order_id) {
                $message = 'This order does not have a Bonzai order_id. It cannot be synced.';
                $message_type = 'error';
            } else {
                $api_order = bonzai_api_retrieve_order($bonzai_order_id, $gw);
                if (is_wp_error($api_order)) {
                    $message = 'Error while retrieving order from Bonzai: ' . esc_html($api_order->get_error_message());
                    $message_type = 'error';
                    $order->add_order_note('Bonzai manual sync error: ' . $api_order->get_error_message());
                } else {
                    bonzai_store_last_retrieve_payload($order, $api_order);
                    bonzai_sync_wc_order_with_bonzai($order, $api_order);
                    $message = 'Bonzai order synced successfully for WooCommerce order #' . $order_id . '.';
                    $message_type = 'success';
                }
            }
        } else {
            $message = 'Invalid WooCommerce order ID.';
            $message_type = 'error';
        }

        if ($search_email) {
            $orders = wc_get_orders(array(
                'limit'         => 50,
                'orderby'       => 'date',
                'order'         => 'DESC',
                'billing_email' => $search_email,
                'return'        => 'objects',
            ));
        }
    }

    $notice_class = 'notice notice-info';
    if ($message_type === 'success') $notice_class = 'notice notice-success';
    if ($message_type === 'warning') $notice_class = 'notice notice-warning';
    if ($message_type === 'error')   $notice_class = 'notice notice-error';

    echo '<div class="wrap"><h1>Bonzai Order Sync</h1>';

    if ($message) {
        echo '<div class="' . esc_attr($notice_class) . ' is-dismissible"><p>' . esc_html($message) . '</p></div>';
    }

    echo '<h2>Search orders by customer email</h2>';
    echo '<form method="post">';
    wp_nonce_field('bonzai_search_orders');
    echo '<input type="hidden" name="bonzai_action" value="search" />';
    echo '<p><label for="bonzai_search_email">Customer email:</label> ';
    echo '<input type="email" id="bonzai_search_email" name="bonzai_search_email" value="' . esc_attr($search_email) . '" size="40" />';
    submit_button('Search orders', 'secondary', 'submit', false);
    echo '</p></form>';

    if (!empty($orders)) {
        echo '<h2>Orders for ' . esc_html($search_email) . '</h2>';
        echo '<table class="widefat striped">';
        echo '<thead><tr><th>Order ID</th><th>Date</th><th>Status</th><th>Total</th><th>Bonzai order_id</th><th>Action</th></tr></thead><tbody>';

        foreach ($orders as $order) {
            $bonzai_order_id = $order->get_meta('_bonzai_order_id', true);
            $payload_exists = (bool) $order->get_meta('_bonzai_last_retrieve_payload', true);

            echo '<tr>';
            echo '<td><a href="' . esc_url(get_edit_post_link($order->get_id())) . '">#' . esc_html($order->get_id()) . '</a></td>';
            echo '<td>' . esc_html($order->get_date_created() ? $order->get_date_created()->date_i18n('Y-m-d H:i') : '') . '</td>';
            echo '<td>' . esc_html(wc_get_order_status_name($order->get_status())) . '</td>';
            $total_html = wp_kses_post(
                wc_price($order->get_total(), array('currency' => $order->get_currency()))
            );

            if ($order->has_status('refunded')) {
                $zero_html = wp_kses_post(
                    wc_price(0, array('currency' => $order->get_currency()))
                );

                echo '<td>'
                    . '<del>' . $total_html . '</del> '
                    . '<ins>' . $zero_html . '</ins>'
                    . '</td>';
            } else {
                echo '<td>' . $total_html . '</td>';
            }
            echo '<td>' . esc_html($bonzai_order_id ? $bonzai_order_id : '') . '</td>';

            echo '<td>';
            if ($bonzai_order_id) {
                echo '<form method="post" style="display:inline-block; margin-right:8px;">';
                wp_nonce_field('bonzai_sync_single_order');
                echo '<input type="hidden" name="bonzai_action" value="sync" />';
                echo '<input type="hidden" name="bonzai_search_email" value="' . esc_attr($search_email) . '" />';
                echo '<input type="hidden" name="bonzai_sync_order_id" value="' . esc_attr($order->get_id()) . '" />';
                submit_button('Sync with Bonzai', 'primary', 'submit', false);
                echo '</form>';

                if ($payload_exists) {
                    echo '<button type="button" class="button bonzai_history_btn" data_order_id="' . esc_attr($order->get_id()) . '">History</button>';
                } else {
                    echo '<span style="margin-left:6px; color:#666;">No history yet</span>';
                }

            } else {
                echo 'No Bonzai order_id';
            }
            echo '</td>';

            echo '</tr>';
        }

        echo '</tbody></table>';
    }

    $nonce = wp_create_nonce('bonzai_history_nonce');
    $ajax_url = admin_url('admin-ajax.php');

    echo '
<div id="bonzai_history_modal" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.6); z-index:99999;">
  <div style="background:#fff; width:90%; max-width:1100px; margin:40px auto; border-radius:6px; overflow:hidden;">
    <div style="padding:12px 16px; border-bottom:1px solid #ddd; display:flex; justify-content:space-between; align-items:center;">
      <div style="font-size:16px; font-weight:600;">Bonzai Retrieve History</div>
      <button type="button" class="button" id="bonzai_history_close">Close</button>
    </div>
    <div id="bonzai_history_meta" style="padding:8px 16px; border-bottom:1px solid #eee; color:#444;"></div>
    <div id="bonzai_history_content" style="max-height:70vh; overflow:auto;"></div>
  </div>
</div>

<script type="text/javascript">
(function($){
  function openModal(){ $("#bonzai_history_modal").show(); }
  function closeModal(){
    $("#bonzai_history_modal").hide();
    $("#bonzai_history_content").html("");
    $("#bonzai_history_meta").text("");
  }

  $(document).on("click", "#bonzai_history_close", function(){ closeModal(); });
  $(document).on("click", "#bonzai_history_modal", function(e){
    if (e.target === this) closeModal();
  });

  $(document).on("click", ".bonzai_history_btn", function(){
    var orderId = $(this).attr("data_order_id");
    $("#bonzai_history_content").html("<div style=\'padding:12px;\'>Loading...</div>");
    $("#bonzai_history_meta").text("");
    openModal();

    $.post("' . esc_js($ajax_url) . '", {
      action: "bonzai_get_order_history",
      nonce: "' . esc_js($nonce) . '",
      order_id: orderId
    })
    .done(function(resp){
      if (!resp || !resp.success) {
        var msg = (resp && resp.data && resp.data.message) ? resp.data.message : "Unknown error";
        $("#bonzai_history_content").html("<div style=\'padding:12px; color:#b32d2e;\'>" + msg + "</div>");
        return;
      }
      if (resp.data && resp.data.last_retrieve_at) {
        $("#bonzai_history_meta").text("Last retrieve at: " + resp.data.last_retrieve_at);
      }
      $("#bonzai_history_content").html(resp.data.html || "<div style=\'padding:12px;\'>No data</div>");
    })
    .fail(function(){
      $("#bonzai_history_content").html("<div style=\'padding:12px; color:#b32d2e;\'>Request failed</div>");
    });
  });
})(jQuery);
</script>
';

    echo '</div>';
}

add_action('wp_ajax_bonzai_get_order_history', 'bonzai_ajax_get_order_history');

function bonzai_ajax_get_order_history() {
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error(array('message' => 'Unauthorized'), 403);
    }

    check_ajax_referer('bonzai_history_nonce', 'nonce');

    $order_id = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
    if (!$order_id) {
        wp_send_json_error(array('message' => 'Missing order_id'), 400);
    }

    $order = wc_get_order($order_id);
    if (!$order) {
        wp_send_json_error(array('message' => 'Invalid WooCommerce order'), 404);
    }

    $payload_json = $order->get_meta('_bonzai_last_retrieve_payload', true);
    if (!$payload_json) {
        wp_send_json_error(array('message' => 'No stored Retrieve payload for this order. Run Sync first.'), 404);
    }

    $payload = json_decode($payload_json, true);
    if (!is_array($payload)) {
        wp_send_json_error(array('message' => 'Stored payload is invalid JSON'), 500);
    }

    $bonzai_order_id = $order->get_meta('_bonzai_order_id', true);
    $html = bonzai_render_history_html($payload, $bonzai_order_id);

    $last_at = (string) $order->get_meta('_bonzai_last_retrieve_at', true);

    wp_send_json_success(array(
        'html' => $html,
        'last_retrieve_at' => $last_at,
    ));
}

/**
 * Validate and parse a Bonzai checkout URL.
 *
 * Security goal: avoid turning the popup endpoint into an open redirect/iframe loader.
 * We only allow HTTPS URLs to bonzai.pro and its subdomains.
 *
 * @param string $url
 * @return array|null Parsed URL parts when valid, otherwise null.
 */
function bonzai_extract_bonzai_target($url) {
    $url = trim((string) $url);
    if ($url === '') {
        return null;
    }

    // Only allow absolute HTTPS URLs.
    $parts = wp_parse_url($url);
    if (!is_array($parts)) {
        return null;
    }

    $scheme = isset($parts['scheme']) ? strtolower($parts['scheme']) : '';
    if ($scheme !== 'https') {
        return null;
    }

    $host = isset($parts['host']) ? strtolower($parts['host']) : '';
    if ($host === '') {
        return null;
    }

    // Allow bonzai.pro and any subdomain *.bonzai.pro (including pay.bonzai.pro).
    if ($host === 'bonzai.pro' || $host === 'www.bonzai.pro') {
        return $parts;
    }

    // Note: '.bonzai.pro' length is 11.
    if (substr($host, -11) === '.bonzai.pro') {
        return $parts;
    }

    return null;
}

/**
 * Mirror some special-checkout settings into standalone options.
 *
 * Why: WooCommerce saves gateway settings under woocommerce_{gateway_id}_settings,
 * but some environments/theme builders/cache layers may cause the special checkout
 * to read settings before the in-memory gateway instance refreshes.
 *
 * This action runs on the canonical WooCommerce hook fired when the Bonzai gateway
 * settings are saved.
 */
add_action('woocommerce_update_options_payment_gateways_bonzai', function () {
    if (!function_exists('wc_clean')) {
        return;
    }

    // Field names as rendered by WC_Settings_API.
    $mode_field    = 'woocommerce_bonzai_sc_testimonials_mode';
    $enabled_field = 'woocommerce_bonzai_sc_testimonials_enabled';

    $posted_mode = isset($_POST[$mode_field]) ? sanitize_key(wp_unslash($_POST[$mode_field])) : '';
    if (!in_array($posted_mode, array('carousel', 'inline'), true)) {
        $posted_mode = 'carousel';
    }

    // Checkbox may be absent when unchecked.
    $posted_enabled = isset($_POST[$enabled_field]) ? sanitize_key(wp_unslash($_POST[$enabled_field])) : 'no';
    $enabled = ($posted_enabled === 'yes' || $posted_enabled === '1' || $posted_enabled === 'on') ? 'yes' : 'no';

    update_option('bonzai_sc_testimonials_mode', $posted_mode);
    update_option('bonzai_sc_testimonials_enabled', $enabled);
}, 20);

