<?php
/*
Plugin Name: Bonzai Payment Gateway
Description: Payment via Bonzai Checkout with confirmation webhooks and order sync.
Version: 1.5.0
Author: Ramy
*/

if (!defined('ABSPATH')) exit;

add_action('plugins_loaded', 'bonzai_init_gateway_class');

function bonzai_init_gateway_class() {

    class WC_Gateway_Bonzai extends WC_Payment_Gateway {

        /** @var WC_Logger|null */
        protected $logger = null;

        public function __construct() {
            $this->id                 = 'bonzai';
            $this->icon               = '';
            $this->has_fields         = false;
            $this->method_title       = 'Bonzai';
            $this->method_description = 'Pay through Bonzai Checkout.';
            $this->supports           = array('products');

            $this->init_form_fields();
            $this->init_settings();

            // Settings
            $this->title               = $this->get_option('title');
            $this->description         = $this->get_option('description');
            $this->enabled             = $this->get_option('enabled');
            $this->api_token           = trim($this->get_option('api_token'));
            $this->product_uuid        = trim($this->get_option('product_uuid'));
            $this->redirect_url        = trim($this->get_option('redirect_url'));
            $this->debug               = wc_string_to_bool($this->get_option('debug', 'no'));
            $this->timeout             = absint($this->get_option('timeout', 20));
            $this->force_currency      = strtoupper(trim($this->get_option('force_currency', '')));
            $this->min_amount          = floatval($this->get_option('min_amount', 0));
            $this->webhook_token       = trim($this->get_option('webhook_token', ''));
            $this->is_vat_incl_default = $this->get_option('is_vat_incl_default', 'yes'); // yes/no
            $this->order_sync_enabled  = $this->get_option('order_sync_enabled', 'no');   // no/daily/weekly
            $this->order_sync_hour     = intval($this->get_option('order_sync_hour', 3)); // hour 0–23
            $this->order_sync_day      = strtolower($this->get_option('order_sync_day', 'monday')); // monday...

            if ($this->debug) {
                $this->logger = wc_get_logger();
            }

            add_action(
                'woocommerce_update_options_payment_gateways_' . $this->id,
                array($this, 'process_admin_options')
            );
        }

        public function init_form_fields() {
            $base_webhook_url = rest_url('bonzai/v1/webhook');

            $this->form_fields = array(
                'enabled' => array(
                    'title'   => 'Enable',
                    'type'    => 'checkbox',
                    'label'   => 'Enable Bonzai Checkout',
                    'default' => 'yes',
                ),
                'title' => array(
                    'title'       => 'Title',
                    'type'        => 'text',
                    'description' => 'Displayed title during checkout.',
                    'default'     => 'Pay with Bonzai',
                ),
                'description' => array(
                    'title'       => 'Description',
                    'type'        => 'textarea',
                    'default'     => 'You will be redirected to Bonzai to complete the payment.',
                ),
                'api_token' => array(
                    'title'       => 'API Token',
                    'type'        => 'password',
                    'description' => 'Your Bonzai API token (Bonzai Premium dashboard → API Tokens).',
                ),
                'product_uuid' => array(
                    'title'       => 'Bonzai Product UUID',
                    'type'        => 'text',
                    'description' => 'The Bonzai product UUID used for all WooCommerce purchases.',
                ),
                'redirect_url' => array(
                    'title'       => 'Redirect URL after payment',
                    'type'        => 'text',
                    'default'     => home_url('/thank-you'),
                ),
                'force_currency' => array(
                    'title'       => 'Currency sent to Bonzai',
                    'type'        => 'select',
                    'description' => 'If empty, WooCommerce currency will be used. Bonzai supports EUR or USD.',
                    'default'     => '',
                    'options'     => array(
                        ''    => 'Use WooCommerce currency',
                        'EUR' => 'Force EUR',
                        'USD' => 'Force USD',
                    ),
                ),
                'min_amount' => array(
                    'title'       => 'Minimum amount',
                    'type'        => 'number',
                    'description' => 'Minimum cart total required to enable this payment method. Set 0 to disable.',
                    'default'     => '0',
                    'custom_attributes' => array('step' => '0.01', 'min' => '0'),
                ),
                'timeout' => array(
                    'title'       => 'API Request Timeout (seconds)',
                    'type'        => 'number',
                    'default'     => '20',
                    'custom_attributes' => array('min' => '5', 'step' => '1'),
                ),
                'debug' => array(
                    'title'       => 'Debug Logs',
                    'type'        => 'checkbox',
                    'label'       => 'Enable logs (WooCommerce → Status → Logs)',
                    'default'     => 'no',
                ),

                // VAT handling
                'is_vat_incl_default' => array(
                    'title'       => 'Amounts include VAT?',
                    'type'        => 'select',
                    'description' => 'Default VAT handling for Bonzai amounts. Can be overridden per product.',
                    'default'     => 'yes',
                    'options'     => array(
                        'yes' => 'Yes – prices include VAT',
                        'no'  => 'No – prices are excl. VAT',
                    ),
                ),

                // Automatic order sync
                'order_sync_title' => array(
                    'title'       => 'Automatic Bonzai order sync',
                    'type'        => 'title',
                    'description' => 'Automatically call Bonzai “Retrieve an order” to keep WooCommerce orders in sync.',
                ),
                'order_sync_enabled' => array(
                    'title'       => 'Automatic sync frequency',
                    'type'        => 'select',
                    'default'     => 'no',
                    'options'     => array(
                        'no'     => 'Disabled',
                        'daily'  => 'Daily',
                        'weekly' => 'Weekly',
                    ),
                ),
                'order_sync_hour' => array(
                    'title'       => 'Sync hour (0–23)',
                    'type'        => 'number',
                    'default'     => '3',
                    'custom_attributes' => array('min' => '0', 'max' => '23', 'step' => '1'),
                    'description' => 'Hour of the day (server time) when the automatic sync should run.',
                ),
                'order_sync_day' => array(
                    'title'       => 'Sync weekday (for weekly sync)',
                    'type'        => 'select',
                    'default'     => 'monday',
                    'options'     => array(
                        'monday'    => 'Monday',
                        'tuesday'   => 'Tuesday',
                        'wednesday' => 'Wednesday',
                        'thursday'  => 'Thursday',
                        'friday'    => 'Friday',
                        'saturday'  => 'Saturday',
                        'sunday'    => 'Sunday',
                    ),
                ),

                // Webhooks Bonzai
                'webhook_title' => array(
                    'title'       => 'Bonzai Webhooks',
                    'type'        => 'title',
                    'description' => 'Bonzai sends 2 events: product_access_granted and product_access_revoked. Secured using a simple token.',
                ),
                'webhook_token' => array(
                    'title'       => 'Webhook Token',
                    'type'        => 'text',
                    'description' => 'Click "Generate token" to create a secure random token.',
                ),
                'webhook_url' => array(
                    'title'       => 'Webhook URL',
                    'type'        => 'title',
                    'description' =>
                        '<code id="bonzai-webhook-url-preview" data-base-url="' . esc_attr($base_webhook_url) . '">' .
                            esc_html($base_webhook_url . '?token=YOUR_TOKEN') .
                        '</code><br />' .
                        '<small>Paste it in <a href="https://bonzai.pro/business" target="_blank" rel="noopener noreferrer">bonzai.pro/business</a>.</small>',
                ),
            );
        }

        public function is_available() {
            if ('yes' !== $this->enabled) return false;
            if (empty($this->api_token)) return false;

            $currency = get_woocommerce_currency();
            $target   = $this->force_currency ? $this->force_currency : $currency;

            if (!in_array($target, array('EUR', 'USD'), true)) return false;

            if (function_exists('WC') && WC()->cart) {
                $total = floatval(WC()->cart->total);
                if ($this->min_amount > 0 && $total < $this->min_amount) return false;
            }

            return parent::is_available();
        }

        protected function log($message, $context = array()) {
            if ($this->logger) {
                $this->logger->info('[Bonzai] ' . $message, array('source' => 'bonzai-gateway') + $context);
            }
        }

        protected function fail_with_notice(WC_Order $order, $msg) {
            wc_add_notice($msg, 'error');
            if ($order instanceof WC_Order) {
                $order->add_order_note('Bonzai: ' . $msg);
            }
            $this->log('Error: ' . $msg);
            return array('result' => 'fail');
        }

        public function admin_options() {
            parent::admin_options();
            // Inject JS for token generation + webhook URL preview
            ?>
            <script type="text/javascript">
            (function($){
                $(function(){
                    var $tokenField = $('#woocommerce_bonzai_webhook_token');
                    if (!$tokenField.length) return;

                    // Add generate button
                    var $btn = $('<button type="button" class="button" style="margin-left:8px;">Generate token</button>');
                    $btn.insertAfter($tokenField);

                    var $preview = $('#bonzai-webhook-url-preview');
                    var baseUrl  = $preview.data('base-url') || $preview.text();

                    function updatePreview() {
                        var token = $.trim($tokenField.val());
                        var url = baseUrl;
                        if (token) {
                            url += '?token=' + encodeURIComponent(token);
                        } else {
                            url += '?token=YOUR_TOKEN';
                        }
                        $preview.text(url);
                    }

                    $btn.on('click', function(){
                        // Simple random token generator (32 chars base36)
                        var token = '';
                        while (token.length < 32) {
                            token += Math.random().toString(36).substring(2);
                        }
                        token = token.substring(0, 32);

                        // IMPORTANT: déclencher change pour que WooCommerce active "Save changes"
                        $tokenField.val(token).trigger('change');
                        updatePreview();
                    });

                    $tokenField.on('input change', updatePreview);
                    updatePreview();
                });
            })(jQuery);
            </script>
            <?php
        }

        public function process_payment($order_id) {

            $order = wc_get_order($order_id);
            if (!$order) return array('result' => 'fail');

            if (empty($this->api_token)) {
                return $this->fail_with_notice(
                    $order,
                    'Missing Bonzai API Token. Go to WooCommerce → Payments → Bonzai → Manage.'
                );
            }

            if (empty($this->product_uuid)) {
                return $this->fail_with_notice(
                    $order,
                    'Missing Bonzai Product UUID. Add it in WooCommerce → Payments → Bonzai → Manage.'
                );
            }

            $product_uuid = $this->product_uuid;

            $amount = (float) $order->get_total();
            if ($amount <= 0) {
                return $this->fail_with_notice($order, 'Invalid order amount.');
            }

            // Currency
            $currency = $this->force_currency ? $this->force_currency : get_woocommerce_currency();
            if (!in_array($currency, array('EUR', 'USD'), true)) {
                $currency = 'EUR';
            }

            $email        = $order->get_billing_email() ?: '';
            $redirect_url = $this->redirect_url ?: home_url('/thank-you');
            $redirect_url = add_query_arg(array('wc_order' => $order->get_id()), $redirect_url);

            // === Determine product, VAT handling and payment mode from first line item ===
            $items        = $order->get_items('line_item');
            $product_name = '';
            $item_count   = is_array($items) ? count($items) : 0;

            $is_vat_incl = ($this->is_vat_incl_default === 'yes'); // default
            $mode        = 'one_off';
            $interval    = null;

            if ($item_count > 0 && is_array($items)) {
                foreach ($items as $item) {
                    $product_name = $item->get_name();
                    $product_id   = $item->get_product_id();
                    $product      = $product_id ? wc_get_product($product_id) : null;

                    // VAT override
                    if ($product_id) {
                        $override_vat = get_post_meta($product_id, 'bonzai_is_vat_incl', true); // '', 'yes', 'no'
                        if ($override_vat === 'yes') {
                            $is_vat_incl = true;
                        } elseif ($override_vat === 'no') {
                            $is_vat_incl = false;
                        }
                    }

                    // Payment mode per product
                    $product_mode = $product_id ? get_post_meta($product_id, 'bonzai_payment_mode', true) : '';

                    // Try to auto-detect subscription via WooCommerce Subscriptions if installed
                    if ($product && empty($product_mode)) {
                        if (class_exists('WC_Product_Subscription') && $product instanceof WC_Product_Subscription) {
                            $product_mode = 'subscription_auto';
                        } elseif (class_exists('WC_Product_Variable_Subscription') && $product instanceof WC_Product_Variable_Subscription) {
                            $product_mode = 'subscription_auto';
                        }
                    }

                    if ($product_mode === 'subscription_monthly') {
                        $mode     = 'subscription';
                        $interval = 'month';
                    } elseif ($product_mode === 'subscription_yearly') {
                        $mode     = 'subscription';
                        $interval = 'year';
                    } elseif ($product_mode === 'subscription_auto') {
                        $mode = 'subscription';
                        if (is_callable(array($product, 'get_billing_period'))) {
                            $period = $product->get_billing_period(); // day, week, month, year
                            if ($period === 'year') {
                                $interval = 'year';
                            } else {
                                $interval = 'monthly'; // fallback
                            }
                        } else {
                            $interval = 'month';
                        }
                    } else {
                        // one_off (default)
                        $mode     = 'one_off';
                        $interval = null;
                    }

                    // We only need first line item for mode/title/TVA
                    break;
                }
            }

            // === Title for Bonzai checkout ===
            if ($product_name) {
                if ($item_count > 1) {
                    $bonzai_title = sprintf('%s (+%d more items)', $product_name, $item_count - 1);
                } else {
                    $bonzai_title = $product_name;
                }
            } else {
                $bonzai_title = 'WooCommerce Order #' . $order->get_order_number();
            }

            $payload = array(
                'amount'       => round($amount, 2),
                'currency'     => $currency,
                'title'        => $bonzai_title,
                'redirect_url' => $redirect_url,
                'metadata'     => array(
                    'wc_order_id' => $order->get_id(),
                    'site'        => home_url(),
                ),
                'is_vat_incl'  => $is_vat_incl,
                'mode'         => $mode,
            );

            if ($interval && $mode === 'subscription') {
                $payload['interval'] = $interval;
            }

            if (!empty($email)) {
                $payload['email'] = sanitize_email($email);
            }

            $this->log('Calling Bonzai checkout: ' . wp_json_encode($payload));

            $response = wp_remote_post("https://www.bonzai.pro/api/v1/products/$product_uuid/checkout", array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $this->api_token,
                    'Content-Type'  => 'application/json',
                ),
                'body'    => wp_json_encode($payload),
                'timeout' => max(5, $this->timeout),
            ));

            if (is_wp_error($response)) {
                return $this->fail_with_notice($order, 'Bonzai API error: ' . $response->get_error_message());
            }

            $code_http = (int) wp_remote_retrieve_response_code($response);
            $body_txt  = wp_remote_retrieve_body($response);
            $body      = json_decode($body_txt, true);

            // On log toujours la réponse brute pour debug
            $this->log('Bonzai checkout response HTTP ' . $code_http . ' body=' . $body_txt);

            // Construire un message d'erreur plus parlant si Bonzai renvoie une validation error
            $bonzai_error_msg = '';
            if (is_array($body)) {
                if (!empty($body['message'])) {
                    $bonzai_error_msg = $body['message'];
                } elseif (!empty($body['errors']) && is_array($body['errors'])) {
                    // On prend la première erreur trouvée
                    foreach ($body['errors'] as $field => $messages) {
                        if (is_array($messages) && !empty($messages)) {
                            $bonzai_error_msg = $field . ': ' . reset($messages);
                            break;
                        }
                    }
                }
            }

            // On accepte uniquement les 2xx + checkout_url
            if ($code_http < 200 || $code_http >= 300 || empty($body['checkout_url'])) {
                $note = 'Bonzai API HTTP ' . $code_http . ' → ' . $body_txt;
                $order->add_order_note($note);

                $human_msg = 'Unable to create Bonzai payment.';
                if ($bonzai_error_msg) {
                    $human_msg .= ' Bonzai says: ' . $bonzai_error_msg;
                } else {
                    $human_msg .= ' Please try again later.';
                }

                return $this->fail_with_notice($order, $human_msg);
            }

            $order->update_status('pending', 'Waiting for Bonzai payment.');
            $order->add_order_note('Redirecting to Bonzai. Bonzai order_id: ' . ($body['order_id'] ?? 'n/a'));

            $this->log('Redirect URL: ' . $body['checkout_url']);

            if (!empty($body['order_id'])) {
                update_post_meta($order->get_id(), '_bonzai_order_id', sanitize_text_field($body['order_id']));
                $order->add_order_note('Bonzai: order_id linked ' . $body['order_id']);
            }

            return array(
                'result'   => 'success',
                'redirect' => esc_url_raw($body['checkout_url']),
            );
        }
    }
}

// Register the gateway
add_filter('woocommerce_payment_gateways', function($methods){
    $methods[] = 'WC_Gateway_Bonzai';
    return $methods;
});


/* ===========================
   Bonzai → WooCommerce Webhook
   =========================== */

add_action('rest_api_init', function () {
    register_rest_route('bonzai/v1', '/webhook', array(
        'methods'             => 'POST',
        'callback'            => 'bonzai_handle_webhook',
        'permission_callback' => '__return_true',
    ));
});

function bonzai_get_gateway_instance() {
    if (!function_exists('WC') || !WC()->payment_gateways()) return null;
    $gws = WC()->payment_gateways()->payment_gateways();
    return $gws['bonzai'] ?? null;
}

/** Verify token from query ?token=... or header X-Bonzai-Token */
function bonzai_verify_token(WP_REST_Request $request, $gateway) {
    $configured = trim($gateway->get_option('webhook_token'));
    if ($configured === '') return false;
    $q = (string) $request->get_param('token');
    $h = (string) $request->get_header('x-bonzai-token');
    return hash_equals($configured, $q) || hash_equals($configured, $h);
}

/** Simple idempotence protection */
function bonzai_already_processed($event_id) {
    if (!$event_id) return false;
    $key = 'bonz_evt_' . md5($event_id);
    if (get_transient($key)) return true;
    set_transient($key, 1, DAY_IN_SECONDS);
    return false;
}

/** Find WooCommerce order from Bonzai payload */
function bonzai_find_wc_order_from_payload(array $evt) {
    // 1) Preferred: metadata.wc_order_id
    $wc_id = $evt['order']['metadata']['wc_order_id'] ?? null;
    if ($wc_id) {
        $order = wc_get_order((int) $wc_id);
        if ($order) return $order;
    }

    // 2) Fallback: bonzai_order_id mapped earlier
    $bonzai_order_id = $evt['order_id'] ?? ($evt['order']['id'] ?? null);
    if (!empty($bonzai_order_id)) {
        $orders = wc_get_orders(array(
            'limit'      => 1,
            'meta_key'   => '_bonzai_order_id',
            'meta_value' => (string) $bonzai_order_id,
            'return'     => 'objects',
        ));
        if (!empty($orders)) return $orders[0];
    }

    // 3) Fallback by email
    $email = $evt['user']['email'] ?? '';
    if ($email !== '') {
        $orders = wc_get_orders(array(
            'limit'         => 1,
            'orderby'       => 'date',
            'order'         => 'DESC',
            'status'        => array('pending','on-hold'),
            'billing_email' => $email,
            'return'        => 'objects',
        ));
        if (!empty($orders)) return $orders[0];
    }

    return null;
}

/** Webhook handler following Bonzai docs */
function bonzai_handle_webhook(WP_REST_Request $request) {
    $gw = bonzai_get_gateway_instance();
    if (!$gw) return new WP_REST_Response(array('ok'=>false,'msg'=>'gateway not loaded'), 503);

    if (!bonzai_verify_token($request, $gw)) {
        return new WP_REST_Response(array('ok'=>false,'msg'=>'invalid token'), 401);
    }

    $raw = $request->get_body();
    $evt = json_decode($raw, true);

    if (!is_array($evt)) {
        return new WP_REST_Response(array('ok'=>false,'msg'=>'invalid json'), 400);
    }

    $event_id = $evt['id'] ?? $evt['order_id'] ?? $evt['timestamp'] ?? hash('sha256', $raw);
    if (bonzai_already_processed($event_id)) {
        return new WP_REST_Response(array('ok'=>true,'msg'=>'duplicate'), 200);
    }

    $type  = $evt['event_type'] ?? 'unknown';
    $order = bonzai_find_wc_order_from_payload($evt);

    if (!$order) {
        if (function_exists('wc_get_logger')) {
            wc_get_logger()->warning(
                '[Bonzai] Webhook received without wc_order_id: ' . $raw,
                array('source'=>'bonzai-gateway')
            );
        }
        return new WP_REST_Response(array('ok'=>true,'msg'=>'no wc order'), 200);
    }

    switch ($type) {
        case 'product_access_granted':
            if (!$order->is_paid()) {
                $order->payment_complete();
                $order->add_order_note('Bonzai: product_access_granted → payment confirmed.');
            }
            break;

        case 'product_access_revoked':
            $target = 'refunded';
            if ($order->get_status() !== $target) {
                $order->update_status($target, 'Bonzai: product_access_revoked.');
            }
            break;

        default:
            $order->add_order_note('Bonzai: unhandled event ' . esc_html($type) . '.');
            break;
    }

    return new WP_REST_Response(array('ok'=>true), 200);
}

// Add note when customer returns but order not yet paid
add_action('template_redirect', function(){
    if (!isset($_GET['wc_order'])) return;
    $order = wc_get_order(absint($_GET['wc_order']));
    if (!$order || $order->is_paid()) return;
    $order->add_order_note('Customer returned to the redirect page. Waiting for Bonzai webhook.');
});

// Force completed status when payment is confirmed
add_filter('woocommerce_payment_complete_order_status', function($status, $order_id, $order){
    if ($order instanceof WC_Order && $order->get_payment_method() === 'bonzai') {
        return 'completed';
    }
    return $status;
}, 10, 3);


/* ===========================
   Product-level options (VAT + payment mode)
   =========================== */

add_action('woocommerce_product_options_general_product_data', 'bonzai_product_fields');

function bonzai_product_fields() {
    echo '<div class="options_group">';

    // VAT handling per product
    woocommerce_wp_select(array(
        'id'          => 'bonzai_is_vat_incl',
        'label'       => 'Bonzai VAT handling',
        'description' => 'Override Bonzai VAT handling for this product. If set to “Inherit”, the global gateway setting is used.',
        'desc_tip'    => true,
        'options'     => array(
            ''     => 'Inherit from gateway setting',
            'yes'  => 'Amount includes VAT',
            'no'   => 'Amount excludes VAT',
        ),
    ));

    // Payment mode per product
    woocommerce_wp_select(array(
        'id'          => 'bonzai_payment_mode',
        'label'       => 'Bonzai payment mode',
        'description' => 'Choose how this product should be charged in Bonzai. If set to “Inherit”, the plugin assumes a one-off payment unless it detects a subscription product type.',
        'desc_tip'    => true,
        'options'     => array(
            ''                     => 'Inherit / auto-detect',
            'one_off'              => 'One-off payment',
            'subscription_monthly' => 'Subscription – monthly',
            'subscription_yearly'  => 'Subscription – yearly',
        ),
    ));

    echo '</div>';
}

add_action('woocommerce_process_product_meta', 'bonzai_save_product_fields');

function bonzai_save_product_fields($post_id) {
    if (isset($_POST['bonzai_is_vat_incl'])) {
        $value = wc_clean(wp_unslash($_POST['bonzai_is_vat_incl']));
        if (!in_array($value, array('', 'yes', 'no'), true)) {
            $value = '';
        }
        update_post_meta($post_id, 'bonzai_is_vat_incl', $value);
    }

    if (isset($_POST['bonzai_payment_mode'])) {
        $mode = wc_clean(wp_unslash($_POST['bonzai_payment_mode']));
        if (!in_array($mode, array('', 'one_off', 'subscription_monthly', 'subscription_yearly'), true)) {
            $mode = '';
        }
        update_post_meta($post_id, 'bonzai_payment_mode', $mode);
    }
}


/* ===========================
   Retrieve an order helpers
   =========================== */

/**
 * Call Bonzai "Retrieve an order" endpoint.
 *
 * @param string             $bonzai_order_id
 * @param WC_Gateway_Bonzai  $gateway
 * @return array|WP_Error
 */
function bonzai_api_retrieve_order($bonzai_order_id, $gateway) {
    $bonzai_order_id = trim((string) $bonzai_order_id);
    if ($bonzai_order_id === '') {
        return new WP_Error('bonzai_no_order_id', 'Missing Bonzai order_id');
    }

    $api_token = trim($gateway->api_token);
    if ($api_token === '') {
        return new WP_Error('bonzai_no_token', 'Missing Bonzai API token');
    }

    $url = 'https://www.bonzai.pro/api/v1/orders/' . rawurlencode($bonzai_order_id);

    $response = wp_remote_get($url, array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_token,
            'Accept'        => 'application/json',
        ),
        'timeout' => max(5, (int) $gateway->timeout),
    ));

    if (is_wp_error($response)) {
        if ($gateway->debug) {
            $gateway->log('Retrieve order error: ' . $response->get_error_message());
        }
        return $response;
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);

    if ($code !== 200 || !is_array($body)) {
        if ($gateway->debug) {
            $gateway->log('Retrieve order HTTP ' . $code . ' body: ' . wp_json_encode($body));
        }
        return new WP_Error('bonzai_bad_response', 'Unexpected response from Bonzai retrieve order', array(
            'code' => $code,
            'body' => $body,
        ));
    }

    return $body;
}

/**
 * Sync a WooCommerce order with a Bonzai order payload.
 *
 * Uses has_access / intent_status / subscription_status to decide what to do.
 */
function bonzai_sync_wc_order_with_bonzai(WC_Order $order, array $api_order) {
    $has_access          = isset($api_order['has_access']) ? (bool) $api_order['has_access'] : null;
    $intent_status       = $api_order['intent_status'] ?? null;
    $subscription_status = $api_order['subscription_status'] ?? null;

    $status_note = sprintf(
        'Bonzai sync: intent_status=%s, subscription_status=%s, has_access=%s',
        $intent_status !== null ? $intent_status : 'null',
        $subscription_status !== null ? $subscription_status : 'null',
        $has_access === null ? 'null' : ($has_access ? 'true' : 'false')
    );
    $order->add_order_note($status_note);

    $current_status = $order->get_status();

    if ($has_access === true) {
        // Accès actif côté Bonzai → on s’assure que la commande est bien payée/completed
        if (!$order->is_paid()) {
            $order->payment_complete();
            $order->add_order_note('Bonzai sync: access active → order marked as paid.');
        } elseif ($current_status !== 'completed') {
            $order->update_status('completed', 'Bonzai sync: access still active → order completed.');
        }

    } elseif ($has_access === false) {
        // Accès non actif / révoqué côté Bonzai
        // On ne met "refunded" que si la commande était vraiment active (payée)
        $refundable_statuses = array('processing', 'completed', 'on-hold');

        if (in_array($current_status, $refundable_statuses, true)) {
            if ($current_status !== 'refunded') {
                $order->update_status('refunded', 'Bonzai sync: access revoked or expired → order refunded.');
            }
        } else {
            // Pour les commandes jamais payées (pending, cancelled, failed...), on ne change pas le statut,
            // on laisse juste une note explicative.
            $order->add_order_note(
                'Bonzai sync: access is not active (has_access=false) but order status is "' .
                $current_status .
                '", so status was not changed.'
            );
        }
    }
}



/* ===========================
   Automatic scheduled sync (cron)
   =========================== */

add_action('init', 'bonzai_register_cron_event');

function bonzai_register_cron_event() {
    if (!wp_next_scheduled('bonzai_cron_order_sync')) {
        // Run hourly and we’ll decide inside when to actually sync
        wp_schedule_event(time() + HOUR_IN_SECONDS, 'hourly', 'bonzai_cron_order_sync');
    }
}

add_action('bonzai_cron_order_sync', 'bonzai_run_cron_order_sync');

function bonzai_run_cron_order_sync() {
    $gw = bonzai_get_gateway_instance();
    if (!$gw) return;

    $mode = $gw->order_sync_enabled ?? 'no';
    if ($mode === 'no') return;

    $hour_config = isset($gw->order_sync_hour) ? (int) $gw->order_sync_hour : 3;
    $day_config  = isset($gw->order_sync_day) ? strtolower($gw->order_sync_day) : 'monday';

    $now      = current_datetime();
    $hour_now = (int) $now->format('G');         // 0–23
    $day_now  = strtolower($now->format('l'));   // monday...

    if ($hour_now !== $hour_config) {
        return; // only run once per chosen hour
    }

    if ($mode === 'daily') {
        $today = $now->format('Y-m-d');
        $last  = get_option('bonzai_sync_last_daily');
        if ($last === $today) {
            return;
        }
        update_option('bonzai_sync_last_daily', $today);
    } elseif ($mode === 'weekly') {
        if ($day_now !== $day_config) {
            return;
        }
        $yearweek = $now->format('o-W');
        $last     = get_option('bonzai_sync_last_weekly');
        if ($last === $yearweek) {
            return;
        }
        update_option('bonzai_sync_last_weekly', $yearweek);
    } else {
        return;
    }

    if ($gw->debug) {
        $gw->log('Starting automatic Bonzai order sync via cron.');
    }

    // Fetch all orders that have a Bonzai order_id meta
    $orders = wc_get_orders(array(
        'limit'      => -1,
        'meta_key'   => '_bonzai_order_id',
        'meta_compare' => 'EXISTS',
        'status'     => array('pending','on-hold','processing','completed','refunded','cancelled'),
        'return'     => 'objects',
    ));

    if (empty($orders)) {
        if ($gw->debug) $gw->log('Automatic sync: no orders with Bonzai order_id found.');
        return;
    }

    foreach ($orders as $order) {
        $bonzai_order_id = get_post_meta($order->get_id(), '_bonzai_order_id', true);
        if (!$bonzai_order_id) continue;

        $api_order = bonzai_api_retrieve_order($bonzai_order_id, $gw);
        if (is_wp_error($api_order)) {
            if ($gw->debug) {
                $gw->log('Automatic sync error for order #' . $order->get_id() . ': ' . $api_order->get_error_message());
            }
            $order->add_order_note('Bonzai automatic sync error: ' . $api_order->get_error_message());
            continue;
        }

        bonzai_sync_wc_order_with_bonzai($order, $api_order);
    }

    if ($gw->debug) {
        $gw->log('Automatic Bonzai order sync finished.');
    }
}


/* ===========================
   Manual admin sync page
   =========================== */

add_action('admin_menu', 'bonzai_register_admin_page');

function bonzai_register_admin_page() {
    add_submenu_page(
        'woocommerce',
        'Bonzai Order Sync',
        'Bonzai Order Sync',
        'manage_woocommerce',
        'bonzai-order-sync',
        'bonzai_render_order_sync_page'
    );
}

function bonzai_render_order_sync_page() {
    if (!current_user_can('manage_woocommerce')) {
        wp_die('You do not have permission to access this page.');
    }

    $gw = bonzai_get_gateway_instance();
    if (!$gw) {
        echo '<div class="notice notice-error"><p>Bonzai gateway is not loaded.</p></div>';
        return;
    }

    $orders       = array();
    $search_email = '';
    $message      = '';

    // ==========================
    // Handle search form
    // ==========================
    if (isset($_POST['bonzai_search_email']) && isset($_POST['bonzai_search_nonce'])) {

        $search_email = sanitize_email(wp_unslash($_POST['bonzai_search_email']));
        $nonce        = sanitize_text_field(wp_unslash($_POST['bonzai_search_nonce']));

        if (!wp_verify_nonce($nonce, 'bonzai_search_orders')) {
            $message = 'Security check failed for search. Please reload the page and try again.';
        } elseif ($search_email) {
            $orders = wc_get_orders(array(
                'limit'         => 50,
                'orderby'       => 'date',
                'order'         => 'DESC',
                'billing_email' => $search_email,
                'return'        => 'objects',
            ));
            if (empty($orders)) {
                $message = 'No orders found for this email.';
            }
        } else {
            $message = 'Please enter a valid email address.';
        }
    }

    // ==========================
    // Handle single order sync
    // ==========================
    if (isset($_POST['bonzai_sync_order_id'])) {

        // Vérification manuelle du nonce pour éviter "The link you followed has expired"
        $nonce = isset($_POST['_wpnonce']) ? sanitize_text_field(wp_unslash($_POST['_wpnonce'])) : '';

        if (!wp_verify_nonce($nonce, 'bonzai_sync_single_order')) {
            $message = 'Security check failed. Please reload the page and try again.';
        } else {

            $order_id = absint($_POST['bonzai_sync_order_id']);
            $order    = wc_get_order($order_id);

            if ($order) {
                $bonzai_order_id = get_post_meta($order_id, '_bonzai_order_id', true);

                if (!$bonzai_order_id) {
                    $message = 'This order does not have a Bonzai order_id. It was probably never redirected to Bonzai.';
                } else {
                    $api_order = bonzai_api_retrieve_order($bonzai_order_id, $gw);

                    if (is_wp_error($api_order)) {

                        // Rendre le message plus clair si Bonzai ne trouve pas l’order
                        $error_msg = $api_order->get_error_message();
                        $data      = $api_order->get_error_data();

                        if (is_array($data) && isset($data['code']) && (int) $data['code'] === 404) {
                            $error_msg = 'Bonzai order not found (it may be expired, cancelled or was never created).';
                        }

                        // Si la commande Woo est déjà cancelled/failed, on le précise
                        if (in_array($order->get_status(), array('cancelled', 'failed'), true)) {
                            $error_msg .= ' This WooCommerce order is currently "' . $order->get_status() . '", so access is not active.';
                        }

                        $message = 'Error while retrieving order from Bonzai: ' . esc_html($error_msg);
                        $order->add_order_note('Bonzai manual sync error: ' . $error_msg);

                    } else {
                        bonzai_sync_wc_order_with_bonzai($order, $api_order);
                        $message = 'Bonzai order synced successfully for WooCommerce order #' . $order_id . '.';
                    }
                }
            } else {
                $message = 'Invalid WooCommerce order ID.';
            }

            // Recharger la liste des commandes pour le même email après sync
            if (isset($_POST['bonzai_search_email'])) {
                $search_email = sanitize_email(wp_unslash($_POST['bonzai_search_email']));
                if ($search_email) {
                    $orders = wc_get_orders(array(
                        'limit'         => 50,
                        'orderby'       => 'date',
                        'order'         => 'DESC',
                        'billing_email' => $search_email,
                        'return'        => 'objects',
                    ));
                }
            }
        }
    }

    // ==========================
    // Rendu de la page
    // ==========================
    echo '<div class="wrap"><h1>Bonzai Order Sync</h1>';

    if ($message) {
        echo '<div class="notice notice-info is-dismissible"><p>' . esc_html($message) . '</p></div>';
    }

    echo '<h2>Search orders by customer email</h2>';
    echo '<form method="post">';
    // nonce spécifique pour la recherche
    wp_nonce_field('bonzai_search_orders', 'bonzai_search_nonce');
    echo '<p><label for="bonzai_search_email">Customer email:</label> ';
    echo '<input type="email" id="bonzai_search_email" name="bonzai_search_email" value="' . esc_attr($search_email) . '" size="40" /> ';
    submit_button('Search orders', 'secondary', 'submit', false);
    echo '</p></form>';

    if (!empty($orders)) {
        echo '<h2>Orders for ' . esc_html($search_email) . '</h2>';
        echo '<table class="widefat striped">';
        echo '<thead><tr><th>Order ID</th><th>Date</th><th>Status</th><th>Total</th><th>Bonzai order_id</th><th>Action</th></tr></thead><tbody>';

        foreach ($orders as $order) {
            $bonzai_order_id = get_post_meta($order->get_id(), '_bonzai_order_id', true);
            echo '<tr>';
            echo '<td><a href="' . esc_url(get_edit_post_link($order->get_id())) . '">#' . esc_html($order->get_id()) . '</a></td>';
            echo '<td>' . esc_html($order->get_date_created() ? $order->get_date_created()->date_i18n('Y-m-d H:i') : '') . '</td>';
            echo '<td>' . esc_html(wc_get_order_status_name($order->get_status())) . '</td>';
            echo '<td>' . wp_kses_post($order->get_formatted_order_total()) . '</td>';
            echo '<td>' . esc_html($bonzai_order_id ?: '—') . '</td>';
            echo '<td>';
            if ($bonzai_order_id) {
                echo '<form method="post" style="display:inline;">';
                wp_nonce_field('bonzai_sync_single_order');
                echo '<input type="hidden" name="bonzai_search_email" value="' . esc_attr($search_email) . '" />';
                echo '<input type="hidden" name="bonzai_sync_order_id" value="' . esc_attr($order->get_id()) . '" />';
                submit_button('Sync with Bonzai', 'primary', 'submit', false);
                echo '</form>';
            } else {
                echo 'No Bonzai order_id';
            }
            echo '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
    }

    echo '</div>';
}
