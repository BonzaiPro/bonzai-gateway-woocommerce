<?php
/*
Plugin Name: Bonzai Payment Gateway
Description: Payment via Bonzai Checkout with confirmation webhooks.
Version: 1.3.1
Author: Ramy
*/

if (!defined('ABSPATH')) exit;

add_action('plugins_loaded', 'bonzai_init_gateway_class');

function bonzai_init_gateway_class() {

    class WC_Gateway_Bonzai extends WC_Payment_Gateway {

        /** @var WC_Logger|null */
        protected $logger = null;

        public function __construct() {
            $this->id                 = 'bonzai';
            $this->icon               = '';
            $this->has_fields         = false;
            $this->method_title       = 'Bonzai';
            $this->method_description = 'Pay through Bonzai Checkout.';
            $this->supports           = array('products');

            $this->init_form_fields();
            $this->init_settings();

            // Settings
            $this->title          = $this->get_option('title');
            $this->description    = $this->get_option('description');
            $this->enabled        = $this->get_option('enabled');
            $this->api_token      = trim($this->get_option('api_token'));
            $this->product_uuid   = trim($this->get_option('product_uuid'));
            $this->redirect_url   = trim($this->get_option('redirect_url'));
            $this->debug          = wc_string_to_bool($this->get_option('debug', 'no'));
            $this->timeout        = absint($this->get_option('timeout', 20));
            $this->force_currency = strtoupper(trim($this->get_option('force_currency', '')));
            $this->min_amount     = floatval($this->get_option('min_amount', 0));

            $this->webhook_token  = trim($this->get_option('webhook_token', ''));

            if ($this->debug) {
                $this->logger = wc_get_logger();
            }

            add_action(
                'woocommerce_update_options_payment_gateways_' . $this->id,
                array($this, 'process_admin_options')
            );
        }

        public function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title'   => 'Enable',
                    'type'    => 'checkbox',
                    'label'   => 'Enable Bonzai Checkout',
                    'default' => 'yes',
                ),
                'title' => array(
                    'title'       => 'Title',
                    'type'        => 'text',
                    'description' => 'Displayed title during checkout.',
                    'default' => 'Pay with Bonzai',
                ),
                'description' => array(
                    'title'       => 'Description',
                    'type'        => 'textarea',
                    'default' => 'You will be redirected to Bonzai to complete the payment.',
                ),
                'api_token' => array(
                    'title'       => 'API Token',
                    'type'        => 'password',
                    'description' => 'Your Bonzai API token (Bonzai dashboard → API Tokens).',
                ),
                'product_uuid' => array(
                    'title'       => 'Bonzai Product UUID',
                    'type'        => 'text',
                    'description' => 'The Bonzai product UUID used for all WooCommerce purchases.',
                ),
                'redirect_url' => array(
                    'title'       => 'Redirect URL after payment',
                    'type'        => 'text',
                    'default'     => home_url('/thank-you'),
                ),
                'force_currency' => array(
                    'title'       => 'Currency sent to Bonzai',
                    'type'        => 'select',
                    'description' => 'If left empty, WooCommerce currency will be used. Bonzai supports EUR or USD.',
                    'default'     => '',
                    'options'     => array(
                        ''    => 'Use WooCommerce currency',
                        'EUR' => 'Force EUR',
                        'USD' => 'Force USD',
                    ),
                ),
                'min_amount' => array(
                    'title'       => 'Minimum amount',
                    'type'        => 'number',
                    'description' => 'Minimum cart total required to enable this payment method. Set 0 to disable.',
                    'default'     => '0',
                    'custom_attributes' => array('step' => '0.01', 'min' => '0'),
                ),
                'timeout' => array(
                    'title'       => 'API Request Timeout (seconds)',
                    'type'        => 'number',
                    'default'     => '20',
                    'custom_attributes' => array('min' => '5', 'step' => '1'),
                ),
                'debug' => array(
                    'title'       => 'Debug Logs',
                    'type'        => 'checkbox',
                    'label'       => 'Enable logs (WooCommerce → Status → Logs)',
                    'default'     => 'no',
                ),

                // Webhooks
                'webhook_title' => array(
                    'title'       => 'Bonzai Webhooks',
                    'type'        => 'title',
                    'description' => 'Bonzai sends 2 events: product_access_granted and product_access_revoked. Secured using a simple token.',
                ),
                'webhook_token' => array(
                    'title'       => 'Webhook Token',
                    'type'        => 'text',
                    'description' => 'Required. The webhook must include this token in the query (?token=...) or X-Bonzai-Token header.',
                ),
                'webhook_url' => array(
                    'title'       => 'Webhook URL',
                    'type'        => 'title',
                    'description' => '<code>' . esc_html(rest_url('bonzai/v1/webhook') . '?token=YOUR_TOKEN') . '</code>',
                ),
            );
        }

        public function is_available() {
            if ('yes' !== $this->enabled) return false;
            if (empty($this->api_token)) return false;

            $currency = get_woocommerce_currency();
            $target   = $this->force_currency ? $this->force_currency : $currency;

            if (!in_array($target, array('EUR', 'USD'), true)) return false;

            if (function_exists('WC') && WC()->cart) {
                $total = floatval(WC()->cart->total);
                if ($this->min_amount > 0 && $total < $this->min_amount) return false;
            }

            return parent::is_available();
        }

        protected function log($message, $context = array()) {
            if ($this->logger) {
                $this->logger->info('[Bonzai] ' . $message, array('source' => 'bonzai-gateway') + $context);
            }
        }

        protected function fail_with_notice(WC_Order $order, $msg) {
            wc_add_notice($msg, 'error');
            if ($order instanceof WC_Order) {
                $order->add_order_note('Bonzai: ' . $msg);
            }
            $this->log('Error: ' . $msg);
            return array('result' => 'fail');
        }

        public function process_payment($order_id) {

            $order = wc_get_order($order_id);
            if (!$order) return array('result' => 'fail');

            if (empty($this->api_token)) {
                return $this->fail_with_notice(
                    $order,
                    'Missing Bonzai API Token. Go to WooCommerce → Payments → Bonzai → Manage.'
                );
            }

            if (empty($this->product_uuid)) {
                return $this->fail_with_notice(
                    $order,
                    'Missing Bonzai Product UUID. Add it in WooCommerce → Payments → Bonzai → Manage.'
                );
            }

            $product_uuid = $this->product_uuid;

            $amount = (float) $order->get_total();
            if ($amount <= 0) {
                return $this->fail_with_notice($order, 'Invalid order amount.');
            }

            $currency = $this->force_currency ? $this->force_currency : get_woocommerce_currency();
            if (!in_array($currency, array('EUR', 'USD'), true)) $currency = 'EUR';

            $email        = $order->get_billing_email() ?: '';
            $redirect_url = $this->redirect_url ?: home_url('/thank-you');
            $redirect_url = add_query_arg(array('wc_order' => $order->get_id()), $redirect_url);

            $items        = $order->get_items('line_item');
            $product_name = '';
            $item_count   = is_array($items) ? count($items) : 0;

            if ($item_count > 0) {
                // Take the first line item name
                foreach ($items as $item) {
                    $product_name = $item->get_name();
                    break;
                }
            }

            if ($product_name) {
                if ($item_count > 1) {
                    // Example: "My Course (+2 more items)"
                    $bonzai_title = sprintf('%s (+%d more items)', $product_name, $item_count - 1);
                } else {
                    // Single product
                    $bonzai_title = $product_name;
                }
            } else {
                // Fallback if something goes wrong
                $bonzai_title = 'WooCommerce Order #' . $order->get_order_number();
            }

            $payload = array(
                'amount'       => round($amount, 2),
                'currency'     => $currency,
                'title'        => $bonzai_title,
                'redirect_url' => $redirect_url,
                'metadata'     => array(
                    'wc_order_id' => $order->get_id(),
                    'site'        => home_url(),
                ),
                'is_vat_incl'  => true,
                'mode'         => 'one_off',
            );

            if (!empty($email)) {
                $payload['email'] = sanitize_email($email);
            }

            $this->log('Calling Bonzai checkout: ' . wp_json_encode($payload));

            $response = wp_remote_post("https://www.bonzai.pro/api/v1/products/$product_uuid/checkout", array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $this->api_token,
                    'Content-Type'  => 'application/json',
                ),
                'body'    => wp_json_encode($payload),
                'timeout' => max(5, $this->timeout),
            ));

            if (is_wp_error($response)) {
                return $this->fail_with_notice($order, 'Bonzai API error: ' . $response->get_error_message());
            }

            $code_http = (int) wp_remote_retrieve_response_code($response);
            $body_txt  = wp_remote_retrieve_body($response);
            $body      = json_decode($body_txt, true);

            if ($code_http !== 200 || empty($body['checkout_url'])) {
                $order->add_order_note('Bonzai API ' . $code_http . ' → ' . $body_txt);
                return $this->fail_with_notice($order, 'Unable to create Bonzai payment. Please try again later.');
            }

            $order->update_status('pending', 'Waiting for Bonzai payment.');
            $order->add_order_note('Redirecting to Bonzai. Bonzai order_id: ' . ($body['order_id'] ?? 'n/a'));

            $this->log('Redirect URL: ' . $body['checkout_url']);

            if (!empty($body['order_id'])) {
                update_post_meta($order->get_id(), '_bonzai_order_id', sanitize_text_field($body['order_id']));
                $order->add_order_note('Bonzai: order_id linked ' . $body['order_id']);
            }

            return array(
                'result'   => 'success',
                'redirect' => esc_url_raw($body['checkout_url']),
            );
        }
    }
}

// Register the gateway
add_filter('woocommerce_payment_gateways', function($methods){
    $methods[] = 'WC_Gateway_Bonzai';
    return $methods;
});


/* ===========================
   Bonzai → WooCommerce Webhook
   =========================== */

add_action('rest_api_init', function () {
    register_rest_route('bonzai/v1', '/webhook', array(
        'methods'             => 'POST',
        'callback'            => 'bonzai_handle_webhook',
        'permission_callback' => '__return_true',
    ));
});

function bonzai_get_gateway_instance() {
    if (!function_exists('WC') || !WC()->payment_gateways()) return null;
    $gws = WC()->payment_gateways()->payment_gateways();
    return $gws['bonzai'] ?? null;
}

function bonzai_verify_token(WP_REST_Request $request, $gateway) {
    $configured = trim($gateway->get_option('webhook_token'));
    if ($configured === '') return false;
    $q = (string) $request->get_param('token');
    $h = (string) $request->get_header('x-bonzai-token');
    return hash_equals($configured, $q) || hash_equals($configured, $h);
}

function bonzai_already_processed($event_id) {
    if (!$event_id) return false;
    $key = 'bonz_evt_' . md5($event_id);
    if (get_transient($key)) return true;
    set_transient($key, 1, DAY_IN_SECONDS);
    return false;
}

function bonzai_find_wc_order_from_payload(array $evt) {

    $wc_id = $evt['order']['metadata']['wc_order_id'] ?? null;
    if ($wc_id) {
        $order = wc_get_order((int) $wc_id);
        if ($order) return $order;
    }

    $bonzai_order_id = $evt['order_id'] ?? ($evt['order']['id'] ?? null);
    if (!empty($bonzai_order_id)) {
        $orders = wc_get_orders(array(
            'limit'      => 1,
            'meta_key'   => '_bonzai_order_id',
            'meta_value' => (string) $bonzai_order_id,
            'return'     => 'objects',
        ));
        if (!empty($orders)) return $orders[0];
    }

    $email = $evt['user']['email'] ?? '';
    if ($email !== '') {
        $orders = wc_get_orders(array(
            'limit'         => 1,
            'orderby'       => 'date',
            'order'         => 'DESC',
            'status'        => array('pending','on-hold'),
            'billing_email' => $email,
            'return'        => 'objects',
        ));
        if (!empty($orders)) return $orders[0];
    }

    return null;
}

function bonzai_handle_webhook(WP_REST_Request $request) {

    $gw = bonzai_get_gateway_instance();
    if (!$gw) return new WP_REST_Response(array('ok'=>false,'msg'=>'gateway not loaded'), 503);

    if (!bonzai_verify_token($request, $gw)) {
        return new WP_REST_Response(array('ok'=>false,'msg'=>'invalid token'), 401);
    }

    $raw = $request->get_body();
    $evt = json_decode($raw, true);

    if (!is_array($evt)) {
        return new WP_REST_Response(array('ok'=>false,'msg'=>'invalid json'), 400);
    }

    $event_id = $evt['id'] ?? $evt['order_id'] ?? $evt['timestamp'] ?? hash('sha256', $raw);

    if (bonzai_already_processed($event_id)) {
        return new WP_REST_Response(array('ok'=>true,'msg'=>'duplicate'), 200);
    }

    $type  = $evt['event_type'] ?? 'unknown';
    $order = bonzai_find_wc_order_from_payload($evt);

    if (!$order) {
        if (function_exists('wc_get_logger')) {
            wc_get_logger()->warning(
                '[Bonzai] Webhook received without wc_order_id: ' . $raw,
                array('source'=>'bonzai-gateway')
            );
        }
        return new WP_REST_Response(array('ok'=>true,'msg'=>'no wc order'), 200);
    }

    switch ($type) {

        case 'product_access_granted':
            if (!$order->is_paid()) {
                $order->payment_complete();
                $order->add_order_note('Bonzai: product_access_granted → payment confirmed.');
            }
            break;

        case 'product_access_revoked':
            $target = 'refunded';
            if ($order->get_status() !== $target) {
                $order->update_status($target, 'Bonzai: product_access_revoked.');
            }
            break;

        default:
            $order->add_order_note('Bonzai: unhandled event ' . esc_html($type) . '.');
            break;
    }

    return new WP_REST_Response(array('ok'=>true), 200);
}

add_action('template_redirect', function(){
    if (!isset($_GET['wc_order'])) return;
    $order = wc_get_order(absint($_GET['wc_order']));
    if (!$order || $order->is_paid()) return;
    $order->add_order_note('Customer returned to the redirect page. Waiting for Bonzai webhook.');
});

add_filter('woocommerce_payment_complete_order_status', function($status, $order_id, $order){
    if ($order instanceof WC_Order && $order->get_payment_method() === 'bonzai') {
        return 'completed';
    }
    return $status;
}, 10, 3);
