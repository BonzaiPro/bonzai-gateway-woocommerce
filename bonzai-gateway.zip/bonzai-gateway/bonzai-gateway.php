<?php
/*
Plugin Name: Bonzai Payment Gateway
Description: Payment via Bonzai Checkout with confirmation webhooks and order sync.
Version: 1.5.1
Author: Ramy
*/

if (!defined('ABSPATH')) exit;

add_action('plugins_loaded', 'bonzai_init_gateway_class');

function bonzai_init_gateway_class() {

    class WC_Gateway_Bonzai extends WC_Payment_Gateway {

        protected $logger = null;

        public function __construct() {
            $this->id                 = 'bonzai';
            $this->icon               = '';
            $this->has_fields         = false;
            $this->method_title       = 'Bonzai';
            $this->method_description = 'Pay through Bonzai Checkout.';
            $this->supports           = array('products');

            $this->init_form_fields();
            $this->init_settings();

            $this->title               = $this->get_option('title');
            $this->description         = $this->get_option('description');
            $this->enabled             = $this->get_option('enabled');
            $this->api_token           = trim($this->get_option('api_token'));
            $this->product_uuid        = trim($this->get_option('product_uuid'));
            $this->redirect_url        = trim($this->get_option('redirect_url'));
            $this->debug               = wc_string_to_bool($this->get_option('debug', 'no'));
            $this->timeout             = absint($this->get_option('timeout', 20));
            $this->force_currency      = strtoupper(trim($this->get_option('force_currency', '')));
            $this->min_amount          = floatval($this->get_option('min_amount', 0));
            $this->webhook_token       = trim($this->get_option('webhook_token', ''));
            $this->is_vat_incl_default = $this->get_option('is_vat_incl_default', 'yes');
            $this->order_sync_enabled  = $this->get_option('order_sync_enabled', 'no');
            $this->order_sync_hour     = intval($this->get_option('order_sync_hour', 3));
            $this->order_sync_day      = strtolower($this->get_option('order_sync_day', 'monday'));

            if ($this->debug) {
                $this->logger = wc_get_logger();
            }

            add_action(
                'woocommerce_update_options_payment_gateways_' . $this->id,
                array($this, 'process_admin_options')
            );
        }

        public function init_form_fields() {
            $base_webhook_url = rest_url('bonzai/v1/webhook');

            $this->form_fields = array(
                'enabled' => array(
                    'title'   => 'Enable',
                    'type'    => 'checkbox',
                    'label'   => 'Enable Bonzai Checkout',
                    'default' => 'yes',
                ),
                'title' => array(
                    'title'       => 'Title',
                    'type'        => 'text',
                    'description' => 'Displayed title during checkout.',
                    'default'     => 'Pay with Bonzai',
                ),
                'description' => array(
                    'title'       => 'Description',
                    'type'        => 'textarea',
                    'default'     => 'You will be redirected to Bonzai to complete the payment.',
                ),
                'api_token' => array(
                    'title'       => 'API Token',
                    'type'        => 'password',
                    'description' => 'Your Bonzai API token (Bonzai Premium dashboard → API Tokens).',
                ),
                'product_uuid' => array(
                    'title'       => 'Bonzai Product UUID',
                    'type'        => 'text',
                    'description' => 'The Bonzai product UUID used for all WooCommerce purchases.',
                ),
                'redirect_url' => array(
                    'title'       => 'Redirect URL after payment',
                    'type'        => 'text',
                    'default'     => home_url('/thank-you'),
                ),
                'force_currency' => array(
                    'title'       => 'Currency sent to Bonzai',
                    'type'        => 'select',
                    'description' => 'If empty, WooCommerce currency will be used. Bonzai supports EUR or USD.',
                    'default'     => '',
                    'options'     => array(
                        ''    => 'Use WooCommerce currency',
                        'EUR' => 'Force EUR',
                        'USD' => 'Force USD',
                    ),
                ),
                'min_amount' => array(
                    'title'       => 'Minimum amount',
                    'type'        => 'number',
                    'description' => 'Minimum cart total required to enable this payment method. Set 0 to disable.',
                    'default'     => '0',
                    'custom_attributes' => array('step' => '0.01', 'min' => '0'),
                ),
                'timeout' => array(
                    'title'       => 'API Request Timeout (seconds)',
                    'type'        => 'number',
                    'default'     => '20',
                    'custom_attributes' => array('min' => '5', 'step' => '1'),
                ),
                'debug' => array(
                    'title'       => 'Debug Logs',
                    'type'        => 'checkbox',
                    'label'       => 'Enable logs (WooCommerce → Status → Logs)',
                    'default'     => 'no',
                ),

                'is_vat_incl_default' => array(
                    'title'       => 'Amounts include VAT?',
                    'type'        => 'select',
                    'description' => 'Default VAT handling for Bonzai amounts. Can be overridden per product.',
                    'default'     => 'yes',
                    'options'     => array(
                        'yes' => 'Yes, prices include VAT',
                        'no'  => 'No, prices are excl. VAT',
                    ),
                ),

                'order_sync_title' => array(
                    'title'       => 'Automatic Bonzai order sync',
                    'type'        => 'title',
                    'description' => 'Automatically call Bonzai Retrieve an order to keep WooCommerce orders in sync.',
                ),
                'order_sync_enabled' => array(
                    'title'       => 'Automatic sync frequency',
                    'type'        => 'select',
                    'default'     => 'no',
                    'options'     => array(
                        'no'     => 'Disabled',
                        'daily'  => 'Daily',
                        'weekly' => 'Weekly',
                    ),
                ),
                'order_sync_hour' => array(
                    'title'       => 'Sync hour (0 to 23)',
                    'type'        => 'number',
                    'default'     => '3',
                    'custom_attributes' => array('min' => '0', 'max' => '23', 'step' => '1'),
                    'description' => 'Hour of the day (server time) when the automatic sync should run.',
                ),
                'order_sync_day' => array(
                    'title'       => 'Sync weekday (weekly sync)',
                    'type'        => 'select',
                    'default'     => 'monday',
                    'options'     => array(
                        'monday'    => 'Monday',
                        'tuesday'   => 'Tuesday',
                        'wednesday' => 'Wednesday',
                        'thursday'  => 'Thursday',
                        'friday'    => 'Friday',
                        'saturday'  => 'Saturday',
                        'sunday'    => 'Sunday',
                    ),
                ),

                'webhook_title' => array(
                    'title'       => 'Bonzai Webhooks',
                    'type'        => 'title',
                    'description' => 'Bonzai sends product_access_granted and product_access_revoked. Secured using a token.',
                ),
                'webhook_token' => array(
                    'title'       => 'Webhook Token',
                    'type'        => 'text',
                    'description' => 'Use Generate token, then click Save changes. Paste the webhook URL in Bonzai Premium Webhooks.',
                ),
                'webhook_url' => array(
                    'title'       => 'Webhook URL',
                    'type'        => 'title',
                    'description' =>
                        '<div style="margin:6px 0 10px 0;">' .
                        '<code id="bonzai_webhook_url_preview" data_base_url="' . esc_attr($base_webhook_url) . '">' .
                        esc_html($base_webhook_url . '?token=YOUR_TOKEN') .
                        '</code>' .
                        '</div>' .
                        '<div style="font-size:12px; color:#444;">Paste this URL in Bonzai Premium Webhooks.</div>',
                ),
            );
        }

        public function is_available() {
            if ('yes' !== $this->enabled) return false;
            if (empty($this->api_token)) return false;

            $currency = get_woocommerce_currency();
            $target   = $this->force_currency ? $this->force_currency : $currency;

            if (!in_array($target, array('EUR', 'USD'), true)) return false;

            if (function_exists('WC') && WC()->cart) {
                $total = floatval(WC()->cart->total);
                if ($this->min_amount > 0 && $total < $this->min_amount) return false;
            }

            return parent::is_available();
        }

        protected function log($message, $context = array()) {
            if ($this->logger) {
                $this->logger->info('[Bonzai] ' . $message, array('source' => 'bonzai_gateway') + $context);
            }
        }

        protected function fail_with_notice(WC_Order $order, $msg) {
            wc_add_notice($msg, 'error');
            if ($order instanceof WC_Order) {
                $order->add_order_note('Bonzai: ' . $msg);
            }
            $this->log('Error: ' . $msg);
            return array('result' => 'fail');
        }

        public function admin_options() {
            parent::admin_options();
            ?>
            <script type="text/javascript">
            (function($){
                $(function(){
                    var $tokenField = $('#woocommerce_bonzai_webhook_token');
                    if (!$tokenField.length) return;

                    var $btn = $('<button type="button" class="button" style="margin-left:8px;">Generate token</button>');
                    $btn.insertAfter($tokenField);

                    var $preview = $('#bonzai_webhook_url_preview');
                    var baseUrl  = $preview.attr('data_base_url') || $preview.text();

                    function updatePreview() {
                        var token = $.trim($tokenField.val());
                        var url = baseUrl;
                        if (token) {
                            url += '?token=' + encodeURIComponent(token);
                        } else {
                            url += '?token=YOUR_TOKEN';
                        }
                        $preview.text(url);
                    }

                    $btn.on('click', function(e){
                        e.preventDefault();

                        var token = '';
                        while (token.length < 32) {
                            token += Math.random().toString(36).substring(2);
                        }
                        token = token.substring(0, 32);

                        $tokenField.val(token);
                        $tokenField.trigger('change');
                        updatePreview();

                        var $form = $tokenField.closest('form');
                        if ($form.length) {
                            $form.trigger('change');
                        }
                    });

                    $tokenField.on('input change', updatePreview);
                    updatePreview();
                });
            })(jQuery);
            </script>
            <?php
        }

        public function process_payment($order_id) {

            $order = wc_get_order($order_id);
            if (!$order) return array('result' => 'fail');

            if (empty($this->api_token)) {
                return $this->fail_with_notice(
                    $order,
                    'Missing Bonzai API Token. Go to WooCommerce → Payments → Bonzai → Manage.'
                );
            }

            if (empty($this->product_uuid)) {
                return $this->fail_with_notice(
                    $order,
                    'Missing Bonzai Product UUID. Add it in WooCommerce → Payments → Bonzai → Manage.'
                );
            }

            $product_uuid = $this->product_uuid;

            $amount = (float) $order->get_total();
            if ($amount <= 0) {
                return $this->fail_with_notice($order, 'Invalid order amount.');
            }

            $currency = $this->force_currency ? $this->force_currency : get_woocommerce_currency();
            if (!in_array($currency, array('EUR', 'USD'), true)) {
                $currency = 'EUR';
            }

            $email        = $order->get_billing_email() ?: '';
            $redirect_url = $this->redirect_url ?: home_url('/thank-you');
            $redirect_url = add_query_arg(array('wc_order' => $order->get_id()), $redirect_url);

            $items        = $order->get_items('line_item');
            $product_name = '';
            $item_count   = is_array($items) ? count($items) : 0;

            $is_vat_incl = ($this->is_vat_incl_default === 'yes');
            $mode        = 'one_off';
            $interval    = null;

            if ($item_count > 0 && is_array($items)) {
                foreach ($items as $item) {
                    $product_name = $item->get_name();
                    $product_id   = $item->get_product_id();
                    $product      = $product_id ? wc_get_product($product_id) : null;

                    if ($product_id) {
                        $override_vat = get_post_meta($product_id, 'bonzai_is_vat_incl', true);
                        if ($override_vat === 'yes') $is_vat_incl = true;
                        if ($override_vat === 'no')  $is_vat_incl = false;
                    }

                    $product_mode = $product_id ? get_post_meta($product_id, 'bonzai_payment_mode', true) : '';

                    if ($product && empty($product_mode)) {
                        if (class_exists('WC_Product_Subscription') && $product instanceof WC_Product_Subscription) {
                            $product_mode = 'subscription_auto';
                        } elseif (class_exists('WC_Product_Variable_Subscription') && $product instanceof WC_Product_Variable_Subscription) {
                            $product_mode = 'subscription_auto';
                        }
                    }

                    if ($product_mode === 'subscription_monthly') {
                        $mode     = 'subscription';
                        $interval = 'month';
                    } elseif ($product_mode === 'subscription_yearly') {
                        $mode     = 'subscription';
                        $interval = 'year';
                    } elseif ($product_mode === 'subscription_auto') {
                        $mode = 'subscription';
                        if ($product && is_callable(array($product, 'get_billing_period'))) {
                            $period = (string) $product->get_billing_period();
                            if ($period === 'year') {
                                $interval = 'year';
                            } else {
                                $interval = 'month';
                            }
                        } else {
                            $interval = 'month';
                        }
                    } else {
                        $mode     = 'one_off';
                        $interval = null;
                    }

                    break;
                }
            }

            if ($product_name) {
                if ($item_count > 1) {
                    $bonzai_title = sprintf('%s (+%d more items)', $product_name, $item_count - 1);
                } else {
                    $bonzai_title = $product_name;
                }
            } else {
                $bonzai_title = 'WooCommerce Order #' . $order->get_order_number();
            }

            $payload = array(
                'amount'       => round($amount, 2),
                'currency'     => $currency,
                'title'        => $bonzai_title,
                'redirect_url' => $redirect_url,
                'metadata'     => array(
                    'wc_order_id' => $order->get_id(),
                    'site'        => home_url(),
                ),
                'is_vat_incl'  => (bool) $is_vat_incl,
                'mode'         => $mode,
            );

            if ($interval && $mode === 'subscription') {
                $payload['interval'] = $interval;
            }

            if (!empty($email)) {
                $payload['email'] = sanitize_email($email);
            }

            $this->log('Calling Bonzai checkout: ' . wp_json_encode($payload));

            $response = wp_remote_post("https://www.bonzai.pro/api/v1/products/$product_uuid/checkout", array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $this->api_token,
                    'Content-Type'  => 'application/json',
                ),
                'body'    => wp_json_encode($payload),
                'timeout' => max(5, $this->timeout),
            ));

            if (is_wp_error($response)) {
                return $this->fail_with_notice($order, 'Bonzai API error: ' . $response->get_error_message());
            }

            $code_http = (int) wp_remote_retrieve_response_code($response);
            $body_txt  = (string) wp_remote_retrieve_body($response);
            $body      = json_decode($body_txt, true);

            $this->log('Bonzai checkout response HTTP ' . $code_http . ' body=' . $body_txt);

            $bonzai_error_msg = '';
            if (is_array($body)) {
                if (!empty($body['message'])) {
                    $bonzai_error_msg = (string) $body['message'];
                } elseif (!empty($body['errors']) && is_array($body['errors'])) {
                    foreach ($body['errors'] as $field => $messages) {
                        if (is_array($messages) && !empty($messages)) {
                            $bonzai_error_msg = (string) $field . ': ' . (string) reset($messages);
                            break;
                        }
                    }
                }
            }

            if ($code_http < 200 || $code_http >= 300 || !is_array($body) || empty($body['checkout_url'])) {
                $note = 'Bonzai API HTTP ' . $code_http . ' -> ' . $body_txt;
                $order->add_order_note($note);

                $human_msg = 'Unable to create Bonzai payment.';
                if ($bonzai_error_msg) {
                    $human_msg .= ' Bonzai says: ' . $bonzai_error_msg;
                } else {
                    $human_msg .= ' Please try again later.';
                }

                return $this->fail_with_notice($order, $human_msg);
            }

            $order->update_status('pending', 'Waiting for Bonzai payment.');
            $order->add_order_note('Redirecting to Bonzai. Bonzai order_id: ' . ($body['order_id'] ?? 'n/a'));

            $this->log('Redirect URL: ' . $body['checkout_url']);

            if (!empty($body['order_id'])) {
                update_post_meta($order->get_id(), '_bonzai_order_id', sanitize_text_field($body['order_id']));
                $order->add_order_note('Bonzai: order_id linked ' . $body['order_id']);
            }

            return array(
                'result'   => 'success',
                'redirect' => esc_url_raw($body['checkout_url']),
            );
        }
    }
}

add_filter('woocommerce_payment_gateways', function($methods){
    $methods[] = 'WC_Gateway_Bonzai';
    return $methods;
});


add_action('rest_api_init', function () {
    register_rest_route('bonzai/v1', '/webhook', array(
        'methods'             => 'POST',
        'callback'            => 'bonzai_handle_webhook',
        'permission_callback' => '__return_true',
    ));
});

function bonzai_get_gateway_instance() {
    if (!function_exists('WC') || !WC()->payment_gateways()) return null;
    $gws = WC()->payment_gateways()->payment_gateways();
    return isset($gws['bonzai']) ? $gws['bonzai'] : null;
}

function bonzai_verify_token(WP_REST_Request $request, $gateway) {
    $configured = trim($gateway->get_option('webhook_token'));
    if ($configured === '') return false;
    $q = (string) $request->get_param('token');
    $h = (string) $request->get_header('x-bonzai-token');
    return hash_equals($configured, $q) || hash_equals($configured, $h);
}

function bonzai_already_processed($event_id) {
    if (!$event_id) return false;
    $key = 'bonz_evt_' . md5($event_id);
    if (get_transient($key)) return true;
    set_transient($key, 1, DAY_IN_SECONDS);
    return false;
}

function bonzai_find_wc_order_from_payload(array $evt) {
    $wc_id = $evt['order']['metadata']['wc_order_id'] ?? null;
    if ($wc_id) {
        $order = wc_get_order((int) $wc_id);
        if ($order) return $order;
    }

    $bonzai_order_id = $evt['order_id'] ?? ($evt['order']['id'] ?? null);
    if (!empty($bonzai_order_id)) {
        $orders = wc_get_orders(array(
            'limit'      => 1,
            'meta_key'   => '_bonzai_order_id',
            'meta_value' => (string) $bonzai_order_id,
            'return'     => 'objects',
        ));
        if (!empty($orders)) return $orders[0];
    }

    $email = $evt['user']['email'] ?? '';
    if ($email !== '') {
        $orders = wc_get_orders(array(
            'limit'         => 1,
            'orderby'       => 'date',
            'order'         => 'DESC',
            'status'        => array('pending','on-hold'),
            'billing_email' => $email,
            'return'        => 'objects',
        ));
        if (!empty($orders)) return $orders[0];
    }

    return null;
}

function bonzai_handle_webhook(WP_REST_Request $request) {
    $gw = bonzai_get_gateway_instance();
    if (!$gw) return new WP_REST_Response(array('ok'=>false,'msg'=>'gateway not loaded'), 503);

    if (!bonzai_verify_token($request, $gw)) {
        return new WP_REST_Response(array('ok'=>false,'msg'=>'invalid token'), 401);
    }

    $raw = $request->get_body();
    $evt = json_decode($raw, true);

    if (!is_array($evt)) {
        return new WP_REST_Response(array('ok'=>false,'msg'=>'invalid json'), 400);
    }

    $event_id = $evt['id'] ?? $evt['order_id'] ?? $evt['timestamp'] ?? hash('sha256', $raw);
    if (bonzai_already_processed($event_id)) {
        return new WP_REST_Response(array('ok'=>true,'msg'=>'duplicate'), 200);
    }

    $type  = $evt['event_type'] ?? 'unknown';
    $order = bonzai_find_wc_order_from_payload($evt);

    if (!$order) {
        if (function_exists('wc_get_logger')) {
            wc_get_logger()->warning('[Bonzai] Webhook received without wc_order_id: ' . $raw, array('source'=>'bonzai_gateway'));
        }
        return new WP_REST_Response(array('ok'=>true,'msg'=>'no wc order'), 200);
    }

    switch ($type) {
        case 'product_access_granted':
            if (!$order->is_paid()) {
                $order->payment_complete();
                $order->add_order_note('Bonzai: product_access_granted -> payment confirmed.');
            } else {
                if ($order->get_status() !== 'completed') {
                    $order->update_status('completed', 'Bonzai: product_access_granted -> completed.');
                }
            }
            break;

        case 'product_access_revoked':
            if ($order->get_status() !== 'cancelled') {
                $order->update_status('cancelled', 'Bonzai: product_access_revoked.');
            }
            break;

        default:
            $order->add_order_note('Bonzai: unhandled event ' . esc_html($type) . '.');
            break;
    }

    return new WP_REST_Response(array('ok'=>true), 200);
}

add_action('template_redirect', function(){
    if (!isset($_GET['wc_order'])) return;
    $order = wc_get_order(absint($_GET['wc_order']));
    if (!$order || $order->is_paid()) return;
    $order->add_order_note('Customer returned to the redirect page. Waiting for Bonzai webhook.');
});

add_filter('woocommerce_payment_complete_order_status', function($status, $order_id, $order){
    if ($order instanceof WC_Order && $order->get_payment_method() === 'bonzai') {
        return 'completed';
    }
    return $status;
}, 10, 3);


add_action('woocommerce_product_options_general_product_data', 'bonzai_product_fields');

function bonzai_product_fields() {
    echo '<div class="options_group">';

    woocommerce_wp_select(array(
        'id'          => 'bonzai_is_vat_incl',
        'label'       => 'Bonzai VAT handling',
        'description' => 'Override Bonzai VAT handling for this product. If Inherit, gateway default is used.',
        'desc_tip'    => true,
        'options'     => array(
            ''     => 'Inherit from gateway setting',
            'yes'  => 'Amount includes VAT',
            'no'   => 'Amount excludes VAT',
        ),
    ));

    woocommerce_wp_select(array(
        'id'          => 'bonzai_payment_mode',
        'label'       => 'Bonzai payment mode',
        'description' => 'Choose how this product should be charged in Bonzai.',
        'desc_tip'    => true,
        'options'     => array(
            ''                     => 'Inherit or auto detect',
            'one_off'              => 'One off payment',
            'subscription_monthly' => 'Subscription monthly',
            'subscription_yearly'  => 'Subscription yearly',
        ),
    ));

    echo '</div>';
}

add_action('woocommerce_process_product_meta', 'bonzai_save_product_fields');

function bonzai_save_product_fields($post_id) {
    if (isset($_POST['bonzai_is_vat_incl'])) {
        $value = wc_clean(wp_unslash($_POST['bonzai_is_vat_incl']));
        if (!in_array($value, array('', 'yes', 'no'), true)) $value = '';
        update_post_meta($post_id, 'bonzai_is_vat_incl', $value);
    }

    if (isset($_POST['bonzai_payment_mode'])) {
        $mode = wc_clean(wp_unslash($_POST['bonzai_payment_mode']));
        if (!in_array($mode, array('', 'one_off', 'subscription_monthly', 'subscription_yearly'), true)) $mode = '';
        update_post_meta($post_id, 'bonzai_payment_mode', $mode);
    }
}


function bonzai_api_retrieve_order($bonzai_order_id, $gateway) {
    $bonzai_order_id = trim((string) $bonzai_order_id);
    if ($bonzai_order_id === '') {
        return new WP_Error('bonzai_no_order_id', 'Missing Bonzai order_id');
    }

    $api_token = trim($gateway->api_token);
    if ($api_token === '') {
        return new WP_Error('bonzai_no_token', 'Missing Bonzai API token');
    }

    $url = 'https://www.bonzai.pro/api/v1/orders/' . rawurlencode($bonzai_order_id);

    $response = wp_remote_get($url, array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_token,
            'Accept'        => 'application/json',
        ),
        'timeout' => max(5, (int) $gateway->timeout),
    ));

    if (is_wp_error($response)) {
        if (!empty($gateway->debug)) {
            $gateway->log('Retrieve order error: ' . $response->get_error_message());
        }
        return $response;
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    $body_txt = (string) wp_remote_retrieve_body($response);
    $body = json_decode($body_txt, true);

    if ($code !== 200 || !is_array($body)) {
        if (!empty($gateway->debug)) {
            $gateway->log('Retrieve order HTTP ' . $code . ' body=' . $body_txt);
        }
        return new WP_Error('bonzai_bad_response', 'Unexpected response from Bonzai retrieve order', array(
            'code' => $code,
            'body' => $body_txt,
        ));
    }

    return $body;
}

function bonzai_store_last_retrieve_payload(WC_Order $order, array $api_order) {
    update_post_meta($order->get_id(), '_bonzai_last_retrieve_payload', wp_json_encode($api_order));
    update_post_meta($order->get_id(), '_bonzai_last_retrieve_at', current_time('mysql'));
}

function bonzai_extract_timeline(array $payload) {
    $events = array();

    // 1) If there is a real timeline field, use it (future-proof)
    if (!empty($payload['timeline']) && is_array($payload['timeline'])) {
        foreach ($payload['timeline'] as $ev) {
            if (!is_array($ev)) continue;

            $date = $ev['date'] ?? ($ev['created_at'] ?? '');
            if (!$date) continue;

            $events[] = array(
                'date'    => (string) $date,
                'type'    => (string) ($ev['type'] ?? ($ev['event'] ?? 'event')),
                'message' => (string) ($ev['message'] ?? ($ev['label'] ?? '')),
            );
        }
    }

    // 2) Fallback: build timeline from accesses[]
    if (empty($events) && !empty($payload['accesses']) && is_array($payload['accesses'])) {
        foreach ($payload['accesses'] as $a) {
            if (!is_array($a)) continue;

            $id = isset($a['id']) ? (string) $a['id'] : '';

            if (!empty($a['created_at'])) {
                $events[] = array(
                    'date'    => (string) $a['created_at'],
                    'type'    => 'access',
                    'message' => 'Access created' . ($id ? " (#$id)" : ''),
                );
            }

            if (!empty($a['updated_at']) && ($a['updated_at'] !== ($a['created_at'] ?? null))) {
                $events[] = array(
                    'date'    => (string) $a['updated_at'],
                    'type'    => 'access',
                    'message' => 'Access updated' . ($id ? " (#$id)" : ''),
                );
            }

            if (!empty($a['deleted_at'])) {
                $events[] = array(
                    'date'    => (string) $a['deleted_at'],
                    'type'    => 'access',
                    'message' => 'Access deleted' . ($id ? " (#$id)" : ''),
                );
            }
        }
    }

    // Sort ASC by date
    usort($events, function($x, $y){
        $dx = strtotime((string)($x['date'] ?? '')) ?: 0;
        $dy = strtotime((string)($y['date'] ?? '')) ?: 0;
        return $dx <=> $dy;
    });

    return $events;
}

function bonzai_render_history_html(array $payload, $bonzai_order_id = '') {
    $has_access = array_key_exists('has_access', $payload) ? ($payload['has_access'] ? 'true' : 'false') : 'null';
    $intent_status = $payload['intent_status'] ?? ($payload['order']['intent_status'] ?? null);
    $subscription_status = $payload['subscription_status'] ?? ($payload['order']['subscription_status'] ?? null);

    $timeline = bonzai_extract_timeline($payload);

    ob_start();
    ?>
    <div style="padding:12px;">
        <div style="margin-bottom:10px;">
            <div><strong>Bonzai order_id:</strong> <?php echo esc_html($bonzai_order_id ?: ''); ?></div>
            <div><strong>has_access:</strong> <?php echo esc_html($has_access); ?></div>
            <div><strong>intent_status:</strong> <?php echo esc_html($intent_status !== null ? (string) $intent_status : 'null'); ?></div>
            <div><strong>subscription_status:</strong> <?php echo esc_html($subscription_status !== null ? (string) $subscription_status : 'null'); ?></div>
        </div>

        <h3 style="margin:0 0 8px 0;">Timeline</h3>

        <?php if (empty($timeline)) : ?>
            <p>No timeline data found in this Retrieve payload. Raw payload is available below.</p>
        <?php else : ?>
            <table class="widefat striped" style="margin-top:8px;">
                <thead>
                    <tr>
                        <th style="width:180px;">Date</th>
                        <th style="width:220px;">Type</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($timeline as $evt) : ?>
                    <tr>
                        <td><?php echo esc_html($evt['date']); ?></td>
                        <td><?php echo esc_html($evt['type']); ?></td>
                        <td><?php echo esc_html($evt['message']); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <details style="margin-top:10px;">
            <summary>Raw payload</summary>
            <pre style="white-space:pre-wrap;"><?php echo esc_html(wp_json_encode($payload, JSON_PRETTY_PRINT)); ?></pre>
        </details>
    </div>
    <?php
    return ob_get_clean();
}

function bonzai_sync_wc_order_with_bonzai(WC_Order $order, array $api_order) {

    // Support plusieurs formats de réponse possibles
    $has_access = null;
    if (array_key_exists('has_access', $api_order)) {
        $has_access = (bool) $api_order['has_access'];
    } elseif (isset($api_order['order']) && is_array($api_order['order']) && array_key_exists('has_access', $api_order['order'])) {
        $has_access = (bool) $api_order['order']['has_access'];
    }

    $intent_status = $api_order['intent_status'] ?? ($api_order['order']['intent_status'] ?? null);
    $subscription_status = $api_order['subscription_status'] ?? ($api_order['order']['subscription_status'] ?? null);

    // Normalisation simple
    $intent_status_norm = is_string($intent_status) ? strtolower(trim($intent_status)) : null;
    $subscription_status_norm = is_string($subscription_status) ? strtolower(trim($subscription_status)) : null;

    $order->add_order_note(sprintf(
        'Bonzai sync: intent_status=%s, subscription_status=%s, has_access=%s',
        $intent_status_norm !== null ? $intent_status_norm : 'null',
        $subscription_status_norm !== null ? $subscription_status_norm : 'null',
        $has_access === null ? 'null' : ($has_access ? 'true' : 'false')
    ));

    // Heuristique paiement complété
    $payment_completed =
        ($intent_status_norm === 'completed')
        || ($intent_status_norm === 'complete')
        || ($intent_status_norm === 'succeeded')
        || ($intent_status_norm === 'paid');

    // 1) Access actif: on force completed même si c'était refunded
    if ($has_access === true) {
        if ($order->get_status() !== 'completed') {
            // payment_complete peut être bloquant selon l'état, donc on force le statut
            $order->update_status('completed', 'Bonzai sync: access active.');
        }
        return;
    }

    // 2) Access inactif
    if ($has_access === false) {

        // Si paiement jamais complété: on évite de mettre refunded sur un test non payé
        if (!$payment_completed && !$order->is_paid()) {
            // Laisser tel quel, ou marquer cancelled si vous voulez
            $order->add_order_note('Bonzai sync: access inactive and payment not completed. No status change.');
            return;
        }

        // Si paiement a existé: refunded
        if ($order->get_status() !== 'cancelled') {
            $order->update_status('cancelled', 'Bonzai sync: access inactive after payment.');
        }
        return;
    }

    // 3) Cas indéterminé: on ne touche pas au statut
    $order->add_order_note('Bonzai sync: unable to determine access state. No status change.');
}


add_action('init', 'bonzai_register_cron_event');

function bonzai_register_cron_event() {
    if (!wp_next_scheduled('bonzai_cron_order_sync')) {
        wp_schedule_event(time() + HOUR_IN_SECONDS, 'hourly', 'bonzai_cron_order_sync');
    }
}

add_action('bonzai_cron_order_sync', 'bonzai_run_cron_order_sync');

function bonzai_run_cron_order_sync() {
    $gw = bonzai_get_gateway_instance();
    if (!$gw) return;

    $mode = $gw->order_sync_enabled ?? 'no';
    if ($mode === 'no') return;

    $hour_config = isset($gw->order_sync_hour) ? (int) $gw->order_sync_hour : 3;
    $day_config  = isset($gw->order_sync_day) ? strtolower($gw->order_sync_day) : 'monday';

    $now      = current_datetime();
    $hour_now = (int) $now->format('G');
    $day_now  = strtolower($now->format('l'));

    if ($hour_now !== $hour_config) return;

    if ($mode === 'daily') {
        $today = $now->format('Y-m-d');
        $last  = get_option('bonzai_sync_last_daily');
        if ($last === $today) return;
        update_option('bonzai_sync_last_daily', $today);
    } elseif ($mode === 'weekly') {
        if ($day_now !== $day_config) return;
        $yearweek = $now->format('o-W');
        $last     = get_option('bonzai_sync_last_weekly');
        if ($last === $yearweek) return;
        update_option('bonzai_sync_last_weekly', $yearweek);
    } else {
        return;
    }

    if (!empty($gw->debug)) {
        $gw->log('Starting automatic Bonzai order sync via cron.');
    }

    $orders = wc_get_orders(array(
        'limit'        => -1,
        'meta_key'     => '_bonzai_order_id',
        'meta_compare' => 'EXISTS',
        'status'       => array('pending','on-hold','processing','completed','refunded','cancelled','failed'),
        'return'       => 'objects',
    ));

    if (empty($orders)) {
        if (!empty($gw->debug)) $gw->log('Automatic sync: no orders with Bonzai order_id found.');
        return;
    }

    foreach ($orders as $order) {
        $bonzai_order_id = get_post_meta($order->get_id(), '_bonzai_order_id', true);
        if (!$bonzai_order_id) continue;

        $api_order = bonzai_api_retrieve_order($bonzai_order_id, $gw);
        if (is_wp_error($api_order)) {
            if (!empty($gw->debug)) {
                $gw->log('Automatic sync error for order #' . $order->get_id() . ': ' . $api_order->get_error_message());
            }
            $order->add_order_note('Bonzai automatic sync error: ' . $api_order->get_error_message());
            continue;
        }

        bonzai_store_last_retrieve_payload($order, $api_order);
        bonzai_sync_wc_order_with_bonzai($order, $api_order);
    }

    if (!empty($gw->debug)) {
        $gw->log('Automatic Bonzai order sync finished.');
    }
}


add_action('admin_menu', 'bonzai_register_admin_page');

function bonzai_register_admin_page() {
    add_submenu_page(
        'woocommerce',
        'Bonzai Order Sync',
        'Bonzai Order Sync',
        'manage_woocommerce',
        'bonzai_order_sync',
        'bonzai_render_order_sync_page'
    );
}

function bonzai_render_order_sync_page() {
    if (!current_user_can('manage_woocommerce')) {
        wp_die('You do not have permission to access this page.');
    }

    $gw = bonzai_get_gateway_instance();
    if (!$gw) {
        echo '<div class="notice notice-error"><p>Bonzai gateway is not loaded.</p></div>';
        return;
    }

    $orders       = array();
    $search_email = '';
    $message      = '';
    $message_type = 'info';

    if (isset($_POST['bonzai_search_email']) && isset($_POST['bonzai_action']) && $_POST['bonzai_action'] === 'search') {
        check_admin_referer('bonzai_search_orders');
        $search_email = sanitize_email(wp_unslash($_POST['bonzai_search_email']));
        if ($search_email) {
            $orders = wc_get_orders(array(
                'limit'         => 50,
                'orderby'       => 'date',
                'order'         => 'DESC',
                'billing_email' => $search_email,
                'return'        => 'objects',
            ));
            if (empty($orders)) {
                $message = 'No orders found for this email.';
                $message_type = 'warning';
            }
        } else {
            $message = 'Please enter a valid email address.';
            $message_type = 'error';
        }
    }

    if (isset($_POST['bonzai_sync_order_id']) && isset($_POST['bonzai_action']) && $_POST['bonzai_action'] === 'sync') {
        check_admin_referer('bonzai_sync_single_order');

        $order_id = absint($_POST['bonzai_sync_order_id']);
        $search_email = isset($_POST['bonzai_search_email']) ? sanitize_email(wp_unslash($_POST['bonzai_search_email'])) : '';
        $order = wc_get_order($order_id);

        if ($order) {
            $bonzai_order_id = get_post_meta($order_id, '_bonzai_order_id', true);
            if (!$bonzai_order_id) {
                $message = 'This order does not have a Bonzai order_id. It cannot be synced.';
                $message_type = 'error';
            } else {
                $api_order = bonzai_api_retrieve_order($bonzai_order_id, $gw);
                if (is_wp_error($api_order)) {
                    $message = 'Error while retrieving order from Bonzai: ' . esc_html($api_order->get_error_message());
                    $message_type = 'error';
                    $order->add_order_note('Bonzai manual sync error: ' . $api_order->get_error_message());
                } else {
                    bonzai_store_last_retrieve_payload($order, $api_order);
                    bonzai_sync_wc_order_with_bonzai($order, $api_order);
                    $message = 'Bonzai order synced successfully for WooCommerce order #' . $order_id . '.';
                    $message_type = 'success';
                }
            }
        } else {
            $message = 'Invalid WooCommerce order ID.';
            $message_type = 'error';
        }

        if ($search_email) {
            $orders = wc_get_orders(array(
                'limit'         => 50,
                'orderby'       => 'date',
                'order'         => 'DESC',
                'billing_email' => $search_email,
                'return'        => 'objects',
            ));
        }
    }

    $notice_class = 'notice notice-info';
    if ($message_type === 'success') $notice_class = 'notice notice-success';
    if ($message_type === 'warning') $notice_class = 'notice notice-warning';
    if ($message_type === 'error')   $notice_class = 'notice notice-error';

    echo '<div class="wrap"><h1>Bonzai Order Sync</h1>';

    if ($message) {
        echo '<div class="' . esc_attr($notice_class) . ' is-dismissible"><p>' . esc_html($message) . '</p></div>';
    }

    echo '<h2>Search orders by customer email</h2>';
    echo '<form method="post">';
    wp_nonce_field('bonzai_search_orders');
    echo '<input type="hidden" name="bonzai_action" value="search" />';
    echo '<p><label for="bonzai_search_email">Customer email:</label> ';
    echo '<input type="email" id="bonzai_search_email" name="bonzai_search_email" value="' . esc_attr($search_email) . '" size="40" />';
    submit_button('Search orders', 'secondary', 'submit', false);
    echo '</p></form>';

    if (!empty($orders)) {
        echo '<h2>Orders for ' . esc_html($search_email) . '</h2>';
        echo '<table class="widefat striped">';
        echo '<thead><tr><th>Order ID</th><th>Date</th><th>Status</th><th>Total</th><th>Bonzai order_id</th><th>Action</th></tr></thead><tbody>';

        foreach ($orders as $order) {
            $bonzai_order_id = get_post_meta($order->get_id(), '_bonzai_order_id', true);
            $payload_exists = (bool) get_post_meta($order->get_id(), '_bonzai_last_retrieve_payload', true);

            echo '<tr>';
            echo '<td><a href="' . esc_url(get_edit_post_link($order->get_id())) . '">#' . esc_html($order->get_id()) . '</a></td>';
            echo '<td>' . esc_html($order->get_date_created() ? $order->get_date_created()->date_i18n('Y-m-d H:i') : '') . '</td>';
            echo '<td>' . esc_html(wc_get_order_status_name($order->get_status())) . '</td>';
            $total_html = wp_kses_post(
                wc_price($order->get_total(), array('currency' => $order->get_currency()))
            );

            if ($order->has_status('refunded')) {
                $zero_html = wp_kses_post(
                    wc_price(0, array('currency' => $order->get_currency()))
                );

                echo '<td>'
                    . '<del>' . $total_html . '</del> '
                    . '<ins>' . $zero_html . '</ins>'
                    . '</td>';
            } else {
                echo '<td>' . $total_html . '</td>';
            }
            echo '<td>' . esc_html($bonzai_order_id ? $bonzai_order_id : '') . '</td>';

            echo '<td>';
            if ($bonzai_order_id) {
                echo '<form method="post" style="display:inline-block; margin-right:8px;">';
                wp_nonce_field('bonzai_sync_single_order');
                echo '<input type="hidden" name="bonzai_action" value="sync" />';
                echo '<input type="hidden" name="bonzai_search_email" value="' . esc_attr($search_email) . '" />';
                echo '<input type="hidden" name="bonzai_sync_order_id" value="' . esc_attr($order->get_id()) . '" />';
                submit_button('Sync with Bonzai', 'primary', 'submit', false);
                echo '</form>';

                if ($payload_exists) {
                    echo '<button type="button" class="button bonzai_history_btn" data_order_id="' . esc_attr($order->get_id()) . '">History</button>';
                } else {
                    echo '<span style="margin-left:6px; color:#666;">No history yet</span>';
                }

            } else {
                echo 'No Bonzai order_id';
            }
            echo '</td>';

            echo '</tr>';
        }

        echo '</tbody></table>';
    }

    $nonce = wp_create_nonce('bonzai_history_nonce');
    $ajax_url = admin_url('admin-ajax.php');

    echo '
<div id="bonzai_history_modal" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.6); z-index:99999;">
  <div style="background:#fff; width:90%; max-width:1100px; margin:40px auto; border-radius:6px; overflow:hidden;">
    <div style="padding:12px 16px; border-bottom:1px solid #ddd; display:flex; justify-content:space-between; align-items:center;">
      <div style="font-size:16px; font-weight:600;">Bonzai Retrieve History</div>
      <button type="button" class="button" id="bonzai_history_close">Close</button>
    </div>
    <div id="bonzai_history_meta" style="padding:8px 16px; border-bottom:1px solid #eee; color:#444;"></div>
    <div id="bonzai_history_content" style="max-height:70vh; overflow:auto;"></div>
  </div>
</div>

<script type="text/javascript">
(function($){
  function openModal(){ $("#bonzai_history_modal").show(); }
  function closeModal(){
    $("#bonzai_history_modal").hide();
    $("#bonzai_history_content").html("");
    $("#bonzai_history_meta").text("");
  }

  $(document).on("click", "#bonzai_history_close", function(){ closeModal(); });
  $(document).on("click", "#bonzai_history_modal", function(e){
    if (e.target === this) closeModal();
  });

  $(document).on("click", ".bonzai_history_btn", function(){
    var orderId = $(this).attr("data_order_id");
    $("#bonzai_history_content").html("<div style=\'padding:12px;\'>Loading...</div>");
    $("#bonzai_history_meta").text("");
    openModal();

    $.post("' . esc_js($ajax_url) . '", {
      action: "bonzai_get_order_history",
      nonce: "' . esc_js($nonce) . '",
      order_id: orderId
    })
    .done(function(resp){
      if (!resp || !resp.success) {
        var msg = (resp && resp.data && resp.data.message) ? resp.data.message : "Unknown error";
        $("#bonzai_history_content").html("<div style=\'padding:12px; color:#b32d2e;\'>" + msg + "</div>");
        return;
      }
      if (resp.data && resp.data.last_retrieve_at) {
        $("#bonzai_history_meta").text("Last retrieve at: " + resp.data.last_retrieve_at);
      }
      $("#bonzai_history_content").html(resp.data.html || "<div style=\'padding:12px;\'>No data</div>");
    })
    .fail(function(){
      $("#bonzai_history_content").html("<div style=\'padding:12px; color:#b32d2e;\'>Request failed</div>");
    });
  });
})(jQuery);
</script>
';

    echo '</div>';
}

add_action('wp_ajax_bonzai_get_order_history', 'bonzai_ajax_get_order_history');

function bonzai_ajax_get_order_history() {
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error(array('message' => 'Unauthorized'), 403);
    }

    check_ajax_referer('bonzai_history_nonce', 'nonce');

    $order_id = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
    if (!$order_id) {
        wp_send_json_error(array('message' => 'Missing order_id'), 400);
    }

    $order = wc_get_order($order_id);
    if (!$order) {
        wp_send_json_error(array('message' => 'Invalid WooCommerce order'), 404);
    }

    $payload_json = get_post_meta($order_id, '_bonzai_last_retrieve_payload', true);
    if (!$payload_json) {
        wp_send_json_error(array('message' => 'No stored Retrieve payload for this order. Run Sync first.'), 404);
    }

    $payload = json_decode($payload_json, true);
    if (!is_array($payload)) {
        wp_send_json_error(array('message' => 'Stored payload is invalid JSON'), 500);
    }

    $bonzai_order_id = get_post_meta($order_id, '_bonzai_order_id', true);
    $html = bonzai_render_history_html($payload, $bonzai_order_id);

    $last_at = (string) get_post_meta($order_id, '_bonzai_last_retrieve_at', true);

    wp_send_json_success(array(
        'html' => $html,
        'last_retrieve_at' => $last_at,
    ));
}
